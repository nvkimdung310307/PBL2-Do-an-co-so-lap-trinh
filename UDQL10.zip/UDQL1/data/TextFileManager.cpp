#include "data/TextFileManager.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QByteArray>
#include <QSaveFile>
#include <QTextStream>
#include <QString>
#include <QStringList>
#include <utility>
#include <QtGlobal>
#if QT_VERSION >= QT_VERSION_CHECK(6, 0, 0)
#include <QStringConverter>
#endif

namespace {
QString g_lastTextFileError;

QString fromUtf8(const std::string& value)
{
    return QString::fromUtf8(value.data(), static_cast<int>(value.size()));
}

std::string toUtf8(const QString& value)
{
    const QByteArray bytes = value.toUtf8();
    return std::string(bytes.constData(), static_cast<size_t>(bytes.size()));
}

void setUtf8(QTextStream& stream)
{
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    stream.setCodec("UTF-8");
#else
    stream.setEncoding(QStringConverter::Utf8);
#endif
}

QString escapeField(const QString& value)
{
    QString out;
    out.reserve(value.size());
    for (QChar ch : value) {
        if (ch == QLatin1Char('\\')) out += QStringLiteral("\\\\");
        else if (ch == QLatin1Char('|')) out += QStringLiteral("\\p");
        else if (ch == QLatin1Char('\n')) out += QStringLiteral("\\n");
        else if (ch == QLatin1Char('\r')) out += QStringLiteral("\\r");
        else out += ch;
    }
    return out;
}

QString unescapeField(const QString& value)
{
    QString out;
    out.reserve(value.size());
    for (int i = 0; i < value.size(); ++i) {
        const QChar ch = value.at(i);
        if (ch == QLatin1Char('\\') && i + 1 < value.size()) {
            const QChar next = value.at(i + 1);
            if (next == QLatin1Char('\\')) { out += QLatin1Char('\\'); ++i; continue; }
            if (next == QLatin1Char('p')) { out += QLatin1Char('|'); ++i; continue; }
            if (next == QLatin1Char('n')) { out += QLatin1Char('\n'); ++i; continue; }
            if (next == QLatin1Char('r')) { out += QLatin1Char('\r'); ++i; continue; }
        }
        out += ch;
    }
    return out;
}

QStringList splitEscapedLine(const QString& line)
{
    QStringList parts;
    QString field;
    bool escaped = false;
    for (QChar ch : line) {
        if (escaped) {
            field += QLatin1Char('\\');
            field += ch;
            escaped = false;
        } else if (ch == QLatin1Char('\\')) {
            escaped = true;
        } else if (ch == QLatin1Char('|')) {
            parts.push_back(unescapeField(field));
            field.clear();
        } else {
            field += ch;
        }
    }
    if (escaped) field += QLatin1Char('\\');
    parts.push_back(unescapeField(field));
    return parts;
}
}

std::string TextFileManager::dataDirectory()
{
#ifndef APP_DATA_DIR
#error "APP_DATA_DIR must be defined by CMake to select the single TXT data directory."
#endif
    // Chi su dung duy nhat database/ cua thu muc ma CMake da cau hinh.
    // Tuyet doi khong tim fallback theo currentPath() hoac vi tri file EXE,
    // tranh doc/ghi nham mot bo TXT khac khi chay tu VS Code hay double-click.
    const QString configuredPath = QString::fromUtf8(APP_DATA_DIR);
    const QString absolutePath = QDir::cleanPath(QFileInfo(configuredPath).absoluteFilePath());
    // Neu khong tao duoc thu muc, van giu dung duong dan chuan de thao tac
    // doc/ghi that bai ro rang; khong duoc roi ve current working directory.
    QDir().mkpath(absolutePath);
    return toUtf8(absolutePath);
}

std::string TextFileManager::filePath(const std::string& fileName)
{
    const QString safeName = QFileInfo(fromUtf8(fileName)).fileName();
    const QDir root(fromUtf8(dataDirectory()));
    return toUtf8(root.filePath(safeName));
}



bool TextFileManager::read(const std::string& fileName, std::vector<Row>& rows)
{
    g_lastTextFileError.clear();
    rows.clear();
    QFile file(fromUtf8(filePath(fileName)));
    if (!file.exists()) return true; // File mới: danh sách rỗng hợp lệ.
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        g_lastTextFileError = QStringLiteral("Không mở được %1: %2")
                                  .arg(file.fileName(), file.errorString());
        return false;
    }

    QTextStream in(&file);
    setUtf8(in);
    while (!in.atEnd()) {
        const QString line = in.readLine();
        if (line.isEmpty()) continue;
        const QStringList parts = splitEscapedLine(line);
        Row row;
        row.reserve(static_cast<size_t>(parts.size()));
        for (const QString& part : parts) row.push_back(toUtf8(part));
        rows.push_back(std::move(row));
    }
    if (in.status() != QTextStream::Ok) {
        g_lastTextFileError = QStringLiteral("Lỗi đọc dữ liệu từ %1.").arg(file.fileName());
        return false;
    }
    return true;
}

bool TextFileManager::write(const std::string& fileName, const std::vector<Row>& rows)
{
    g_lastTextFileError.clear();
    const QString path = fromUtf8(filePath(fileName));
    if (!QDir().mkpath(QFileInfo(path).absolutePath())) {
        g_lastTextFileError = QStringLiteral("Không tạo được thư mục dữ liệu: %1").arg(QFileInfo(path).absolutePath());
        return false;
    }
    QSaveFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        g_lastTextFileError = QStringLiteral("Không mở được file để ghi %1: %2").arg(path, file.errorString());
        return false;
    }

    QTextStream out(&file);
    setUtf8(out);
    for (const Row& row : rows) {
        for (size_t i = 0; i < row.size(); ++i) {
            if (i) out << QLatin1Char('|');
            out << escapeField(fromUtf8(row[i]));
        }
        out << QLatin1Char('\n');
    }
    out.flush();
    if (out.status() != QTextStream::Ok) {
        g_lastTextFileError = QStringLiteral("Lỗi ghi dữ liệu vào %1.").arg(path);
        file.cancelWriting();
        return false;
    }
    if (!file.commit()) {
        g_lastTextFileError = QStringLiteral("Không thể hoàn tất ghi file %1: %2")
                                  .arg(path, file.errorString());
        return false;
    }
    return true;
}

QString TextFileManager::lastErrorMessage()
{
    return g_lastTextFileError;
}


