#ifndef TEXT_FILE_MANAGER_H
#define TEXT_FILE_MANAGER_H

#include <string>
#include <vector>
#include <utility>
#include <QString>

class TextFileManager
{
public:
    using Row = std::vector<std::string>;

    static std::string dataDirectory();
    // Mot bo du lieu TXT duy nhat cho nha hang nay.
    static std::string filePath(const std::string& fileName);
    static bool read(const std::string& fileName, std::vector<Row>& rows);
    static bool write(const std::string& fileName, const std::vector<Row>& rows);
    static QString lastErrorMessage();
    // Ghi nhieu file theo journal: neu bi dung dot ngot, lan thao tac tiep theo se roll-forward.
 
};

#endif
