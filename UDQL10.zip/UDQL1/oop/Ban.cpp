#include "Ban.h"

using std::string;

Ban::Ban(){
    maban = "";
    tenban = "";
    socho = 0;
    trangthai = "";
    makhuvuc = "";
}
Ban::Ban(string maban, string tenban, int socho, string trangthai, string makhuvuc){
    this->maban = maban;
    this->tenban = tenban;
    this->socho = socho;
    this->trangthai = trangthai;
    this->makhuvuc = makhuvuc;
}
string Ban::getMaBan() const{
    return maban;
}
string Ban::getTenBan() const{
    return tenban;
}
int Ban::getSoCho() const{
    return socho;
}
string Ban::getTrangThai() const{
    return trangthai;
}
string Ban::getMaKhuVuc() const{
    return makhuvuc;
}
void Ban::setMaBan(string maban){
    this->maban = maban;
}
void Ban::setTenBan(string tenban){
    this->tenban = tenban;
}
void Ban::setSoCho(int socho){
    this->socho = socho;
}
void Ban::setTrangThai(string trangthai){
    this->trangthai = trangthai;
}
void Ban::setMaKhuVuc(string makhuvuc){
    this->makhuvuc = makhuvuc;
}
bool Ban::hopLe() const{
    return !maban.empty() && !tenban.empty() && socho > 0 && !makhuvuc.empty();
}