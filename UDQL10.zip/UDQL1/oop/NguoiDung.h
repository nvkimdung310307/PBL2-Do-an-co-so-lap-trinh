#ifndef NGUOIDUNG_H
#define NGUOIDUNG_H

#include <string>

// Lop co so truu tuong cho nhung nguoi tham gia he thong nha hang.
class NguoiDung
{
private:
    std::string madinhdanh;
    std::string hoten;
    std::string sodienthoai;

protected:
    void setMaDinhDanh(const std::string& ma);

public:
    void setHoTen(const std::string& ten);
    void setSoDienThoai(const std::string& sodt);

    NguoiDung();
    NguoiDung(const std::string& ma, const std::string& ten, const std::string& sodt);
    virtual ~NguoiDung() = default;

    std::string getMaDinhDanh() const;
    std::string getHoTen() const;
    std::string getSoDienThoai() const;

    // Lop con tu dinh nghia cach kiem tra du lieu hop le.
    virtual bool hopLe() const = 0;
};

#endif
