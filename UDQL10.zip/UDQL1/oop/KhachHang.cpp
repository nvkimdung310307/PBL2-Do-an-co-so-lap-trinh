#include "KhachHang.h"

using std::string;

KhachHang::KhachHang()
    : NguoiDung()
{
}

KhachHang::KhachHang(string makh, string hoten, string sodienthoai)
    : NguoiDung(makh, hoten, sodienthoai)
{
}

string KhachHang::getMaKH() const
{
    return getMaDinhDanh();
}

void KhachHang::setMaKH(string makh)
{
    setMaDinhDanh(makh);
}

bool KhachHang::hopLe() const
{
    return !getMaKH().empty() && !getHoTen().empty()
        && !getSoDienThoai().empty();
}
