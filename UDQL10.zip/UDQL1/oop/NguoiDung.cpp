#include "NguoiDung.h"

using std::string;

NguoiDung::NguoiDung()
    : madinhdanh(""), hoten(""), sodienthoai("")
{
}

NguoiDung::NguoiDung(const string& ma, const string& ten, const string& sodt)
    : madinhdanh(ma), hoten(ten), sodienthoai(sodt)
{
}

string NguoiDung::getMaDinhDanh() const
{
    return madinhdanh;
}

string NguoiDung::getHoTen() const
{
    return hoten;
}

string NguoiDung::getSoDienThoai() const
{
    return sodienthoai;
}

void NguoiDung::setMaDinhDanh(const string& ma)
{
    madinhdanh = ma;
}

void NguoiDung::setHoTen(const string& ten)
{
    hoten = ten;
}

void NguoiDung::setSoDienThoai(const string& sodt)
{
    sodienthoai = sodt;
}
