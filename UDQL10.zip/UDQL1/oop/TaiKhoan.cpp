#include "TaiKhoan.h"

using std::string;

TaiKhoan::TaiKhoan(){
    matk = "";
    tendangnhap = "";
    matkhau = "";
    vaitro = "";
    manv = "";
    trangthai = "";
}
TaiKhoan::TaiKhoan(string matk, string tendangnhap, string matkhau, string vaitro, string manv, string trangthai){
    this->matk = matk;
    this->tendangnhap = tendangnhap;
    this->matkhau = matkhau;
    this->vaitro = vaitro;
    this->manv = manv;
    this->trangthai = trangthai;
}
string TaiKhoan::getMaTK() const{
    return matk;
}
string TaiKhoan::getTenDangNhap() const{
    return tendangnhap;
}
string TaiKhoan::getMatKhau() const{
    return matkhau;
}
string TaiKhoan::getVaiTro() const{
    return vaitro;
}
string TaiKhoan::getMaNV() const{
    return manv;
}
string TaiKhoan::getTrangThai() const{
    return trangthai;
}
void TaiKhoan::setMaTK(string matk){
    this->matk = matk;
}
void TaiKhoan::setTenDangNhap(string tendangnhap){
    this->tendangnhap = tendangnhap;
}
void TaiKhoan::setMatKhau(string matkhau){
    this->matkhau = matkhau;
}
void TaiKhoan::setVaiTro(string vaitro){
    this->vaitro = vaitro;
}
void TaiKhoan::setMaNV(string manv){
    this->manv = manv;
}
void TaiKhoan::setTrangThai(string trangthai){
    this->trangthai = trangthai;
}
bool TaiKhoan::hopLe() const{
    return !matk.empty() && !tendangnhap.empty() && !matkhau.empty() && !vaitro.empty() && !manv.empty();
}