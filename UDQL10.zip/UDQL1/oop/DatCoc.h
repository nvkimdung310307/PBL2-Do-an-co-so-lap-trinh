#ifndef DATCOC_H
#define DATCOC_H

#include <string>

// Thong tin dat coc duoc quan ly doc lap voi phieu dat ban.
class DatCoc {
private:
    std::string maDatCoc;
    std::string maDatBan;
    long long soTien;
    std::string ngayDatCoc; // Dinh dang YYYY-MM-DD
    std::string trangThai;

public:
    // Cac trang thai hop le cua dat coc.
    static const std::string CHUA_DAT_COC;
    static const std::string DA_DAT_COC;
    static const std::string DA_HOAN_COC;
    static const std::string MAT_COC;

    DatCoc();
    DatCoc(const std::string& maDatCoc,
           const std::string& maDatBan,
           long long soTien,
           const std::string& ngayDatCoc = "",
           const std::string& trangThai = DA_DAT_COC);

    std::string getMaDatCoc() const;
    std::string getMaDatBan() const;
    long long getSoTien() const;
    std::string getNgayDatCoc() const;
    std::string getTrangThai() const;

    void setMaDatCoc(const std::string& maDatCoc);
    void setMaDatBan(const std::string& maDatBan);
    void setSoTien(long long soTien);
    void setNgayDatCoc(const std::string& ngayDatCoc);
    void setTrangThai(const std::string& trangThai);

    // Kiem tra toan bo du lieu dat coc.
    bool hopLe() const;

    // Cac ham kiem tra rieng de Services co the tai su dung.
    bool soTienHopLe() const;
    bool trangThaiHopLe() const;
    bool ngayDatCocHopLe() const;
};

#endif