#include "DatCoc.h"

#include <cctype>

const std::string DatCoc::CHUA_DAT_COC = "Chua dat coc";
const std::string DatCoc::DA_DAT_COC = "Da dat coc";
const std::string DatCoc::DA_HOAN_COC = "Da hoan coc";
const std::string DatCoc::MAT_COC = "Mat coc";

namespace {
bool laSo(const std::string& s, std::size_t batDau, std::size_t doDai) {
    if (batDau + doDai > s.size()) return false;
    for (std::size_t i = batDau; i < batDau + doDai; ++i) {
        if (!std::isdigit(static_cast<unsigned char>(s[i]))) return false;
    }
    return true;
}

bool laNamNhuan(int nam) {
    return (nam % 400 == 0) || (nam % 4 == 0 && nam % 100 != 0);
}
}

DatCoc::DatCoc()
    : maDatCoc(""), maDatBan(""), soTien(0), ngayDatCoc(""), trangThai(CHUA_DAT_COC) {}

DatCoc::DatCoc(const std::string& maDatCoc,
               const std::string& maDatBan,
               long long soTien,
               const std::string& ngayDatCoc,
               const std::string& trangThai)
    : maDatCoc(maDatCoc),
      maDatBan(maDatBan),
      soTien(soTien),
      ngayDatCoc(ngayDatCoc),
      trangThai(trangThai) {}

std::string DatCoc::getMaDatCoc() const { return maDatCoc; }
std::string DatCoc::getMaDatBan() const { return maDatBan; }
long long DatCoc::getSoTien() const { return soTien; }
std::string DatCoc::getNgayDatCoc() const { return ngayDatCoc; }
std::string DatCoc::getTrangThai() const { return trangThai; }

void DatCoc::setMaDatCoc(const std::string& ma) { maDatCoc = ma; }
void DatCoc::setMaDatBan(const std::string& ma) { maDatBan = ma; }
void DatCoc::setSoTien(long long tien) { soTien = tien; }
void DatCoc::setNgayDatCoc(const std::string& ngay) { ngayDatCoc = ngay; }
void DatCoc::setTrangThai(const std::string& tt) { trangThai = tt; }

bool DatCoc::trangThaiHopLe() const {
    return trangThai == CHUA_DAT_COC || trangThai == DA_DAT_COC ||
           trangThai == DA_HOAN_COC || trangThai == MAT_COC;
}

bool DatCoc::soTienHopLe() const {
    if (soTien < 0) return false;
    if (trangThai == CHUA_DAT_COC) return soTien == 0;
    if (trangThai == DA_DAT_COC || trangThai == DA_HOAN_COC || trangThai == MAT_COC)
        return soTien > 0;
    return false;
}

bool DatCoc::ngayDatCocHopLe() const {
    // Chua dat coc thi ngay dat coc co the de trong.
    if (trangThai == CHUA_DAT_COC && ngayDatCoc.empty()) return true;
    if (ngayDatCoc.size() != 10 || ngayDatCoc[4] != '-' || ngayDatCoc[7] != '-') return false;
    if (!laSo(ngayDatCoc, 0, 4) || !laSo(ngayDatCoc, 5, 2) || !laSo(ngayDatCoc, 8, 2)) return false;

    const int nam = std::stoi(ngayDatCoc.substr(0, 4));
    const int thang = std::stoi(ngayDatCoc.substr(5, 2));
    const int ngay = std::stoi(ngayDatCoc.substr(8, 2));
    if (nam < 1 || thang < 1 || thang > 12 || ngay < 1) return false;

    const int soNgayTrongThang[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int gioiHan = soNgayTrongThang[thang - 1];
    if (thang == 2 && laNamNhuan(nam)) gioiHan = 29;
    return ngay <= gioiHan;
}

bool DatCoc::hopLe() const {
    if (maDatCoc.empty() || maDatBan.empty()) return false;
    if (!trangThaiHopLe() || !soTienHopLe() || !ngayDatCocHopLe()) return false;
    return true;
}
