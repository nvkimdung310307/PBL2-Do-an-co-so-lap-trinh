#include "KhuVuc.h"

using std::string;

KhuVuc::KhuVuc(){
    makhuvuc = "";
    tenkhuvuc = "";
    mota = "";
}
KhuVuc::KhuVuc(string makhuvuc, string tenkhuvuc, string mota){
    this->makhuvuc = makhuvuc;
    this->tenkhuvuc = tenkhuvuc;
    this->mota = mota;
}
string KhuVuc::getMaKhuVuc() const{
    return makhuvuc;
}
string KhuVuc::getTenKhuVuc() const{
    return tenkhuvuc;
}
string KhuVuc::getMoTa() const{
    return mota;
}
void KhuVuc::setMaKhuVuc(string makhuvuc){
    this->makhuvuc = makhuvuc;
}
void KhuVuc::setTenKhuVuc(string tenkhuvuc){
    this->tenkhuvuc = tenkhuvuc;
}
void KhuVuc::setMoTa(string mota){
    this->mota = mota;
}
bool KhuVuc::hopLe() const{
    return !makhuvuc.empty() && !tenkhuvuc.empty();
}