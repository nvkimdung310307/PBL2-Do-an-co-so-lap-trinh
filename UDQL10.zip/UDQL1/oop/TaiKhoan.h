#ifndef TAIKHOAN_H
#define TAIKHOAN_H
#include <iostream>
#include <string>

class TaiKhoan{
private:
    std::string matk;
    std::string tendangnhap;
    std::string matkhau;
    std::string vaitro;
    std::string manv;
    std::string trangthai;
public:
    TaiKhoan();
    TaiKhoan(std::string matk, std::string tendangnhap, std::string matkhau, std::string vaitro, std::string manv, std::string trangthai);

    std::string getMaTK() const;
    std::string getTenDangNhap() const;
    std::string getMatKhau() const;
    std::string getVaiTro() const;
    std::string getMaNV() const;
    std::string getTrangThai() const;

    void setMaTK(std::string matk);
    void setTenDangNhap(std::string tendangnhap);
    void setMatKhau(std::string matkhau);
    void setVaiTro(std::string vaitro);
    void setMaNV(std::string manv);
    void setTrangThai(std::string trangthai);

    bool hopLe() const;
};

#endif