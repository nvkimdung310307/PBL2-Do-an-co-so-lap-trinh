#include "BoTriBan.h"

BoTriBan::BoTriBan() : cot(0), hang(0), thutu(0) {}
BoTriBan::BoTriBan(const std::string& id, int x, int y, int order)
    : maban(id), cot(x), hang(y), thutu(order) {}

const std::string& BoTriBan::getMaBan() const { return maban; }
int BoTriBan::getCot() const { return cot; }
int BoTriBan::getHang() const { return hang; }
int BoTriBan::getThuTu() const { return thutu; }
void BoTriBan::setCot(int value) { cot = value; }
void BoTriBan::setHang(int value) { hang = value; }
void BoTriBan::setThuTu(int value) { thutu = value; }
bool BoTriBan::hopLe() const {
    return !maban.empty() && cot >= 0 && hang >= 0 && thutu >= 0;
}
