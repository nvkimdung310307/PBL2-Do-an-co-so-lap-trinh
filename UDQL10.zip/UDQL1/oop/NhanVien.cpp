#include "NhanVien.h"
#include <cmath>

using std::string;

NhanVien::NhanVien()
    : NguoiDung(), gioitinh(""), ngaysinh(""), email(""),
      chucvu(""), luong(0), trangthai("")
{
}

NhanVien::NhanVien(string manv, string hoten, string gioitinh, string ngaysinh,
                   string sodienthoai, string email, string chucvu,
                   double luong, string trangthai)
    : NguoiDung(manv, hoten, sodienthoai),
      gioitinh(gioitinh), ngaysinh(ngaysinh), email(email),
      chucvu(chucvu), luong(luong), trangthai(trangthai)
{
}

string NhanVien::getMaNV() const
{
    return getMaDinhDanh();
}

string NhanVien::getGioiTinh() const { return gioitinh; }
string NhanVien::getNgaySinh() const { return ngaysinh; }
string NhanVien::getEmail() const { return email; }
string NhanVien::getChucVu() const { return chucvu; }
double NhanVien::getLuong() const { return luong; }
string NhanVien::getTrangThai() const { return trangthai; }

void NhanVien::setMaNV(string manv) { setMaDinhDanh(manv); }
void NhanVien::setGioiTinh(string value) { gioitinh = value; }
void NhanVien::setNgaySinh(string value) { ngaysinh = value; }
void NhanVien::setEmail(string value) { email = value; }
void NhanVien::setChucVu(string value) { chucvu = value; }
void NhanVien::setLuong(double value) { luong = value; }
void NhanVien::setTrangThai(string value) { trangthai = value; }

bool NhanVien::hopLe() const
{
    return !getMaNV().empty() && !getHoTen().empty() && std::isfinite(luong) && luong >= 0;
}
