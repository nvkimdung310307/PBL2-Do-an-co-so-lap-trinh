#include "DatBan.h"

using std::string;

DatBan::DatBan(){
    madatban = "";
    makh = "";
    maban = "";
    manv = "";
    ngaydat = "";
    giodat = "";
    songuoi = 0;
    trangthai = "";
    ghichu = "";
    ngaytao = "";
    giotao = "";
}
DatBan::DatBan(string madatban, string makh, string maban, string manv, string ngaydat, string giodat, int songuoi, string trangthai, string ghichu, string ngaytao, string giotao){
    this->madatban = madatban;
    this->makh = makh;
    this->maban = maban;
    this->manv = manv;
    this->ngaydat = ngaydat;
    this->giodat = giodat;
    this->songuoi = songuoi;
    this->trangthai = trangthai;
    this->ghichu = ghichu;
    this->ngaytao = ngaytao;
    this->giotao = giotao;
}
string DatBan::getMaDatBan() const{
    return madatban;
}
string DatBan::getMaKH() const{
    return makh;
}
string DatBan::getMaBan() const{
    return maban;
}
string DatBan::getMaNV() const{
    return manv;
}
string DatBan::getNgayDat() const{
    return ngaydat;
}
string DatBan::getGioDat() const{
    return giodat;
}
int DatBan::getSoNguoi() const{
    return songuoi;
}
string DatBan::getTrangThai() const{
    return trangthai;
}
string DatBan::getGhiChu() const{
    return ghichu;
}
string DatBan::getNgayTao() const{
    return ngaytao;
}
string DatBan::getGioTao() const{
    return giotao;
}
void DatBan::setMaDatBan(string madatban){
    this->madatban = madatban;
}
void DatBan::setMaKH(string makh){
    this->makh = makh;
}
void DatBan::setMaBan(string maban){
    this->maban = maban;
}
void DatBan::setMaNV(string manv){
    this->manv = manv;
}
void DatBan::setNgayDat(string ngaydat){
    this->ngaydat = ngaydat;
}
void DatBan::setGioDat(string giodat){
    this->giodat = giodat;
}
void DatBan::setSoNguoi(int songuoi){
    this->songuoi = songuoi;
}
void DatBan::setTrangThai(string trangthai){
    this->trangthai = trangthai;
}
void DatBan::setGhiChu(string ghichu){
    this->ghichu = ghichu;
}
void DatBan::setNgayTao(string ngaytao){
    this->ngaytao = ngaytao;
}
void DatBan::setGioTao(string giotao){
    this->giotao = giotao;
}
bool DatBan::hopLe() const{
    return !madatban.empty() && !makh.empty() && !maban.empty() && !ngaydat.empty() && !giodat.empty() && songuoi > 0;
}