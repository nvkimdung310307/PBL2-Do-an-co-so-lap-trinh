#ifndef DATBAN_H
#define DATBAN_H
#include <iostream>
#include <string>

class DatBan{
private:
    std::string madatban;
    std::string makh;
    std::string maban;
    std::string manv;
    std::string ngaydat;
    std::string giodat;
    int songuoi;
    std::string trangthai;
    std::string ghichu;
    std::string ngaytao;
    std::string giotao;
public:
    DatBan();
    DatBan(std::string madatban, std::string makh, std::string maban, std::string manv, std::string ngaydat, std::string giodat, int songuoi, std::string trangthai, std::string ghichu,
           std::string ngaytao = "", std::string giotao = "");

    std::string getMaDatBan() const;
    std::string getMaKH() const;
    std::string getMaBan() const;
    std::string getMaNV() const;
    std::string getNgayDat() const;
    std::string getGioDat() const;
    int getSoNguoi() const;
    std::string getTrangThai() const;
    std::string getGhiChu() const;
    std::string getNgayTao() const;
    std::string getGioTao() const;

    void setMaDatBan(std::string madatban);
    void setMaKH(std::string makh);
    void setMaBan(std::string maban);
    void setMaNV(std::string manv);
    void setNgayDat(std::string ngaydat);
    void setGioDat(std::string giodat);
    void setSoNguoi(int songuoi);
    void setTrangThai(std::string trangthai);
    void setGhiChu(std::string ghichu);
    void setNgayTao(std::string ngaytao);
    void setGioTao(std::string giotao);

    bool hopLe() const;
};
#endif