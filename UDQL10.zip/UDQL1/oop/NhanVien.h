#ifndef NHANVIEN_H
#define NHANVIEN_H

#include "NguoiDung.h"
#include <string>

class NhanVien : public NguoiDung
{
private:
    std::string gioitinh;
    std::string ngaysinh;
    std::string email;
    std::string chucvu;
    double luong;
    std::string trangthai;

public:
    NhanVien();
    NhanVien(std::string manv, std::string hoten, std::string gioitinh, std::string ngaysinh,
             std::string sodienthoai, std::string email, std::string chucvu,
             double luong, std::string trangthai);

    std::string getMaNV() const;
    std::string getGioiTinh() const;
    std::string getNgaySinh() const;
    std::string getEmail() const;
    std::string getChucVu() const;
    double getLuong() const;
    std::string getTrangThai() const;

    void setMaNV(std::string manv);
    void setGioiTinh(std::string gioitinh);
    void setNgaySinh(std::string ngaysinh);
    void setEmail(std::string email);
    void setChucVu(std::string chucvu);
    void setLuong(double luong);
    void setTrangThai(std::string trangthai);

    bool hopLe() const override;
};

#endif
