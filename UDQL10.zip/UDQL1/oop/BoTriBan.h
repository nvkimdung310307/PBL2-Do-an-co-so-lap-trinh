#ifndef BOTRIBAN_H
#define BOTRIBAN_H
#include <string>

class BoTriBan {
private:
    std::string maban;
    int cot;
    int hang;
    int thutu;
public:
    BoTriBan();
    BoTriBan(const std::string& maban, int cot, int hang, int thutu = 0);

    const std::string& getMaBan() const;
    int getCot() const;
    int getHang() const;
    int getThuTu() const;

    void setCot(int value);
    void setHang(int value);
    void setThuTu(int value);

    bool hopLe() const;
};
#endif
