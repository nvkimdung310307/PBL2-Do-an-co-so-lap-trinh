#ifndef BAN_H
#define BAN_H
#include <iostream>
#include <string>

class Ban{
private:
    std::string maban;
    std::string tenban;
    int socho;
    std::string trangthai;
    std::string makhuvuc;
public:
    Ban();
    Ban(std::string maban, std::string tenban, int socho, std::string trangthai, std::string makhuvuc);

    std::string getMaBan() const;
    std::string getTenBan() const;
    int getSoCho() const;
    std::string getTrangThai() const;
    std::string getMaKhuVuc() const;

    void setMaBan(std::string maban);
    void setTenBan(std::string tenban);
    void setSoCho(int socho);
    void setTrangThai(std::string trangthai);
    void setMaKhuVuc(std::string makhuvuc);

    bool hopLe() const;
};
#endif