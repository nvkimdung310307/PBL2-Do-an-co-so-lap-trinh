#ifndef KHUVUC_H
#define KHUVUC_H
#include <iostream>
#include <string>

class KhuVuc{
private:
    std::string makhuvuc;
    std::string tenkhuvuc;
    std::string mota;
public:
    KhuVuc();
    KhuVuc(std::string makhuvuc, std::string tenkhuvuc, std::string mota);

    std::string getMaKhuVuc() const;
    std::string getTenKhuVuc() const;
    std::string getMoTa() const;

    void setMaKhuVuc(std::string makhuvuc);
    void setTenKhuVuc(std::string tenkhuvuc);
    void setMoTa(std::string mota);

    bool hopLe() const;
};
#endif