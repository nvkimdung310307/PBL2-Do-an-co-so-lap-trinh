#ifndef KHACHHANG_H
#define KHACHHANG_H

#include "NguoiDung.h"
#include <string>

class KhachHang : public NguoiDung
{
public:
    KhachHang();
    KhachHang(std::string makh, std::string hoten, std::string sodienthoai);

    std::string getMaKH() const;
    void setMaKH(std::string makh);

    bool hopLe() const override;
};

#endif
