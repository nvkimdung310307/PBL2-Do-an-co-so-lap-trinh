#include "DangNhapService.h"
#include "PasswordUtils.h"
#include "../services/NhanVienService.h"
#include "../data/TextFileManager.h"
#include <QString>
#include <iostream>
#include <QDateTime>

using namespace std;

DangNhapService::DangNhapService(TaiKhoanService& service) : taiKhoanService(service) {}

const TaiKhoan* DangNhapService::dangNhap(const string& tenDangNhap,const string& matKhau) {
    if(tenDangNhap.empty()||matKhau.empty()) {
        cout<<"Vui long nhap ten dang nhap va mat khau!\n"; return nullptr;
    }
    const TaiKhoan* found=taiKhoanService.timTheoTenDangNhap(tenDangNhap);
    if(!found) { cout<<"Sai ten dang nhap hoac mat khau!\n"; return nullptr; }
    const TaiKhoan snapshot=*found;
    if(snapshot.getTrangThai()!="Hoạt động" && snapshot.getTrangThai()!="HoatDong") {
        cout<<"Tai khoan da bi khoa hoac khong hoat dong!\n"; return nullptr;
    }
    const QString input=QString::fromUtf8(matKhau.c_str());
    const QString stored=QString::fromUtf8(snapshot.getMatKhau().c_str());
    if(!PasswordUtils::verifyPassword(input,stored)) { cout<<"Sai ten dang nhap hoac mat khau!\n"; return nullptr; }
    if(!PasswordUtils::isPasswordHash(stored)) {
        // Nâng cấp mật khẩu dạng cũ sang PBKDF2 ngay sau lần đăng nhập hợp lệ.
        if (!taiKhoanService.nangCapMatKhauCu(snapshot.getMaTK(), matKhau)) {
            cout << "Khong the nang cap mat khau cu. Vui long kiem tra quyen ghi TaiKhoan.txt!\\n";
            return nullptr;
        }
    }
    taiKhoanDangNhap=TaiKhoan(snapshot.getMaTK(),snapshot.getTenDangNhap(),"",snapshot.getVaiTro(),snapshot.getMaNV(),snapshot.getTrangThai());
    // Ghi nhật ký đăng nhập dạng TXT; không lưu mật khẩu.
    vector<TextFileManager::Row> logs;
    if(TextFileManager::read("NhatKyDangNhap.txt",logs)) {
        logs.push_back({snapshot.getMaTK(),snapshot.getTenDangNhap(),snapshot.getVaiTro(),QDateTime::currentDateTime().toString(Qt::ISODate).toStdString()});
        TextFileManager::write("NhatKyDangNhap.txt",logs);
    }
    cout<<"Dang nhap TXT thanh cong!\n";
    return &taiKhoanDangNhap;
}
