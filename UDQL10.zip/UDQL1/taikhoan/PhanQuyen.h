#ifndef PHANQUYEN_H
#define PHANQUYEN_H

#include "../oop/TaiKhoan.h"
#include <QString>
#include <string>

class PhanQuyen
{
public:
    static bool laAdmin(const TaiKhoan& tk);
    static bool laNhanVien(const TaiKhoan& tk);

    // Xac dinh vai tro giao dien tu vai tro tai khoan va chuc vu nhan vien.
    // Tra ve Admin, PhucVu hoac chuoi rong neu chua duoc phan quyen.
    static QString xacDinhVaiTroGiaoDien(const TaiKhoan& tk,
                                         const QString& chucVuNhanVien = QString());

    // Kiem tra tap quyen trang theo mot dau moi duy nhat.
    static bool coQuyenTruyCapTrang(const QString& vaiTro, int pageIndex);

    // Vai tro cua phien dang nhap; mac dinh rong (tu choi moi thao tac can quyen).
    static void datVaiTroHienTai(const QString& vaiTro);
    static void dangXuat();
    static QString vaiTroHienTai();
    // Ma quyen nghiep vu duoc khai bao tap trung trong PhanQuyen.cpp.
    static bool coQuyenNghiepVu(const QString& maQuyen);
};

#endif
