#include "PhanQuyen.h"

namespace { QString g_vaiTroPhien; }

namespace {
std::string normalizedRole(const std::string& role) {
    if (role == "Admin" || role == "Quản lý") return "Admin";
    if (role == "NhanVien" || role == "Nhân viên") return "NhanVien";
    return role;
}
}

bool PhanQuyen::laAdmin(const TaiKhoan& tk)
{
    return normalizedRole(tk.getVaiTro()) == "Admin";
}

bool PhanQuyen::laNhanVien(const TaiKhoan& tk)
{
    return normalizedRole(tk.getVaiTro()) == "NhanVien";
}

QString PhanQuyen::xacDinhVaiTroGiaoDien(const TaiKhoan& tk,
                                         const QString& chucVuNhanVien)
{
    if (laAdmin(tk)) return QStringLiteral("Admin");
    if (!laNhanVien(tk)) return QString();

    const QString job = chucVuNhanVien.trimmed().toCaseFolded();
    // Chức vụ Thu ngân đã được gộp vào Admin; không còn vai trò riêng.
    if (job.contains(QStringLiteral("thu ngân")) ||
        job.contains(QStringLiteral("thu ngan")))
        return QStringLiteral("Admin");

    if (job.contains(QStringLiteral("phục vụ")) ||
        job.contains(QStringLiteral("phuc vu")) ||
        job == QStringLiteral("nhân viên") ||
        job == QStringLiteral("nhan vien"))
        return QStringLiteral("PhucVu");

    return QString();
}

bool PhanQuyen::coQuyenTruyCapTrang(const QString& vaiTro, int pageIndex)
{
    // Chuan hoa ten vai tro de tranh truong hop tai khoan luu "Quan ly"
    // nhung giao dien dang dung "Admin".
    const QString role = vaiTro.trimmed().toCaseFolded();
    const bool isAdmin = role == QStringLiteral("admin") ||
                         role == QStringLiteral("quản lý") ||
                         role == QStringLiteral("quan ly") ||
                         role == QStringLiteral("quanly");
    const bool isOrder = role == QStringLiteral("phucvu") ||
                         role == QStringLiteral("phục vụ") ||
                         role == QStringLiteral("phuc vu");

    // Trang 11 la trang Admin theo doi danh sach dat ban.
    if (isAdmin) {
        // Admin duoc vao tat ca trang quan tri dang co tren menu.
        return pageIndex == 0 || pageIndex == 3 || pageIndex == 4 ||
               pageIndex == 6 || pageIndex == 7 || pageIndex == 8 ||
               pageIndex == 9 || pageIndex == 10 || pageIndex == 11;
    }

    if (isOrder) {
        // Trang POS duoc dung de goi mon; cac nut tach/gop va thanh toan
        // ben trong trang van co kiem tra quyen Thu ngan rieng.
        return pageIndex == 0 || pageIndex == 1 || pageIndex == 2 || pageIndex == 5;
    }

    return false;
}


void PhanQuyen::datVaiTroHienTai(const QString& vaiTro)
{
    if (vaiTro == QStringLiteral("Admin") ||
        vaiTro == QStringLiteral("PhucVu"))
        g_vaiTroPhien = vaiTro;
    else
        g_vaiTroPhien.clear();
}

void PhanQuyen::dangXuat()
{
    g_vaiTroPhien.clear();
}


bool PhanQuyen::coQuyenNghiepVu(const QString& maQuyen)
{
    // Khong co phien dang nhap => tu choi. Cac tac vu noi bo khoi dong/tu dong
    // (dong bo trang thai theo thoi gian) khong goi ham phan quyen nay.
    if (g_vaiTroPhien.isEmpty()) return false;
    if (g_vaiTroPhien == QStringLiteral("Admin")) return true;

    if (maQuyen == QStringLiteral("KHACH_HANG"))
        return g_vaiTroPhien == QStringLiteral("PhucVu");

    // Thu ngan duoc xac nhan hoan tat luot su dung sau khi da nhan thanh toan.
    // Nhan vien order xac nhan khach den; ca hai thao tac dung cung DatBanService.
    if (maQuyen == QStringLiteral("DAT_BAN"))
        return g_vaiTroPhien == QStringLiteral("PhucVu");

    if (maQuyen == QStringLiteral("CHUYEN_BAN") ||
        maQuyen == QStringLiteral("CAP_NHAT_TRANG_THAI_BAN"))
        return g_vaiTroPhien == QStringLiteral("PhucVu");

    if (maQuyen == QStringLiteral("THANH_TOAN"))
        return g_vaiTroPhien == QStringLiteral("Admin");

    // Quan ly danh muc, tai khoan, nhan vien, bao cao va thao tac khac: Admin.
    return false;
}
