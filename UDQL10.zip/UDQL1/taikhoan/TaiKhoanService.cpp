#include "TaiKhoanService.h"
#include "PhanQuyen.h"
#include "PasswordUtils.h"
#include "../data/TextFileManager.h"
#include "../services/NhanVienService.h"
#include <QString>
#include <algorithm>
#include <cstdlib>
#include <cstdio>
#include <iostream>

using namespace std;
namespace {
const char* FILE_NAME = "TaiKhoan.txt";
QString qstr(const string& s) { return QString::fromUtf8(s.c_str()); }
string roleApp(const string& r) {
    if (r == "Quản lý" || r == "Admin") return "Admin";
    if (r == "Nhân viên" || r == "NhanVien") return "NhanVien";
    return r;
}
string statusApp(const string& s) {
    if (s == "Hoạt động" || s == "HoatDong") return "Hoạt động";
    if (s == "Bị khóa" || s == "BiKhoa" || s == "Bi khoa") return "Bị khóa";
    return s;
}
bool isAdmin(const TaiKhoan& tk) { return roleApp(tk.getVaiTro()) == "Admin"; }
bool isActive(const TaiKhoan& tk) { return statusApp(tk.getTrangThai()) == "Hoạt động"; }
}

bool TaiKhoanService::napDanhSachTXT() const {
    vector<TextFileManager::Row> rows;
    if (!TextFileManager::read(FILE_NAME, rows)) return false;
    vector<TaiKhoan> fresh;
    for (const auto& r : rows) if (r.size() >= 6)
        fresh.emplace_back(r[0],r[1],r[2],roleApp(r[3]),r[4],statusApp(r[5]));
    danhSachTaiKhoan.swap(fresh);
    return true;
}

bool TaiKhoanService::ghiDanhSachTXT() const {
    vector<TextFileManager::Row> rows;
    for (const auto& tk : danhSachTaiKhoan)
        rows.push_back({tk.getMaTK(),tk.getTenDangNhap(),tk.getMatKhau(),roleApp(tk.getVaiTro()),tk.getMaNV(),statusApp(tk.getTrangThai())});
    return TextFileManager::write(FILE_NAME, rows);
}

bool TaiKhoanService::taiKhoanTonTai(const string& maTK) const { return timTheoMa(maTK) != nullptr; }
const vector<TaiKhoan>& TaiKhoanService::getDanhSachTaiKhoan() const { napDanhSachTXT(); return danhSachTaiKhoan; }

const TaiKhoan* TaiKhoanService::timTheoMa(const string& maTK) const {
    if (!napDanhSachTXT()) return nullptr;
    for (const auto& tk : danhSachTaiKhoan) if (tk.getMaTK()==maTK) return &tk;
    return nullptr;
}
const TaiKhoan* TaiKhoanService::timTheoTenDangNhap(const string& ten) const {
    if (!napDanhSachTXT()) return nullptr;
    for (const auto& tk : danhSachTaiKhoan) if (QString::compare(qstr(tk.getTenDangNhap()),qstr(ten),Qt::CaseInsensitive)==0) return &tk;
    return nullptr;
}

string TaiKhoanService::taoMaTaiKhoan() const {
    if (!napDanhSachTXT()) return "";
    int maxId=0;
    for(const auto& tk:danhSachTaiKhoan){const auto& id=tk.getMaTK();if(id.rfind("TK",0)==0)maxId=max(maxId,atoi(id.substr(2).c_str()));}
    char buf[32]; snprintf(buf,sizeof(buf),"TK%06d",maxId+1); return buf;
}

bool TaiKhoanService::themTaiKhoan(const TaiKhoan& tk) {
    if (!PhanQuyen::coQuyenNghiepVu(QStringLiteral("QUAN_LY_DANH_MUC"))) return false;
    if (!tk.hopLe() || tk.getMatKhau().size()<10 || timTheoMa(tk.getMaTK()) || timTheoTenDangNhap(tk.getTenDangNhap())) return false;
    NhanVienService employeeService;
    if (!employeeService.timTheoMa(tk.getMaNV())) return false;
    if (roleApp(tk.getVaiTro())!="Admin" && roleApp(tk.getVaiTro())!="NhanVien") return false;
    if (statusApp(tk.getTrangThai())!="Hoạt động" && statusApp(tk.getTrangThai())!="Bị khóa") return false;
    if (!napDanhSachTXT()) return false;
    danhSachTaiKhoan.emplace_back(tk.getMaTK(),tk.getTenDangNhap(),PasswordUtils::hashPassword(qstr(tk.getMatKhau())).toUtf8().toStdString(),roleApp(tk.getVaiTro()),tk.getMaNV(),statusApp(tk.getTrangThai()));
    return ghiDanhSachTXT();
}

bool TaiKhoanService::xoaTaiKhoan(const string& maTK) {
    if (!PhanQuyen::coQuyenNghiepVu(QStringLiteral("QUAN_LY_DANH_MUC"))) return false;
    if (!napDanhSachTXT()) return false;
    auto it=find_if(danhSachTaiKhoan.begin(),danhSachTaiKhoan.end(),[&](const TaiKhoan& t){return t.getMaTK()==maTK;});
    if(it==danhSachTaiKhoan.end()) return false;
    if(isAdmin(*it)&&isActive(*it)) {
        int activeAdmins=0; for(const auto& t:danhSachTaiKhoan) if(isAdmin(t)&&isActive(t)) ++activeAdmins;
        if(activeAdmins<=1) return false;
    }
    danhSachTaiKhoan.erase(it); return ghiDanhSachTXT();
}

bool TaiKhoanService::capLaiMatKhau(const string& maTK,const string& moi) {
    if(moi.size() < 10 || !napDanhSachTXT()) return false;
    for(auto& tk:danhSachTaiKhoan) if(tk.getMaTK()==maTK && isActive(tk)) {
        tk.setMatKhau(PasswordUtils::hashPassword(qstr(moi)).toUtf8().toStdString()); return ghiDanhSachTXT();
    }
    return false;
}

bool TaiKhoanService::nangCapMatKhauCu(const string& maTK, const string& matKhauCu) {
    // Ham nay chi duoc goi sau khi dang nhap da xac thuc mat khau cu.
    // Khong ap dung do dai toi thieu o day de tai khoan cu van duoc nang cap,
    // nhung van giu nguyen chinh sach >= 10 ky tu cho cap lai/doi mat khau moi.
    if (matKhauCu.empty() || !napDanhSachTXT()) return false;
    for (auto& tk : danhSachTaiKhoan) {
        if (tk.getMaTK() != maTK || !isActive(tk)) continue;
        const QString stored = qstr(tk.getMatKhau());
        if (PasswordUtils::isPasswordHash(stored) || stored != qstr(matKhauCu))
            return false;
        tk.setMatKhau(PasswordUtils::hashPassword(stored).toUtf8().toStdString());
        return ghiDanhSachTXT();
    }
    return false;
}

bool TaiKhoanService::doiMatKhau(const string& maTK,const string& cu,const string& moi) {
    if(moi.size() < 10 || !napDanhSachTXT()) return false;
    for(auto& tk:danhSachTaiKhoan) if(tk.getMaTK()==maTK && isActive(tk)) {
        if(!PasswordUtils::verifyPassword(qstr(cu),qstr(tk.getMatKhau()))) return false;
        tk.setMatKhau(PasswordUtils::hashPassword(qstr(moi)).toUtf8().toStdString()); return ghiDanhSachTXT();
    }
    return false;
}

bool TaiKhoanService::capNhatVaiTro(const string& maTK,const string& vaiTroMoi) {
    const string role=roleApp(vaiTroMoi); if(role!="Admin"&&role!="NhanVien") return false;
    if(!napDanhSachTXT()) return false;
    for(auto& tk:danhSachTaiKhoan) if(tk.getMaTK()==maTK) {
        if(isAdmin(tk)&&isActive(tk)&&role!="Admin") { int n=0;for(const auto& t:danhSachTaiKhoan)if(isAdmin(t)&&isActive(t))++n;if(n<=1)return false; }
        tk.setVaiTro(role); return ghiDanhSachTXT();
    }
    return false;
}

bool TaiKhoanService::capNhatTrangThai(const string& maTK,const string& trangThaiMoi) {
    const string status=statusApp(trangThaiMoi);if(status!="Hoạt động"&&status!="Bị khóa")return false;
    if(!napDanhSachTXT())return false;
    for(auto& tk:danhSachTaiKhoan)if(tk.getMaTK()==maTK){
        if(isAdmin(tk)&&isActive(tk)&&status!="Hoạt động"){int n=0;for(const auto& t:danhSachTaiKhoan)if(isAdmin(t)&&isActive(t))++n;if(n<=1)return false;}
        tk.setTrangThai(status);return ghiDanhSachTXT();
    }
    return false;
}

void TaiKhoanService::hienThiDanhSach() const {
    for(const auto& tk:getDanhSachTaiKhoan()) cout<<tk.getMaTK()<<" | "<<tk.getTenDangNhap()<<" | "<<tk.getVaiTro()<<" | "<<tk.getMaNV()<<" | "<<tk.getTrangThai()<<'\n';
}
