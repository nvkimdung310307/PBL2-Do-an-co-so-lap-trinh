#include "DangNhapWidget.h"

#include <QWidget>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QComboBox>
#include <QLineEdit>
#include <QMessageBox>
#include <QObject>

#include "taikhoan/TaiKhoanService.h"
#include "taikhoan/DangNhapService.h"
#include "taikhoan/PhanQuyen.h"
#include "services/NhanVienService.h"

namespace {
QLabel *loginLabel(const QString &text, const QString &id = QString()) {
    auto *label = new QLabel(text);
    if (!id.isEmpty()) label->setObjectName(id);
    return label;
}
}

LoginWidget::LoginWidget(const QString &styleSheet, QWidget *parent)
    : QMainWindow(parent) {
    setWindowTitle("Đăng nhập | Dzgn");
    resize(520, 590);
    setMinimumSize(480, 560);
    setStyleSheet(styleSheet);

    auto *root = new QWidget;
    root->setObjectName("root");
    auto *layout = new QVBoxLayout(root);
    layout->setContentsMargins(42, 32, 42, 30);
    layout->setSpacing(13);
    layout->addWidget(loginLabel("Nhà Hàng", "brand"), 0, Qt::AlignHCenter);
    layout->addWidget(loginLabel("Chào mừng bạn quay lại", "pageTitle"), 0, Qt::AlignHCenter);
    layout->addWidget(loginLabel("Đăng nhập vào hệ thống quản lý Đặt bàn Nhà Hàng", "muted"), 0, Qt::AlignHCenter);
    //layout->addWidget(loginLabel("Tài khoản Admin/Nhân viên được tạo ngay trong phần mềm. Không cần tài khoản SSMS.", "muted"), 0, Qt::AlignHCenter);
    layout->addSpacing(8);

    layout->addWidget(loginLabel("Đăng nhập với vai trò"));
    auto *roleBox = new QComboBox;
    roleBox->addItem("Quản trị viên (Admin)", "Admin");
    roleBox->addItem("Phục Vụ", "PhucVu");
    roleBox->setMinimumHeight(44);
    layout->addWidget(roleBox);

    layout->addWidget(loginLabel("Tên đăng nhập"));
    auto *username = new QLineEdit;
    username->setPlaceholderText("Nhập tên đăng nhập");
    username->setMinimumHeight(44);
    layout->addWidget(username);

    layout->addWidget(loginLabel("Mật khẩu"));
    auto *password = new QLineEdit;
    passwordEdit = password;
    password->setPlaceholderText("Nhập mật khẩu");
    password->setEchoMode(QLineEdit::Password);
    password->setMinimumHeight(44);
    layout->addWidget(password);

    auto *showPassword = new QPushButton("Hiện mật khẩu");
    showPassword->setObjectName("soft");
    showPassword->setCheckable(true);
    QObject::connect(showPassword, &QPushButton::toggled, password, [password, showPassword](bool visible) {
        password->setEchoMode(visible ? QLineEdit::Normal : QLineEdit::Password);
        showPassword->setText(visible ? "Ẩn mật khẩu" : "Hiện mật khẩu");
    });
    layout->addWidget(showPassword, 0, Qt::AlignRight);

    auto *loginButton = new QPushButton("Đăng nhập");
    loginButton->setObjectName("primary");
    loginButton->setMinimumHeight(46);
    layout->addWidget(loginButton);
    auto *status = loginLabel("", "muted");
    statusLabel = status;
    status->setAlignment(Qt::AlignCenter);
    layout->addWidget(status);
    layout->addStretch();
    layout->addWidget(loginLabel("BPL2  •  Ứng dụng Quản lí Đặt bàn Nhà Hàng", "muted"), 0, Qt::AlignHCenter);
    setCentralWidget(root);

    accountService = new TaiKhoanService;
    loginService = new DangNhapService(*accountService);
    QObject::connect(loginButton, &QPushButton::clicked, this,
        [this, roleBox, username, password, status]() {
        if (username->text().trimmed().isEmpty() || password->text().isEmpty()) {
            QMessageBox::warning(this, "Thiếu thông tin", "Vui lòng nhập tên đăng nhập và mật khẩu.");
            return;
        }

        const TaiKhoan *account = loginService->dangNhap(
            username->text().trimmed().toStdString(), password->text().toStdString());
        if (!account) {
            QMessageBox::warning(this, "Đăng nhập thất bại",
                "Tên đăng nhập hoặc mật khẩu không đúng, hoặc tài khoản không hoạt động.");
            password->clear();
            password->setFocus();
            return;
        }

        QString employeeJob;
        if (PhanQuyen::laNhanVien(*account)) {
            NhanVienService employees;
            const NhanVien *employee = employees.timTheoMa(account->getMaNV());
            if (!employee) {
                QMessageBox::warning(this, "Không xác định được vai trò",
                    "Không đọc được chức vụ nhân viên từ NhanVien.txt.");
                password->clear();
                return;
            }
            employeeJob = QString::fromUtf8(employee->getChucVu().c_str());
        }

        const QString effectiveRole = PhanQuyen::xacDinhVaiTroGiaoDien(*account, employeeJob);
        if (effectiveRole.isEmpty()) {
            QMessageBox::warning(this, "Chức vụ chưa được phân quyền",
                "Chức vụ của tài khoản chưa được gán quyền Admin hoặc Phục Vụ. "
                "Admin hãy cập nhật chức vụ nhân viên trong NhanVien.txt.");
            password->clear();
            return;
        }

        const QString requestedRole = roleBox->currentData().toString();
        if (effectiveRole != requestedRole) {
            QMessageBox::warning(this, "Sai vai trò đăng nhập",
                requestedRole == "Admin"
                    ? "Tài khoản này không có quyền Quản trị viên."
                    : "Tài khoản này không được phân quyền Phục Vụ. Hãy chọn đúng vai trò theo chức vụ nhân viên.");
            password->clear();
            return;
        }

        password->clear();
        status->clear();
        if (onLoginSuccess) onLoginSuccess(username->text().trimmed(), effectiveRole);
    });
    QObject::connect(password, &QLineEdit::returnPressed, loginButton, &QPushButton::click);
    QObject::connect(username, &QLineEdit::returnPressed, password, [password]() { password->setFocus(); });
}

LoginWidget::~LoginWidget() {
    delete loginService;
    delete accountService;
}

void LoginWidget::setStatusMessage(const QString &message) {
    if (statusLabel) statusLabel->setText(message);
}

void LoginWidget::clearPassword() {
    if (passwordEdit) passwordEdit->clear();
}
