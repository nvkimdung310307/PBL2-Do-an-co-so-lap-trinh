#pragma once

#include <QMainWindow>
#include <QString>
#include <functional>

class QLabel;
class QLineEdit;
class TaiKhoanService;
class DangNhapService;

class LoginWidget : public QMainWindow {
public:
    explicit LoginWidget(const QString &styleSheet, QWidget *parent = nullptr);
    ~LoginWidget() override;
    std::function<void(const QString &, const QString &)> onLoginSuccess;
    void setStatusMessage(const QString &message);
    void clearPassword();
private:
    QLabel *statusLabel = nullptr;
    QLineEdit *passwordEdit = nullptr;
    TaiKhoanService *accountService = nullptr;
    DangNhapService *loginService = nullptr;
};
