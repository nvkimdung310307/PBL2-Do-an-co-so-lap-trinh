#include <QMainWindow>
#include <QWidget>
#include <QFrame>
#include <QLabel>
#include <QPushButton>
#include <QCheckBox>
#include <QLineEdit>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QStackedWidget>
#include <QTableWidget>
#include <QToolButton>
#include <QAbstractItemView>
#include <QRegularExpression>
#include <QLocale>
#include <QHeaderView>
#include <QMessageBox>
#include <QDialog>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QDate>
#include <QDateTime>
#include <QDateEdit>
#include <QTimeEdit>
#include <QComboBox>
#include <QInputDialog>
#include <QGraphicsDropShadowEffect>
#include <QColor>
#include <QTime>
#include <QSpinBox>
#include <QDoubleSpinBox>
#include <QScrollArea>
#include <QSizePolicy>
#include <QTimer>
#include <QMap>
#include <QSet>
#include <memory>
#include <QVariant>
#include <QObject>
#include <functional>
#include <utility>
#include "taikhoan/TaiKhoanService.h"
#include "taikhoan/DangNhapService.h"
#include "taikhoan/PhanQuyen.h"
#include "oop/TaiKhoan.h"
#include "services/GiaoDienDataService.h"
#include "oop/DatBan.h"
#include "oop/DatCoc.h"
#include "services/DatCocService.h"
#include "oop/KhachHang.h"
#include "oop/NhanVien.h"
#include "services/BanService.h"
#include "services/KhuVucService.h"
#include "services/BoTriBanService.h"
#include "services/DatBanService.h"
#include "services/ChuyenBanService.h"
#include "services/KhachHangService.h"
#include "services/NhanVienService.h"
#include "widgets/login/DangNhapWidget.h"
#include "widgets/admin/AdminWidget.h"
#include "widgets/nhanvien/NhanVienWidget.h"
#include "widgets/common/RestaurantWindowFactory.h"
#include <vector>
#include <string>

#include <algorithm>
#include <QStringList>

#include "widgets/common/RestaurantWindowFactory.h"
QWidget * RestaurantWindow::makeBookingPage(){
        auto *w = new QWidget;
        auto *v = createPageTemplate(w);
        addPageHeader(v, "Quản lý đặt bàn",
                      "Tạo lượt đặt bàn và lưu trực tiếp vào file TXT");
        auto*f=panel(); auto*l=new QVBoxLayout(f); auto*form=new QGridLayout;
        auto*name=new QLineEdit; name->setPlaceholderText("Tên khách hàng");
        auto*phone=new QLineEdit; phone->setPlaceholderText("Số điện thoại");
        auto*createdAt=new QLineEdit(QDateTime::currentDateTime().toString("dd/MM/yyyy HH:mm"));
        createdAt->setReadOnly(true);
        createdAt->setToolTip("Thời điểm hệ thống ghi nhận tạo lượt đặt bàn.");
        const QDateTime defaultArrival=QDateTime::currentDateTime().addSecs(60*60);
        auto*date=new QDateEdit(defaultArrival.date()); date->setCalendarPopup(true); date->setMinimumDate(QDate::currentDate());
        auto*time=new QTimeEdit(defaultArrival.time()); time->setDisplayFormat("HH:mm");
        time->setToolTip("Giờ khách dự kiến đến nhà hàng.");
        auto*count=new QSpinBox; count->setRange(1,30); count->setValue(2);
        auto*tableBox=new QComboBox;
        auto*note=new QLineEdit; note->setPlaceholderText("Ghi chú (không bắt buộc)");
        // Giữ nguyên thông tin khách hàng và số điện thoại của biểu mẫu cũ;
        // các trường thời gian mới được bổ sung bên dưới, không thay thế trường cũ.
        form->addWidget(label("Khách hàng"),0,0); form->addWidget(name,1,0);
        form->addWidget(label("Điện thoại"),0,1); form->addWidget(phone,1,1);
        form->addWidget(label("Thời điểm tạo (tự động)"),2,0); form->addWidget(createdAt,3,0);
        form->addWidget(label("Ngày khách đến"),2,1); form->addWidget(date,3,1);
        form->addWidget(label("Giờ khách đến"),4,0); form->addWidget(time,5,0);
        form->addWidget(label("Số người"),4,1); form->addWidget(count,5,1);
        form->addWidget(label("Bàn phù hợp"),6,0); form->addWidget(tableBox,7,0,1,2);
        form->addWidget(label("Ghi chú"),8,0); form->addWidget(note,9,0,1,2); l->addLayout(form);
        auto*buttons=new QHBoxLayout; auto*refresh=new QPushButton("↻  Tải bàn phù hợp"); refresh->setObjectName("soft");
        auto*save=new QPushButton("＋  Tạo đặt bàn"); save->setObjectName("primary"); buttons->addWidget(refresh); buttons->addWidget(save); buttons->addStretch(); l->addLayout(buttons);
        auto*hint=label("Chọn ngày, giờ khách đến và số người. Bàn đang phục vụ vẫn có thể được đặt cho lượt sau nếu không trùng lịch; hệ thống ưu tiên giữ bàn trước 30 phút.","muted"); l->addWidget(hint);
        auto loadTables=[this,tableBox,date,time,count,hint](){
            tableBox->clear();
            const auto tables=uiRowsFrom(BanService().getDanhSachBan());
            const auto bookings=uiRowsFrom(DatBanService().getDanhSachDatBan());
            int available=0;
            for (const auto &table : tables) {
                if (table.size()<5) continue;
                const QString id=GiaoDienDataService::value(table,0), name=GiaoDienDataService::value(table,1);
                const int seats=GiaoDienDataService::value(table,2).toInt();
                const QString status=GiaoDienDataService::value(table,3), areaId=GiaoDienDataService::value(table,4);
                // Cho phep dat truoc tren ban dang phuc vu; chi loai ban bao tri.
                // Trang thai vat ly cua ban khong bi doi khi tao lich dat tuong lai.
                if (seats<count->value() || status==QStringLiteral("Bảo trì") ||
                    status==QStringLiteral("Bao tri")) continue;
                QString areaName=GiaoDienDataService::areaName(areaId);
                bool occupied=false;
                for (const auto &booking : bookings) {
                    if (booking.size()<8 || GiaoDienDataService::value(booking,2)!=id || GiaoDienDataService::value(booking,4)!=date->date().toString("yyyy-MM-dd") || !GiaoDienDataService::activeBooking(GiaoDienDataService::value(booking,7))) continue;
                    const QString bookingStatus=GiaoDienDataService::value(booking,7);
                    if (bookingStatus==QStringLiteral("Đã nhận bàn") || bookingStatus==QStringLiteral("Da nhan ban") ||
                        bookingStatus==QStringLiteral("Đang sử dụng") || bookingStatus==QStringLiteral("Dang su dung")) continue;
                    const QTime bookedTime=QTime::fromString(GiaoDienDataService::value(booking,5).left(5),"HH:mm");
                    if (bookedTime.isValid() && qAbs(bookedTime.msecsTo(time->time()))<120*60*1000) { occupied=true; break; }
                }
                if (occupied) continue;
                const QString usage = (status==QStringLiteral("Đang sử dụng") || status==QStringLiteral("Dang su dung"))
                    ? QString(" · đang phục vụ khách") : QString();
                tableBox->addItem(QString("%1 · %2 · %3 chỗ%4").arg(name,areaName).arg(seats).arg(usage),id);
                ++available;
            }
            hint->setText(available?QString("Có %1 bàn phù hợp.").arg(available):"Không có bàn phù hợp với ngày, giờ và số người đã chọn.");
        };
        connect(refresh,&QPushButton::clicked,w,loadTables); connect(date,&QDateEdit::dateChanged,w,[loadTables](const QDate&){loadTables();}); connect(time,&QTimeEdit::timeChanged,w,[loadTables](const QTime&){loadTables();}); connect(count,QOverload<int>::of(&QSpinBox::valueChanged),w,[loadTables](int){loadTables();});
        auto reservationReloader = std::make_shared<std::function<void()>>();
        connect(save,&QPushButton::clicked,w,[this,name,phone,createdAt,date,time,count,tableBox,note,loadTables,hint,reservationReloader](){
            const QString ten=name->text().trimmed(),sdt=phone->text().trimmed(),maBan=tableBox->currentData().toString();
            if(ten.isEmpty()||sdt.isEmpty()||maBan.isEmpty()){QMessageBox::warning(this,"Thiếu thông tin","Nhập tên, số điện thoại và chọn bàn phù hợp.");return;}
            if(sdt.size()<9||sdt.size()>15){QMessageBox::warning(this,"Số điện thoại không hợp lệ","Số điện thoại phải có từ 9 đến 15 ký tự.");return;}
            KhachHangService customerService;
            QString maKH;
            const KhachHang* existingCustomer = customerService.timTheoSoDienThoai(sdt.toStdString());
            if (existingCustomer) {
                const std::string customerId = existingCustomer->getMaKH();
                maKH = QString::fromUtf8(customerId.c_str());
                const KhachHang updated(customerId,ten.toStdString(),sdt.toStdString());
                if (!customerService.suaKhachHang(customerId,updated)) {
                    QMessageBox::critical(this,"Lỗi lưu khách hàng","Không thể cập nhật thông tin khách hàng."); return;
                }
            } else {
                maKH = QString::fromStdString(customerService.taoMaKhachHang());
                if (!customerService.themKhachHang(KhachHang(maKH.toStdString(),ten.toStdString(),sdt.toStdString()))) {
                    QMessageBox::critical(this,"Lỗi lưu khách hàng","Không thể tạo hồ sơ khách hàng mới."); return;
                }
            }
            const QDateTime arrival(date->date(), time->time());
            if (arrival <= QDateTime::currentDateTime()) {
                QMessageBox::warning(this,"Thời gian không hợp lệ","Giờ khách đến phải nằm trong tương lai. Thời điểm tạo đặt bàn được hệ thống ghi nhận riêng.");
                return;
            }
            const QString selectedTableId = tableBox->currentData().toString();
            loadTables();
            const int refreshedTableIndex = tableBox->findData(selectedTableId);
            if (selectedTableId.isEmpty() || refreshedTableIndex < 0) {
                QMessageBox::warning(this, "Bàn không còn trống",
                    "Bàn bạn chọn không còn phù hợp hoặc lịch đặt đã bị trùng. Hãy chọn lại bàn.");
                return;
            }
            tableBox->setCurrentIndex(refreshedTableIndex);
            DatBanService bookingService;
            const QString maDB=QString::fromStdString(bookingService.taoMaDatBan());
            const QString maNV=GiaoDienDataService::employeeId(user);
            const QDateTime createdNow = QDateTime::currentDateTime();
            createdAt->setText(createdNow.toString("dd/MM/yyyy HH:mm"));
            const QString ngay=date->date().toString("yyyy-MM-dd"), gio=time->time().toString("HH:mm");
            const QString ngayTao=createdNow.date().toString("yyyy-MM-dd"), gioTao=createdNow.time().toString("HH:mm");
            DatBan booking(GiaoDienDataService::utf8(maDB),GiaoDienDataService::utf8(maKH),GiaoDienDataService::utf8(maBan),GiaoDienDataService::utf8(maNV),GiaoDienDataService::utf8(ngay),GiaoDienDataService::utf8(gio),count->value(),"Chờ đến",GiaoDienDataService::utf8(note->text().trimmed()),GiaoDienDataService::utf8(ngayTao),GiaoDienDataService::utf8(gioTao));
            if (!bookingService.themDatBan(booking)) { QMessageBox::critical(this,"Không tạo được đặt bàn","Không thể tạo lượt đặt. Kiểm tra mã khách, nhân viên, bàn và trạng thái bàn hiện tại."); return; }
            // Chot muc coc theo khu vuc tai thoi diem tao phieu; khong bi anh huong khi Admin doi gia sau nay.
            if (!GiaoDienDataService::chotMucCocChoDatBan(
                    GiaoDienDataService::utf8(maDB), GiaoDienDataService::utf8(maBan))) {
                QMessageBox::warning(this,"Lưu mức cọc","Đặt bàn đã tạo nhưng chưa lưu được mức cọc chụp tại thời điểm tạo. Vui lòng báo Admin kiểm tra.");
            }
            QMessageBox::information(this,"Đặt bàn thành công","Đã lưu lượt đặt "+maDB+" vào file TXT. Lịch đặt bàn đã được cập nhật bên dưới.");
            name->clear();phone->clear();note->clear();loadTables();if(*reservationReloader)(*reservationReloader)();
        });
        v->addWidget(f);

        // Danh sach dat ban de nhan vien xac nhan khach den va cap nhat trang thai ban.
        auto *reservationPanel = panel();
        auto *reservationLayout = new QVBoxLayout(reservationPanel);
        auto *reservationHeader = new QHBoxLayout;
        reservationHeader->addWidget(label("Lịch đặt bàn / Xác nhận khách đến", "pageTitle"));
        reservationHeader->addStretch();
        auto *refreshReservations = new QPushButton("↻ Làm mới lịch");
        refreshReservations->setObjectName("soft");
        auto *confirmArrival = new QPushButton("✓ Xác nhận khách đến / Nhận bàn");
        confirmArrival->setObjectName("primary");
        auto *cancelReservation = new QPushButton("✕ Hủy bàn");
        cancelReservation->setObjectName("danger");
        reservationHeader->addWidget(refreshReservations);
        reservationHeader->addWidget(confirmArrival);
        reservationHeader->addWidget(cancelReservation);
        reservationLayout->addLayout(reservationHeader);
        reservationLayout->addWidget(label("Chọn lịch 'Đã đặt' để xác nhận khách đến. Khách được trễ tối đa 10 phút sau giờ hẹn; quá thời gian này hệ thống tự chuyển 'Không đến' và giải phóng bàn nếu không có lượt phục vụ/hóa đơn đang mở.", "muted"));
        auto *reservationTable = new QTableWidget(0, 8);
        reservationTable->setHorizontalHeaderLabels({"Mã lượt", "Khách hàng", "Bàn", "Thời điểm nhận", "Ngày khách đến", "Giờ khách đến", "Số người", "Trạng thái"});
        reservationTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        reservationTable->setSelectionBehavior(QAbstractItemView::SelectRows);
        reservationTable->setSelectionMode(QAbstractItemView::SingleSelection);
        reservationTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
        reservationTable->verticalHeader()->setVisible(false);
        reservationTable->setMinimumHeight(190);
        reservationLayout->addWidget(reservationTable);
        auto *reservationEmptyLabel = label("Chưa có lịch đặt bàn trong file dữ liệu. Hãy tạo đặt bàn ở biểu mẫu phía trên.", "muted");
        reservationEmptyLabel->setAlignment(Qt::AlignCenter);
        reservationEmptyLabel->setWordWrap(true);
        reservationEmptyLabel->setMinimumHeight(42);
        reservationLayout->addWidget(reservationEmptyLabel);
        v->addWidget(reservationPanel, 1);

        auto loadReservations = [this, reservationTable, reservationEmptyLabel]() {
            // Cap nhat tu dong trang thai cho den/khong den moi lan nap danh sach.
            DatBanService().capNhatTrangThaiTheoThoiGian();
            reservationTable->setRowCount(0);
            reservationEmptyLabel->setVisible(false);
            auto bookings=uiRowsFrom(DatBanService().getDanhSachDatBan());
            std::stable_sort(bookings.begin(),bookings.end(),[](const auto&a,const auto&b){
                if(a.size()<6||b.size()<6)return false;
                const QString da=QString::fromUtf8((a[4]+" "+a[5]).c_str());
                const QString db=QString::fromUtf8((b[4]+" "+b[5]).c_str());
                return da>db;
            });
            int loadedRows=0;
            for(const auto &booking:bookings) {
                if(booking.size()<8) continue;
                ++loadedRows;
                const int row=reservationTable->rowCount(); reservationTable->insertRow(row);
                const QString customer=GiaoDienDataService::customerName(GiaoDienDataService::value(booking,1));
                const QString table=GiaoDienDataService::tableName(GiaoDienDataService::value(booking,2));
                const QString createdDate=GiaoDienDataService::value(booking,9);
                const QString createdTime=GiaoDienDataService::value(booking,10);
                const QString createdAtText = createdDate.isEmpty() ? "Dữ liệu cũ" :
                    QDate::fromString(createdDate,"yyyy-MM-dd").toString("dd/MM/yyyy")+" "+createdTime;
                const QString arrivalDate=QDate::fromString(GiaoDienDataService::value(booking,4),"yyyy-MM-dd").toString("dd/MM/yyyy");
                const QStringList cells={GiaoDienDataService::value(booking,0),customer,table,createdAtText,arrivalDate,GiaoDienDataService::value(booking,5),GiaoDienDataService::value(booking,6),GiaoDienDataService::value(booking,7)};
                for(int col=0;col<8;++col){auto *item=new QTableWidgetItem(cells[col]);if(col==0)item->setData(Qt::UserRole,cells[0]);reservationTable->setItem(row,col,item);}
                const QString status=cells[7];
                const QColor bg =
                    status==QStringLiteral("Đã nhận bàn") ? QColor("#F3C8C7") :
                    status==QStringLiteral("Đã đặt") ? QColor("#F8E3AF") :
                    status==QStringLiteral("Chờ đến") || status==QStringLiteral("Cho den") ? QColor("#DCEBFA") :
                    status==QStringLiteral("Đã hủy") || status==QStringLiteral("Không đến") ? QColor("#E5E6E2") :
                    QColor("#E8F2E6");
                for(int col=0;col<8;++col)if(reservationTable->item(row,col)){reservationTable->item(row,col)->setBackground(bg);reservationTable->item(row,col)->setForeground(QColor("#202820"));}
            }
            if(loadedRows==0){reservationEmptyLabel->setText("Chưa có lịch đặt bàn nào trong DatBan.txt. Tạo đặt bàn ở biểu mẫu phía trên, sau đó bấm Làm mới lịch.");reservationEmptyLabel->setVisible(true);}
        };
        *reservationReloader = loadReservations;
        // Tu dong kiem tra moc qua han 10 phut va cap nhat mau/trang thai moi 30 giay.
        auto *reservationStatusTimer = new QTimer(w);
        reservationStatusTimer->setInterval(30000);
        connect(reservationStatusTimer, &QTimer::timeout, w, loadReservations);
        reservationStatusTimer->start();
        connect(refreshReservations, &QPushButton::clicked, w, loadReservations);
        connect(cancelReservation, &QPushButton::clicked, w, [this, reservationTable, loadReservations]() {
            const int row = reservationTable->currentRow();
            if (row < 0 || !reservationTable->item(row, 0)) {
                QMessageBox::information(this, "Chưa chọn lịch", "Hãy chọn lượt đặt bàn cần hủy.");
                return;
            }
            const QString bookingId = reservationTable->item(row, 0)->text().trimmed();
            const QString status = reservationTable->item(row, 7) ? reservationTable->item(row, 7)->text().trimmed() : QString();
            if (bookingId.isEmpty() || status.isEmpty()) {
                QMessageBox::information(this, "Lịch không hợp lệ", "Không đọc được thông tin lượt đặt bàn.");
                return;
            }
            if (status == QStringLiteral("Đã hủy") || status == QStringLiteral("Da huy") ||
                status == QStringLiteral("Không đến") || status == QStringLiteral("Khong den") ||
                status == QStringLiteral("Đã nhận bàn") || status == QStringLiteral("Hoàn thành")) {
                QMessageBox::information(this, "Không thể hủy", "Lượt đặt này đã kết thúc hoặc khách đã nhận bàn.");
                return;
            }
            if (QMessageBox::question(this, "Xác nhận hủy bàn",
                    "Bạn có chắc chắn muốn hủy lượt đặt " + bookingId + "?\n"
                    "Nếu lượt đặt đã thu cọc, toàn bộ tiền cọc sẽ được ghi nhận là mất cọc.\n"
                    "Bàn sẽ được giải phóng sau khi hủy.",
                    QMessageBox::Yes | QMessageBox::No, QMessageBox::No) != QMessageBox::Yes) return;
            if (!DatBanService().huyDatBan(GiaoDienDataService::utf8(bookingId))) {
                QMessageBox::critical(this, "Hủy bàn thất bại",
                    "Không thể hủy lượt đặt. Vui lòng kiểm tra quyền DAT_BAN và dữ liệu đặt bàn/tiền cọc.");
                return;
            }
            loadReservations();
            if (refreshDashboard) refreshDashboard();
            QMessageBox::information(this, "Đã hủy bàn",
                "Lượt đặt " + bookingId + " đã chuyển sang trạng thái 'Đã hủy'. Bàn đã được giải phóng.");
        });

        connect(confirmArrival, &QPushButton::clicked, w, [this, reservationTable, loadReservations]() {
            const int row = reservationTable->currentRow();
            if (row < 0 || !reservationTable->item(row, 0)) {
                QMessageBox::information(this, "Chưa chọn lịch", "Hãy chọn lịch đặt bàn cần xác nhận khách đến.");
                return;
            }
            const QString bookingId = reservationTable->item(row, 0)->text().trimmed();
            const QString status = reservationTable->item(row, 7) ? reservationTable->item(row, 7)->text().trimmed() : QString();
            if (bookingId.isEmpty() || status.isEmpty()) {
                QMessageBox::information(this, "Chưa có lịch hợp lệ", "Hãy làm mới lịch hoặc tạo một lượt đặt bàn trước.");
                return;
            }
            if (status != QStringLiteral("Đã đặt")) {
                QMessageBox::information(this, "Không thể xác nhận", "Chỉ lịch đang ở trạng thái 'Đã đặt' mới có thể xác nhận khách đến. Khách đến trễ quá 10 phút sẽ được ghi nhận 'Không đến' và bàn được giải phóng nếu không có lượt phục vụ đang mở. Trạng thái hiện tại: " + status);
                return;
            }
            if (QMessageBox::question(this, "Xác nhận khách đến",
                    "Xác nhận khách của lượt " + bookingId + " đã đến và nhận bàn?\nBàn sẽ chuyển sang trạng thái 'Đang sử dụng'.",
                    QMessageBox::Yes | QMessageBox::No, QMessageBox::No) != QMessageBox::Yes) return;
            DatBanService bookingService;
            if (!bookingService.xacNhanKhachDen(GiaoDienDataService::utf8(bookingId))) {
                QMessageBox::critical(this,"Không xác nhận được khách","Không thể chuyển lượt đặt sang 'Đã nhận bàn' và đồng bộ trạng thái bàn. Kiểm tra Ban.txt và DatBan.txt.");
                return;
            }
            loadReservations();
            if (refreshDashboard) refreshDashboard();
            QMessageBox::information(this, "Đã nhận bàn",
                "Đã cập nhật lượt đặt thành 'Đã nhận bàn' và bàn thành 'Đang sử dụng'.\n"
                "Sơ đồ bàn trên Trang chủ đã được làm mới.");
        });

        loadTables();
        loadReservations();
        return w;
    }

QWidget * RestaurantWindow::makeTablesPage(){
        auto *w = new QWidget;
        auto *v = createPageTemplate(w);
        addPageHeader(v, "Quản lý bàn ăn",
                      "Dữ liệu bàn được đọc và lưu trực tiếp bằng file TXT");
        auto*f=panel();auto*l=new QVBoxLayout(f);
        // Sơ đồ bàn dạng thẻ dễ nhìn, tự sinh từ dữ liệu TXT; không cần thiết kế vị trí thủ công.
        auto *mapPanel=panel(); auto *mapLayout=new QVBoxLayout(mapPanel);
        auto *mapHeader=new QHBoxLayout; mapHeader->addWidget(label("▦  Sơ đồ bàn", "sectionTitle")); mapHeader->addStretch();
        auto *legend=new QLabel("🟢 Trống    🟡 Đã đặt    🔴 Đang sử dụng    ⚪ Bảo trì"); legend->setStyleSheet("color:#526052;background:transparent;"); mapHeader->addWidget(legend); mapLayout->addLayout(mapHeader);
        auto *mapScroll=new QScrollArea; mapScroll->setObjectName("tableMapScroll"); mapScroll->setWidgetResizable(true); mapScroll->setFrameShape(QFrame::NoFrame); mapScroll->setMinimumHeight(180);
        mapScroll->setStyleSheet("QScrollArea#tableMapScroll{background:#F8FBF7;border:0;} QScrollArea#tableMapScroll QWidget#qt_scrollarea_viewport{background:#F8FBF7;} QScrollBar:vertical{width:12px;background:#EAF2E8;margin:2px;border-radius:6px;} QScrollBar::handle:vertical{background:#A8C8AA;min-height:28px;border-radius:6px;} QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0;}");
        auto *mapContent=new QWidget; mapContent->setObjectName("tableMapContent"); mapContent->setAutoFillBackground(true); mapContent->setStyleSheet("QWidget#tableMapContent{background:#F8FBF7;color:#243328;border:0;}");
        auto *mapGroups=new QVBoxLayout(mapContent); mapGroups->setContentsMargins(2,2,2,2); mapGroups->setSpacing(10); mapScroll->setWidget(mapContent); mapLayout->addWidget(mapScroll); l->addWidget(mapPanel);
        auto*filters=new QHBoxLayout;auto*search=new QLineEdit;search->setPlaceholderText("Tìm mã bàn hoặc tên bàn...");auto*area=new QComboBox;area->addItem("Tất cả khu vực","");auto*refresh=new QPushButton("↻ Làm mới");refresh->setObjectName("soft");auto*add=new QPushButton("＋ Thêm bàn");add->setObjectName("primary");if(userRole!="Admin")add->setVisible(false);filters->addWidget(search,1);filters->addWidget(area);filters->addWidget(refresh);filters->addWidget(add);l->addLayout(filters);
        auto*t=new QTableWidget(0,5);t->setHorizontalHeaderLabels({"Mã bàn","Tên bàn","Khu vực","Số chỗ","Trạng thái"});t->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);t->setSelectionBehavior(QAbstractItemView::SelectRows);t->setSelectionMode(QAbstractItemView::ExtendedSelection);t->setEditTriggers(QAbstractItemView::NoEditTriggers);t->verticalHeader()->setVisible(false);l->addWidget(t,1);
        auto loadAreas=[this,area](){
            const QString old=area->currentData().toString(); area->clear(); area->addItem("Tất cả khu vực","");
            auto areas=uiRowsFrom(KhuVucService().getDanhSachKhuVuc());
            std::sort(areas.begin(),areas.end(),[](const auto&a,const auto&b){return a.size()>1&&b.size()>1&&QString::fromUtf8(a[1].c_str()).localeAwareCompare(QString::fromUtf8(b[1].c_str()))<0;});
            for(const auto &r:areas) if(r.size()>=2) area->addItem(GiaoDienDataService::value(r,1),GiaoDienDataService::value(r,0));
            const int i=area->findData(old);if(i>=0)area->setCurrentIndex(i);
        };
        auto load=[this,t,area,mapGroups,mapContent,search](){
            t->setRowCount(0);while(mapGroups->count()){QLayoutItem *it=mapGroups->takeAt(0);if(it->widget())it->widget()->deleteLater();delete it;}
            auto tables=uiRowsFrom(BanService().getDanhSachBan()); auto bookings=uiRowsFrom(DatBanService().getDanhSachDatBan());
            QMap<QString,QList<QStringList>> grouped;
            for(const auto &table:tables){
                if(table.size()<5)continue;
                const QString id=GiaoDienDataService::value(table,0),name=GiaoDienDataService::value(table,1),areaId=GiaoDienDataService::value(table,4);
                if(!area->currentData().toString().isEmpty()&&areaId!=area->currentData().toString())continue;
                QString status=GiaoDienDataService::value(table,3);
                QString reservationHint;
                for(const auto &booking:bookings) if(booking.size()>=8&&GiaoDienDataService::value(booking,2)==id&&GiaoDienDataService::value(booking,4)==GiaoDienDataService::dateToday()){
                    const QString bookingStatus=GiaoDienDataService::value(booking,7);
                    if(bookingStatus==QStringLiteral("Đã nhận bàn")||bookingStatus==QStringLiteral("Da nhan ban")){status=QStringLiteral("Đang sử dụng");break;}
                    if(GiaoDienDataService::activeBooking(bookingStatus)){
                        const QTime arrival=QTime::fromString(GiaoDienDataService::value(booking,5).left(5),"HH:mm");
                        const qint64 mins=arrival.isValid()?QDateTime::currentDateTime().secsTo(QDateTime(QDate::currentDate(),arrival))/60:999;
                        if(mins>=0&&mins<=30) reservationHint="🔔 Sắp có khách lúc "+arrival.toString("HH:mm");
                    }
                }
                const QString areaName=GiaoDienDataService::areaName(areaId);
                QStringList row={id,name,areaName,GiaoDienDataService::value(table,2),status,reservationHint}; grouped[areaName].append(row);
                const int r=t->rowCount();t->insertRow(r);
                QColor tint=(r%2==0)?QColor("#FFFFFF"):QColor("#EDF6ED");if(status=="Đã đặt")tint=QColor("#FFF0C2");else if(status=="Đang sử dụng")tint=QColor("#F8DADA");else if(status=="Bảo trì")tint=QColor("#E3E5E8");
                for(int c=0;c<5;++c){auto *cell=new QTableWidgetItem(row[c]);cell->setBackground(tint);t->setItem(r,c,cell);}
                if(!reservationHint.isEmpty()&&t->item(r,4))t->item(r,4)->setText(status+" · "+reservationHint);
            }
            for(auto it=grouped.cbegin();it!=grouped.cend();++it){
                auto *group=new QWidget;group->setStyleSheet("QWidget{background:#F8FBF7;color:#243328;border:1px solid #DCEADD;border-radius:10px;}");auto *gv=new QVBoxLayout(group);gv->setContentsMargins(8,6,8,8);
                auto *title=new QToolButton;title->setToolButtonStyle(Qt::ToolButtonTextOnly);title->setText("▾  "+it.key()+"  ·  "+QString::number(it.value().size())+" bàn");title->setCheckable(true);title->setChecked(true);title->setStyleSheet("QToolButton{font-weight:700;color:#365B40;background:transparent;border:0;text-align:left;padding:2px;}");gv->addWidget(title);
                auto *gridWidget=new QWidget;gridWidget->setStyleSheet("background:transparent;border:0;");auto *grid=new QGridLayout(gridWidget);grid->setSpacing(8);int idx=0;
                for(const auto &r:it.value()){QString st=r[4],bg="#DCEFE0",edge="#9BC7A5";if(st=="Đã đặt"){bg="#FFF0C2";edge="#E3C76D";}else if(st=="Đang sử dụng"){bg="#F8DADA";edge="#DCA2A2";}else if(st=="Bảo trì"){bg="#E3E5E8";edge="#B9BEC4";}auto *tile=new QPushButton(r[0]+" · "+r[1]+"\n"+st+"  |  "+r[3]+" chỗ"+(r.size()>5&&!r[5].isEmpty()?"\n"+r[5]:QString()));tile->setMinimumSize(125,62);tile->setCursor(Qt::PointingHandCursor);tile->setToolTip("Nhấn để xem thông tin bàn."+(r.size()>5&&!r[5].isEmpty()?"\n"+r[5]:QString()));tile->setStyleSheet(QString("QPushButton{background:%1;border:1px solid %2;border-radius:8px;color:#243328;font-weight:600;padding:7px;text-align:center;} QPushButton:hover{border:2px solid #4B9B78;}").arg(bg,edge));const QString tableId=r[0],tableName=r[1],tableStatus=r[4],seatCount=r[3],areaLabel=it.key(),reservationNote=(r.size()>5?r[5]:QString());QObject::connect(tile,&QPushButton::clicked,this,[this,tableId,tableName,tableStatus,seatCount,areaLabel,reservationNote](){
                    QString info=QString("Mã bàn: %1\nTên bàn: %2\nKhu vực: %3\nSức chứa: %4 chỗ\nTrạng thái: %5")
                        .arg(tableId,tableName,areaLabel,seatCount,tableStatus);
                    if(!reservationNote.isEmpty()) info+=QString("\n\n%1").arg(reservationNote);
                    if (userRole == QStringLiteral("PhucVu") &&
                        (tableStatus == QStringLiteral("Đang sử dụng") ||
                         tableStatus == QStringLiteral("Dang su dung"))) {
                        if (!orderStaffCanTransferTables()) {
                            QMessageBox::information(this, "Thông tin bàn", info +
                                "\n\nChức năng chuyển bàn hiện chưa được Admin cho phép.");
                            return;
                        }

                        QMessageBox tableInfo(this);
                        tableInfo.setWindowTitle("Thông tin bàn");
                        tableInfo.setText(info);
                        auto *transferButton = tableInfo.addButton("↔ Chuyển bàn", QMessageBox::AcceptRole);
                        tableInfo.addButton("Đóng", QMessageBox::RejectRole);
                        tableInfo.exec();
                        if (tableInfo.clickedButton() != transferButton) return;

                        BanService banService;
                        DatBanService bookingService;
                        QStringList bookingIds, bookingLabels;
                        for (const auto &booking : bookingService.getDanhSachDatBan()) {
                            if (booking.getMaBan() != tableId.toStdString() ||
                                (booking.getTrangThai() != "Đã nhận bàn" &&
                                 booking.getTrangThai() != "Da nhan ban"))
                                continue;
                            const QString id = QString::fromUtf8(booking.getMaDatBan().c_str());
                            const QString customer = GiaoDienDataService::customerName(
                                QString::fromUtf8(booking.getMaKH().c_str()));
                            bookingIds << id;
                            bookingLabels << id + " · " + customer + " · " +
                                QString::fromUtf8(booking.getGioDat().c_str());
                        }

                        if (bookingIds.isEmpty()) {
                            QMessageBox::information(this, "Thông tin bàn", info +
                                "\n\nKhông tìm thấy lượt sử dụng đang hoạt động để chuyển bàn.");
                            return;
                        }

                        QStringList targetLabels, targetIds;
                        for (const auto &target : banService.getDanhSachBan()) {
                            const QString targetId = QString::fromUtf8(target.getMaBan().c_str());
                            const QString targetStatus = QString::fromUtf8(target.getTrangThai().c_str());
                            if (targetId == tableId ||
                                (targetStatus != QStringLiteral("Trống") &&
                                 targetStatus != QStringLiteral("Trong")))
                                continue;
                            targetIds << targetId;
                            targetLabels << QString::fromUtf8(target.getTenBan().c_str()) +
                                " · " + targetId + " · " +
                                QString::number(target.getSoCho()) + " chỗ";
                        }
                        if (targetIds.isEmpty()) {
                            QMessageBox::information(this, "Chuyển bàn",
                                "Hiện không có bàn trống để chuyển khách.");
                            return;
                        }
                        if (bookingLabels.isEmpty() || bookingIds.isEmpty()) return;
                        int bookingIndex = 0; 
                        bool chooseTarget = false;
                        const QString selectedTarget = QInputDialog::getItem(
                            this, "Chuyển sang bàn",
                            "Chọn bàn trống muốn chuyển khách tới:",
                            targetLabels, 0, false, &chooseTarget);
                        if (!chooseTarget) return;
                        const int targetIndex = targetLabels.indexOf(selectedTarget);
                        if (targetIndex < 0) return;
                        
                        if (QMessageBox::question(this, "Xác nhận chuyển bàn",
                            "Chuyển lượt " + bookingIds[bookingIndex] + " từ " +
                            tableName + " sang " + selectedTarget + "?",
                            QMessageBox::Yes | QMessageBox::No, QMessageBox::No) != QMessageBox::Yes)
                            return;

                        ChuyenBanService transferService(banService, bookingService);
                        if (!transferService.chuyenBan(
                            GiaoDienDataService::utf8(bookingIds[bookingIndex]),
                            GiaoDienDataService::utf8(targetIds[targetIndex]))) {
                            QMessageBox::warning(this, "Không thể chuyển bàn",
                                "Không thể chuyển bàn. Kiểm tra quyền chuyển bàn, trạng thái bàn đích và lượt đặt.");
                            return;
                        }
                        QMessageBox::information(this, "Đã chuyển bàn",
                            "Đã chuyển khách sang " + selectedTarget + ".");
                        return;
                    }


                    QMessageBox::information(this,"Thông tin bàn",info);
                });grid->addWidget(tile,idx/6,idx%6);++idx;}
                gv->addWidget(gridWidget);QObject::connect(title,&QToolButton::toggled,group,[title,gridWidget](bool on){gridWidget->setVisible(on);title->setText(QString(on?"▾  ":"▸  ")+title->text().mid(3));});mapGroups->addWidget(group);
            }
            if(grouped.isEmpty())mapGroups->addWidget(label("Chưa có bàn trong khu vực này.","muted"));mapGroups->addStretch();search->setText(search->text());
        };
        connect(refresh,&QPushButton::clicked,w,[loadAreas,load](){loadAreas();load();});connect(area,QOverload<int>::of(&QComboBox::currentIndexChanged),w,[load](int){load();});connect(search,&QLineEdit::textChanged,w,[t](const QString&s){for(int r=0;r<t->rowCount();++r){bool ok=false;for(int c=0;c<2;++c)if(t->item(r,c)&&t->item(r,c)->text().contains(s,Qt::CaseInsensitive))ok=true;t->setRowHidden(r,!ok);}});
        auto *tableRefreshTimer=new QTimer(w);tableRefreshTimer->setInterval(30000);QObject::connect(tableRefreshTimer,&QTimer::timeout,w,load);tableRefreshTimer->start();
        connect(add,&QPushButton::clicked,w,[this,loadAreas,load](){
            QDialog d(this);d.setWindowTitle("Thêm bàn ăn");QFormLayout form(&d);QLineEdit ma,ten;ma.setReadOnly(true);ma.setPlaceholderText("Tự động theo khu vực");QSpinBox cho;cho.setRange(1,30);cho.setValue(4);QComboBox kv;
            KhuVucService areaService;
            for(const auto &area : areaService.getDanhSachKhuVuc())
                kv.addItem(QString::fromUtf8(area.getTenKhuVuc().c_str()),
                           QString::fromUtf8(area.getMaKhuVuc().c_str()));
            if(kv.count()==0){QMessageBox::warning(this,"Thiếu khu vực","Hãy tạo khu vực trong mục Thiết kế sơ đồ bàn trước.");return;}
            QComboBox st;st.addItems({"Trống","Bảo trì"});auto updateTableCode=[&](){BanService svc;ma.setText(QString::fromStdString(svc.taoMaBan(kv.currentData().toString().toStdString())));};QObject::connect(&kv,QOverload<int>::of(&QComboBox::currentIndexChanged),&d,[&](int){updateTableCode();});updateTableCode();form.addRow("Mã bàn (tự động)",&ma);form.addRow("Tên bàn",&ten);form.addRow("Số chỗ",&cho);form.addRow("Khu vực",&kv);form.addRow("Trạng thái",&st);
            QPushButton save("Lưu"),cancel("Hủy");QHBoxLayout buttons;buttons.addWidget(&save);buttons.addWidget(&cancel);form.addRow(&buttons);QObject::connect(&cancel,&QPushButton::clicked,&d,&QDialog::reject);QObject::connect(&save,&QPushButton::clicked,&d,&QDialog::accept);
            if(d.exec()!=QDialog::Accepted)return;const QString id=ma.text().trimmed(),nm=ten.text().trimmed();if(id.isEmpty()||nm.isEmpty()){QMessageBox::warning(this,"Thiếu thông tin","Nhập mã và tên bàn.");return;}
            BanService tableService;
            Ban newTable(id.toStdString(), nm.toStdString(), cho.value(),
                         st.currentText().toStdString(), kv.currentData().toString().toStdString());
            if(!tableService.themBan(newTable)){QMessageBox::critical(this,"Không thêm được bàn","Mã bàn đã tồn tại hoặc thông tin bàn/khu vực không hợp lệ.");return;}
            loadAreas();load();QMessageBox::information(this,"Thành công","Đã thêm bàn.");
        });
        v->addWidget(f,1);loadAreas();load();return w;
    }

QMainWindow *createNhanVienWidget(const QString &username, std::function<void()> logoutCallback) {
    return createRestaurantWindowForRole(username, QStringLiteral("PhucVu"), std::move(logoutCallback));
}
