#pragma once
#include <QMainWindow>
#include <QString>
#include <functional>

QMainWindow *createNhanVienWidget(const QString &username, std::function<void()> logoutCallback);
