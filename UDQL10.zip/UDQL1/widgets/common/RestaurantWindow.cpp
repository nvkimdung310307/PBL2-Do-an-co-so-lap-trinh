#include <QMainWindow>
#include <QWidget>
#include <QFrame>
#include <QLabel>
#include <QPushButton>
#include <QCheckBox>
#include <QLineEdit>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QStackedWidget>
#include <QTableWidget>
#include <QToolButton>
#include <QAbstractItemView>
#include <QRegularExpression>
#include <QLocale>
#include <QHeaderView>
#include <QMessageBox>
#include <QDialog>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QDate>
#include <QDateTime>
#include <QDateEdit>
#include <QTimeEdit>
#include <QComboBox>
#include <QInputDialog>
#include <QGraphicsDropShadowEffect>
#include <QColor>
#include <QTime>
#include <QSpinBox>
#include <QDoubleSpinBox>
#include <QScrollArea>
#include <QSizePolicy>
#include <QTimer>
#include <QMap>
#include <QSet>
#include <memory>
#include <QVariant>
#include <QObject>
#include <functional>
#include <utility>
#include "taikhoan/TaiKhoanService.h"
#include "taikhoan/DangNhapService.h"
#include "taikhoan/PhanQuyen.h"
#include "oop/TaiKhoan.h"
#include "services/GiaoDienDataService.h"
#include "oop/DatBan.h"
#include "oop/DatCoc.h"
#include "services/DatCocService.h"
#include "oop/KhachHang.h"
#include "oop/NhanVien.h"
#include "services/BanService.h"
#include "services/KhuVucService.h"
#include "services/BoTriBanService.h"
#include "services/DatBanService.h"
#include "services/ChuyenBanService.h"
#include "services/KhachHangService.h"
#include "services/NhanVienService.h"
#include "widgets/login/DangNhapWidget.h"
#include "widgets/admin/AdminWidget.h"
#include "widgets/nhanvien/NhanVienWidget.h"
#include "widgets/common/RestaurantWindowFactory.h"
#include <vector>
#include <string>

#include <algorithm>
#include <QStringList>

RestaurantWindow::RestaurantWindow(const QString &username, const QString &role, std::function<void()> logoutCallback) : user(username), userRole(role), onLogout(std::move(logoutCallback)) {
        setWindowTitle("Quản lý nhà hàng | Admin & Nhân viên"); resize(1440, 900); setMinimumSize(1120, 720); setStyleSheet(appStyleSheet());
        auto *root = new QWidget; root->setObjectName("root"); setCentralWidget(root);
        auto *outer = new QHBoxLayout(root); outer->setContentsMargins(18,18,18,18); outer->setSpacing(18);
        auto *side = new QFrame; side->setObjectName("sidebar"); side->setFixedWidth(218); shadow(side);
        auto *sl = new QVBoxLayout(side); sl->setContentsMargins(14,20,14,16); sl->setSpacing(7);
        // Page indices are kept unchanged for QStackedWidget; only visual menu order changes.
        // Daily operations first, administration/configuration at the bottom.
        struct MenuEntry { int page; const char *title; };
        const MenuEntry adminMenu[] = {
            {0, "🏠   Trang chủ"},
            {7, "📋   Theo dõi lượt đặt bàn"},
            {8, "💳   Xác nhận thanh toán"},
            {10, "💵   Thu tiền cọc"},
            {11, "💰   Theo dõi tiền cọc"},
            {3, "😊   Khách hàng"},
            {4, "🧑‍🍳   Nhân viên & tài khoản"},
            {6, "🗺️   Bố trí sơ đồ bàn"},
            {9, "💰   Cấu hình tiền cọc"},
        };
        const MenuEntry orderMenu[] = {
            {0, "🏡   Tổng quan"},
            {1, "📅   Đặt bàn"},
            {2, "🪑   Trạng thái bàn"},
        };
        navButtons.fill(nullptr, 16);
        auto addMenuEntry = [this, sl](int page, const QString &title) {
            auto *b = new QPushButton(title);
            b->setObjectName("nav");
            b->setProperty("active", page == 0);
            b->setCursor(Qt::PointingHandCursor);
            sl->addWidget(b);
            navButtons[page] = b;
            connect(b, &QPushButton::clicked, this, [this, page] { showPage(page); });
        };
        if (userRole == "Admin") {
            for (const auto &entry : adminMenu) addMenuEntry(entry.page, QString::fromUtf8(entry.title));
        } else {
            for (const auto &entry : orderMenu) addMenuEntry(entry.page, QString::fromUtf8(entry.title));
        }
        sl->addStretch();
        outer->addWidget(side);
        auto *right = new QWidget; auto *rv = new QVBoxLayout(right); rv->setContentsMargins(0,0,0,0); rv->setSpacing(16);
        auto *top = new QHBoxLayout; auto *profile=new QLabel("●   "+user+"   -   "+(role=="Admin"?QString("Quản trị viên"):QString("Phục Vụ"))); profile->setStyleSheet("background:#EAF2E8;border-radius:12px;padding:12px;color:#000000;font-weight:600;"); top->addWidget(profile);
        auto *logoutButton=new QPushButton("Đăng xuất"); logoutButton->setObjectName("soft"); logoutButton->setCursor(Qt::PointingHandCursor); top->addWidget(logoutButton); connect(logoutButton,&QPushButton::clicked,this,[this]{ if(QMessageBox::question(this,"Đăng xuất","Bạn có chắc chắn muốn đăng xuất khỏi tài khoản này?",QMessageBox::Yes|QMessageBox::No,QMessageBox::No)==QMessageBox::Yes){ hide(); if(onLogout) onLogout(); } }); rv->addLayout(top);
        // Tu dong cap nhat trang thai dat ban ke ca khi nguoi dung dang o trang khac.
        auto *bookingStatusTimer = new QTimer(this);
        bookingStatusTimer->setInterval(30000);
        connect(bookingStatusTimer, &QTimer::timeout, this, []() {
            DatBanService().capNhatTrangThaiTheoThoiGian();
        });
        bookingStatusTimer->start();
        pages = new QStackedWidget;
        pages->setObjectName("functionPages");
        pages->setStyleSheet("QStackedWidget#functionPages{background:#F5F0E4;border:0;} QStackedWidget#functionPages > QWidget{background:#F5F0E4;color:#000000;}");

        // Chỉ dựng trang chủ khi đăng nhập. Các trang nghiệp vụ được tạo khi
        // người dùng mở đúng mục tương ứng, tránh khởi tạo hàng loạt service
        // và đọc TXT của những chức năng không thuộc vai trò hiện tại.
        pageInitialized.fill(false, 16);
        pages->addWidget(makeDashboard());
        pageInitialized[0] = true;
        for (int pageIndex = 1; pageIndex < 16; ++pageIndex) {
            pages->addWidget(new QWidget);
        }
        // Tao lai Trang chu tu du lieu TXT moi nhat de dong bo so do sau khi Order/Admin cap nhat.
        refreshDashboard = [this]() {
            if (!pages || pages->count() == 0) return;
            const int currentIndex = pages->currentIndex();
            QWidget *oldDashboard = pages->widget(0);
            pages->removeWidget(oldDashboard);
            oldDashboard->deleteLater();
            pages->insertWidget(0, makeDashboard());
            pageInitialized[0] = true;
            pages->setCurrentIndex(currentIndex);
        };
        // Một thanh cuộn chính cho toàn bộ nội dung trang; dùng màu sáng đồng bộ giao diện.
        pageScroll = new QScrollArea;
        pageScroll->setObjectName("pageScroll");
        pageScroll->setWidgetResizable(true);
        pageScroll->setFrameShape(QFrame::NoFrame);
        pageScroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        pageScroll->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        pageScroll->setStyleSheet(
            "QScrollArea#pageScroll{background:#F5F0E4;border:0;}"
            "QScrollArea#pageScroll QWidget#qt_scrollarea_viewport{background:#F5F0E4;}"
            "QScrollBar:vertical{width:12px;background:#EAF2E8;margin:2px;border-radius:6px;}"
            "QScrollBar::handle:vertical{background:#A8C8AA;min-height:28px;border-radius:6px;}"
            "QScrollBar::handle:vertical:hover{background:#7EAD89;}"
            "QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0;}"
        );
        pages->setMinimumSize(0, 0);
        pages->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Preferred);
        pageScroll->setWidget(pages);
        if (pages->currentIndex() == 0) {
            pageScroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
            pageScroll->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        }
        rv->addWidget(pageScroll,1);
        outer->addWidget(right,1);
    }


QWidget *RestaurantWindow::makeSettlementPage() {
        auto *w = new QWidget;
        auto *v = createPageTemplate(w);

        auto *heading = new QHBoxLayout;
        heading->addWidget(label("Quyết toán hóa đơn & tiền cọc", "pageTitle"));
        heading->addStretch();
        auto *refresh = new QPushButton("↻ Làm mới lịch");
        refresh->setObjectName("soft");
        auto *confirm = new QPushButton("✓ Quyết toán và hoàn tất");
        confirm->setObjectName("primary");
        heading->addWidget(refresh);
        heading->addWidget(confirm);
        v->addLayout(heading);
        v->addWidget(label(
            "Chọn lượt đã nhận bàn, nhập tổng bill thực tế. Hệ thống tự trừ cọc đã thu; nếu cọc dư, phần dư được ghi nhận nhà hàng giữ lại. "
            "Lưu ý: phiên bản hiện tại chưa có dịch vụ hóa đơn món ăn nên Thu ngân nhập tổng bill tại đây.", "muted"));

        auto *search = new QLineEdit;
        search->setPlaceholderText("Tìm mã lượt, khách hàng hoặc bàn...");
        v->addWidget(search);

        auto *table = new QTableWidget(0, 9);
        table->setHorizontalHeaderLabels({
            "Mã lượt", "Khách hàng", "Bàn", "Thời điểm nhận",
            "Ngày khách đến", "Giờ khách đến", "Số người", "Tiền cọc", "Trạng thái"
        });
        table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        table->setSelectionBehavior(QAbstractItemView::SelectRows);
        table->setSelectionMode(QAbstractItemView::SingleSelection);
        table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        table->verticalHeader()->setVisible(false);
        table->setAlternatingRowColors(true);
        v->addWidget(table, 1);

        auto load = [table]() {
            table->setRowCount(0);
            GiaoDienDataService::Rows settlements;
            GiaoDienDataService::layLichSuQuyetToan(settlements);
            QSet<QString> settledIds;
            for (const auto &r : settlements) if (!r.empty()) settledIds.insert(QString::fromUtf8(r[0].c_str()));

            DatCocService depositService;
            for (const auto &b : DatBanService().getDanhSachDatBan()) {
                const QString status = QString::fromUtf8(b.getTrangThai().c_str());
                if (status != QStringLiteral("Đã nhận bàn") && status != QStringLiteral("Da nhan ban")) continue;
                const QString bookingId = QString::fromUtf8(b.getMaDatBan().c_str());
                if (settledIds.contains(bookingId)) continue;
                const QString customerId = QString::fromUtf8(b.getMaKH().c_str());
                const QString tableId = QString::fromUtf8(b.getMaBan().c_str());
                const QString createdAt = QString::fromUtf8(b.getNgayTao().c_str()) +
                    (b.getGioTao().empty() ? QString() : " " + QString::fromUtf8(b.getGioTao().c_str()));
                qlonglong depositAmount = 0;
                const DatCoc *deposit = depositService.timTheoDatBan(b.getMaDatBan());
                if (deposit && (deposit->getTrangThai() == DatCoc::DA_DAT_COC ||
                                deposit->getTrangThai() == "Đã đặt cọc"))
                    depositAmount = deposit->getSoTien();
                const QStringList cells = {
                    bookingId,
                    GiaoDienDataService::customerName(customerId),
                    GiaoDienDataService::tableName(tableId),
                    createdAt.isEmpty() ? QStringLiteral("Dữ liệu cũ") : createdAt,
                    QString::fromUtf8(b.getNgayDat().c_str()),
                    QString::fromUtf8(b.getGioDat().c_str()),
                    QString::number(b.getSoNguoi()),
                    QLocale(QLocale::Vietnamese).toString(depositAmount) + " đ",
                    QStringLiteral("Chờ quyết toán")
                };
                const int row = table->rowCount();
                table->insertRow(row);
                for (int c = 0; c < cells.size(); ++c) {
                    auto *item = new QTableWidgetItem(cells[c]);
                    if (c == 0) item->setData(Qt::UserRole, bookingId);
                    if (c == 7) item->setData(Qt::UserRole, QVariant::fromValue<qlonglong>(depositAmount));
                    table->setItem(row, c, item);
                }
            }
        };
        QObject::connect(refresh, &QPushButton::clicked, w, load);
        QObject::connect(search, &QLineEdit::textChanged, w, [table](const QString &term) {
            for (int r = 0; r < table->rowCount(); ++r) {
                bool match = term.trimmed().isEmpty();
                for (int c = 0; c < table->columnCount(); ++c)
                    if (table->item(r, c) && table->item(r, c)->text().contains(term, Qt::CaseInsensitive))
                        match = true;
                table->setRowHidden(r, !match);
            }
        });
        QObject::connect(confirm, &QPushButton::clicked, w, [w, table, load]() {
            const int row = table->currentRow();
            if (row < 0 || !table->item(row, 0)) {
                QMessageBox::information(w, "Chưa chọn lượt", "Hãy chọn một lượt đang chờ quyết toán.");
                return;
            }
            const QString bookingId = table->item(row, 0)->data(Qt::UserRole).toString();
            const qlonglong depositAmount = table->item(row, 7)->data(Qt::UserRole).toLongLong();

            bool ok = false;
            const qlonglong billAmount = QInputDialog::getInt(
                w, "Nhập tổng hóa đơn",
                "Tổng bill của lượt " + bookingId + " (đồng):",
                0, 0, 1000000000, 1000, &ok);
            if (!ok) return;

            const qlonglong amountToUse = std::min(depositAmount, billAmount);
            const qlonglong amountToPay = std::max<qlonglong>(0, billAmount - depositAmount);
            const qlonglong refundAmount = std::max<qlonglong>(0, depositAmount - billAmount);
            const QString summary =
                "Tổng hóa đơn: " + QLocale(QLocale::Vietnamese).toString(billAmount) + " đ\n" +
                "Tiền cọc được trừ: " + QLocale(QLocale::Vietnamese).toString(amountToUse) + " đ\n" +
                "Khách cần nộp thêm: " + QLocale(QLocale::Vietnamese).toString(amountToPay) + " đ\n" +
                "Tiền nhà hàng phải hoàn khách: " + QLocale(QLocale::Vietnamese).toString(refundAmount) + " đ\n\n" +
                "Xác nhận đã thu đủ tiền còn thiếu và hoàn lại tiền cọc dư cho khách (nếu có)?";
            if (QMessageBox::question(w, "Xác nhận quyết toán", summary,
                QMessageBox::Yes | QMessageBox::No, QMessageBox::No) != QMessageBox::Yes) return;

            GiaoDienDataService::Rows rows;
            if (!GiaoDienDataService::layLichSuQuyetToan(rows)) {
                QMessageBox::critical(w, "Lỗi dữ liệu", "Không đọc được lịch sử quyết toán.");
                return;
            }
            for (const auto &r : rows) {
                if (!r.empty() && r[0] == bookingId.toStdString()) {
                    QMessageBox::warning(w, "Đã quyết toán", "Lượt này đã có bản ghi quyết toán, không thể trừ cọc lần nữa.");
                    load();
                    return;
                }
            }
            const QString timestamp = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
            rows.push_back({bookingId.toStdString(), std::to_string(billAmount),
                std::to_string(amountToUse), std::to_string(amountToPay),
                std::to_string(refundAmount), timestamp.toStdString()});
            if (!GiaoDienDataService::luuLichSuQuyetToan(rows)) {
                QMessageBox::critical(w, "Không lưu được", "Không thể lưu lịch sử quyết toán. Chưa hoàn tất lượt đặt.");
                return;
            }
            if (!DatBanService().hoanThanhDatBan(bookingId.toStdString())) {
                QMessageBox::warning(w, "Cần kiểm tra", "Đã lưu quyết toán nhưng không thể cập nhật lượt đặt thành hoàn thành. Không thực hiện quyết toán lại; cần kiểm tra dữ liệu.");
                load();
                return;
            }
            QMessageBox::information(w, "Quyết toán thành công", summary);
            load();
        });
        auto *timer = new QTimer(w);
        timer->setInterval(15000);
        QObject::connect(timer, &QTimer::timeout, w, load);
        timer->start();
        load();
        return w;
    }


void RestaurantWindow::ensurePageInitialized(int index) {
        if (index <= 0 || index >= 16 || pageInitialized.value(index, false)) return;

        QWidget *page = nullptr;
        switch (index) {
        case 1: page = makeBookingPage(); break;
        case 2: page = makeTablesPage(); break;
        case 3: page = makeGenericPage("Khách hàng"); break;
        case 4: page = makeEmployeePage(); break;
        case 5: page = makePosPage(); break;
        case 6: page = makeFloorDesignPage(); break;
        case 7: page = makeBookingMonitorPage(); break;
        case 8: page = makeSettlementPage(); break;
        case 9: page = makeDepositSettingsPage(); break;
        case 10: page = makeDepositCollectionPage(); break;
        case 11: page = makeDepositMonitorPage(); break;
        default: page = new QWidget; break;
        }

        QWidget *placeholder = pages->widget(index);
        pages->removeWidget(placeholder);
        pages->insertWidget(index, page);
        if (placeholder) placeholder->deleteLater();
        pageInitialized[index] = true;
    }

void RestaurantWindow::showPage(int index) {
        // Các trang Món ăn, Hóa đơn, Thống kê và Tài khoản Admin đã được ẩn khỏi ứng dụng.
        // Admin được phép mở các trang quản trị được hiển thị trong adminMenu.
        // Kiểm tra tường minh tại UI để tránh sai khác chuẩn hóa vai trò giữa
        // phiên đăng nhập và PhanQuyen khi điều hướng.
        const bool adminPageAllowed =
            userRole.trimmed().compare(QStringLiteral("Admin"), Qt::CaseInsensitive) == 0 &&
            (index == 0 || index == 3 || index == 4 ||
             index == 6 || index == 7 || index == 8 ||
             index == 9 || index == 10 || index == 11);
        if (!adminPageAllowed && !PhanQuyen::coQuyenTruyCapTrang(userRole, index)) {
            QString message = "Vai trò hiện tại không được phép truy cập chức năng này.";
            if (userRole == QStringLiteral("Admin"))
                message = "Admin không được truy cập chức năng phục vụ hoặc thanh toán tại đây.";
            else if (userRole == QStringLiteral("PhucVu"))
                message = "Phục Vụ chỉ truy cập Trang chủ, Đặt bàn và Trạng thái bàn.";
            QMessageBox::information(this, "Không đủ quyền truy cập", message);
            return;
        }
        ensurePageInitialized(index);
        if (index >= 0 && index < pages->count()) pages->setCurrentIndex(index);
        // Khi quay lại Trang chủ, làm mới dữ liệu sơ đồ bàn dùng cho các vai trò phục vụ.
        if (index == 0 && refreshDashboard) refreshDashboard();
        // Trang chủ phải vừa trong một màn hình; các trang nghiệp vụ vẫn được cuộn như cũ.
        if (pageScroll) {
            const bool fitOneScreen = (index == 0 || index == 9);
            // POS/Trang chủ phải co theo viewport, không ép người dùng cuộn cả trang.
            pages->setMinimumWidth(0);
            pages->setSizePolicy(QSizePolicy::Ignored, fitOneScreen ? QSizePolicy::Ignored : QSizePolicy::Preferred);
            if (pages->currentWidget()) {
                pages->currentWidget()->setMinimumWidth(0);
                pages->currentWidget()->setSizePolicy(QSizePolicy::Ignored, fitOneScreen ? QSizePolicy::Ignored : QSizePolicy::Preferred);
            }
            pageScroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
            pageScroll->setVerticalScrollBarPolicy(fitOneScreen ? Qt::ScrollBarAlwaysOff : Qt::ScrollBarAsNeeded);
        }
        for (int i = 0; i < navButtons.size(); ++i) {
            auto *b = navButtons[i];
            if (!b) continue;
            b->setProperty("active", i == index);
            b->style()->unpolish(b);
            b->style()->polish(b);
        }
    }

QWidget * RestaurantWindow::makeDashboard() {
        auto *w = new QWidget;
        w->setObjectName("dashboardPage");
        w->setMinimumWidth(0);
        w->setStyleSheet("QWidget#dashboardPage{background:#F5F0E4;color:#202820;}");
        auto *root = new QVBoxLayout(w);
        root->setContentsMargins(4, 2, 4, 2);
        root->setSpacing(12);
        auto *heading = new QHBoxLayout;
        auto *headingText = new QVBoxLayout;
        headingText->addWidget(label("Chào mừng trở lại, " + user + "!", "pageTitle"));
        headingText->addWidget(label("Cùng quản lý nhà hàng hiệu quả hơn hôm nay", "muted"));
        heading->addLayout(headingText);
        heading->addStretch();
        auto *date = label("📅  " + QDate::currentDate().toString("dd/MM/yyyy"));
        date->setStyleSheet("background:white;border:1px solid #E5ECE2;border-radius:10px;padding:8px 10px;");
        heading->addWidget(date);
        root->addLayout(heading);

        // Chi Admin hien thi cac the thong ke tren Trang chu.
        if (userRole == QStringLiteral("Admin")) {
            auto *metrics = new QGridLayout;
            metrics->setSpacing(10);
            const auto tables = BanService().getDanhSachBan();
            const auto bookings = DatBanService().getDanhSachDatBan();
            const auto customers = KhachHangService().getDanhSachKhachHang();
            int todayBookings = 0;
            for (const auto &booking : bookings) {
                if (QString::fromUtf8(booking.getNgayDat().c_str()) == GiaoDienDataService::dateToday() &&
                    GiaoDienDataService::activeBooking(QString::fromUtf8(booking.getTrangThai().c_str()))) ++todayBookings;
            }
            const QStringList titles = {"Tổng số bàn", "Đặt bàn hôm nay", "Khách hàng", "Nhân viên"};
            const QStringList values = {QString::number(tables.size()), QString::number(todayBookings),
                                        QString::number(customers.size()), QString::number(NhanVienService().getDanhSachNhanVien().size())};
            const QStringList icons = {"🪑", "📅", "👥", "🧑‍💼"};
            const QStringList colors = {"#E4F2E5", "#FBEBDD", "#FFF3D7", "#F9E5E8"};
            for (int i = 0; i < 4; ++i) {
                auto *card = new QFrame;
                card->setObjectName("stat");
                card->setMinimumHeight(72);
                shadow(card);
                auto *row = new QHBoxLayout(card);
                row->setContentsMargins(12, 8, 12, 8);
                auto *ic = label(icons[i]);
                ic->setAlignment(Qt::AlignCenter);
                ic->setFixedSize(38, 38);
                ic->setStyleSheet(QString("background:%1;border-radius:20px;font-size:19px;").arg(colors[i]));
                auto *col = new QVBoxLayout;
                col->addWidget(label(titles[i], "statTitle"));
                col->addWidget(label(values[i], "statValue"));
                row->addWidget(ic);
                row->addLayout(col, 1);
                metrics->addWidget(card, 0, i);
            }
            root->addLayout(metrics);

        }

        // So do ban hien thi truc tiep tren Trang chu nhu giao dien goc.
        auto *mapPanel = panel();
        auto *mapLayout = new QVBoxLayout(mapPanel);
        auto *mapHeader = new QHBoxLayout;
        mapHeader->addWidget(label("SƠ ĐỒ VÀ TRẠNG THÁI BÀN", "sectionTitle"));
        mapHeader->addStretch();
        mapHeader->addWidget(label("🟢 Trống   🟡 Đã đặt   🔴 Đang sử dụng   ⚪ Bảo trì", "muted"));
        mapLayout->addLayout(mapHeader);
        QMap<QString, QGridLayout*> areaGrids;
        const auto dashboardTables = BanService().getDanhSachBan();
        const auto dashboardBookings = DatBanService().getDanhSachDatBan();
        const auto dashboardPositions = BoTriBanService().getDanhSach();
        int tableIndex = 0;
        for (const auto &tableItem : dashboardTables) {
            const QString id = QString::fromUtf8(tableItem.getMaBan().c_str());
            const QString name = QString::fromUtf8(tableItem.getTenBan().c_str());
            const QString status = QString::fromUtf8(tableItem.getTrangThai().c_str());
            const QString area = GiaoDienDataService::areaName(QString::fromUtf8(tableItem.getMaKhuVuc().c_str()));
            QString shownStatus = status;
            QString customerInfo;
            for (const auto &booking : dashboardBookings) {
                if (QString::fromUtf8(booking.getMaBan().c_str()) == id &&
                    QString::fromUtf8(booking.getNgayDat().c_str()) == GiaoDienDataService::dateToday()) {
                    const QString bookingStatus = QString::fromUtf8(booking.getTrangThai().c_str());
                    if (bookingStatus == QStringLiteral("Đã nhận bàn") ||
                        bookingStatus == QStringLiteral("Da nhan ban")) {
                        shownStatus = QStringLiteral("Đang sử dụng");
                        customerInfo = GiaoDienDataService::customerName(QString::fromUtf8(booking.getMaKH().c_str()));
                        break;
                    }
                    if (GiaoDienDataService::activeBooking(bookingStatus)) {
                        shownStatus = QStringLiteral("Đã đặt");
                        customerInfo = GiaoDienDataService::customerName(QString::fromUtf8(booking.getMaKH().c_str()));
                    }
                }
            }
            QString bg = "#DCEFE0", edge = "#9BC7A5";
            if (shownStatus == "Đã đặt" || shownStatus == "Da dat") { bg = "#FFF0C2"; edge = "#E3C76D"; }
            else if (shownStatus == "Đang sử dụng" || shownStatus == "Dang su dung") { bg = "#F8DADA"; edge = "#DCA2A2"; }
            else if (shownStatus == "Bảo trì" || shownStatus == "Bao tri") { bg = "#E3E5E8"; edge = "#B9BEC4"; }
            if (!areaGrids.contains(area)) {
                auto *areaBox = new QFrame; areaBox->setStyleSheet("QFrame{background:#F8FBF7;border:1px solid #DCEADD;border-radius:10px;}");
                auto *areaLayout = new QVBoxLayout(areaBox); areaLayout->setContentsMargins(8,6,8,8);
                areaLayout->addWidget(label("▦  " + area, "sectionTitle"));
                auto *grid = new QGridLayout; grid->setSpacing(7); areaLayout->addLayout(grid);
                mapLayout->addWidget(areaBox); areaGrids.insert(area, grid);
            }
            int gridCol = tableIndex % 4, gridRow = tableIndex / 4;
            for (const auto &pos : dashboardPositions) if (QString::fromUtf8(pos.getMaBan().c_str()) == id) { gridCol = pos.getCot(); gridRow = pos.getHang(); break; }
            auto *tile = new QPushButton(name + "\n" + shownStatus + " · " + area);
            tile->setMinimumHeight(64); tile->setStyleSheet(QString("QPushButton{background:%1;border:1px solid %2;border-radius:8px;color:#243328;font-weight:600;padding:7px;} QPushButton:hover{border:2px solid #4B9B78;}").arg(bg, edge));
            QObject::connect(tile, &QPushButton::clicked, this, [this, id, name, area, shownStatus, customerInfo, tile]() {
                QString detail = QString("Bàn: %1 (%2)\nKhu vực: %3\nTrạng thái: %4").arg(name, id, area, shownStatus);
                if (!customerInfo.isEmpty()) detail += "\nKhách đặt: " + customerInfo;
                if (userRole == "Admin") {
                    const QStringList states = {"Trống", "Đang sử dụng", "Bảo trì"};
                    bool ok = false;
                    const QString next = QInputDialog::getItem(this, "Cập nhật trạng thái bàn", detail + "\n\nChọn trạng thái mới:", states, states.indexOf(shownStatus) < 0 ? 0 : states.indexOf(shownStatus), false, &ok);
                    if (!ok) return;
                    if (shownStatus == "Đã đặt" && next == "Trống") {
                        QMessageBox::warning(this, "Bàn đang có lịch đặt", "Bàn có lượt đặt đang hoạt động. Hãy xử lý lượt đặt trước khi chuyển trạng thái."); return;
                    }
                    if (!BanService().capNhatTrangThai(id.toStdString(), next.toStdString())) {
                        QMessageBox::warning(this, "Không cập nhật được", "Không thể lưu trạng thái bàn."); return;
                    }
                    tile->setText(name + "\n" + next + " · " + area);
                    QMessageBox::information(this, "Thành công", "Đã cập nhật trạng thái bàn.");
                } else QMessageBox::information(this, "Thông tin bàn", detail);
            });
            areaGrids[area]->addWidget(tile, gridRow, gridCol); ++tableIndex;
        }
        if (tableIndex == 0) mapLayout->addWidget(label("Chưa có dữ liệu bàn.", "muted"));
        root->addWidget(mapPanel);

        root->addStretch();
        return w;
    }

QWidget * RestaurantWindow::makeBookingMonitorPage() {
        auto *w = new QWidget;
        auto *v = createPageTemplate(w);
        addPageHeader(v, "Theo dõi lượt đặt bàn",
                      "Xem khách hàng nào đã đặt bàn nào, thời gian đến và trạng thái lượt đặt.");
        auto *tools = new QHBoxLayout;
        auto *search = new QLineEdit;
        search->setPlaceholderText("Tìm tên khách, số điện thoại, mã bàn hoặc mã đặt...");
        auto *refresh = new QPushButton("↻ Làm mới"); refresh->setObjectName("soft");
        tools->addWidget(search, 1); tools->addWidget(refresh); v->addLayout(tools);
        auto *table = new QTableWidget(0, 8);
        table->setHorizontalHeaderLabels({"Mã đặt", "Khách hàng", "Điện thoại", "Bàn", "Ngày đến", "Giờ đến", "Số người", "Trạng thái"});
        table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        table->setSelectionBehavior(QAbstractItemView::SelectRows);
        table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        table->verticalHeader()->setVisible(false);
        v->addWidget(table, 1);
        auto load = [table]() {
            table->setRowCount(0);
            const auto bookings = DatBanService().getDanhSachDatBan();
            for (const auto &b : bookings) {
                const QString customerId = QString::fromUtf8(b.getMaKH().c_str());
                const QString tableId = QString::fromUtf8(b.getMaBan().c_str());
                const QString customerName = GiaoDienDataService::customerName(customerId);
                KhachHangService customerService;
                const KhachHang *customer = customerService.timKhachHang(customerId.toStdString());
                const QString phone = customer ? QString::fromUtf8(customer->getSoDienThoai().c_str()) : QStringLiteral("-");
                const QString tableName = GiaoDienDataService::tableName(tableId);
                const QStringList cells = {
                    QString::fromUtf8(b.getMaDatBan().c_str()), customerName, phone,
                    tableName + " (" + tableId + ")",
                    QString::fromUtf8(b.getNgayDat().c_str()), QString::fromUtf8(b.getGioDat().c_str()),
                    QString::number(b.getSoNguoi()), QString::fromUtf8(b.getTrangThai().c_str())
                };
                const int row = table->rowCount(); table->insertRow(row);
                for (int c = 0; c < cells.size(); ++c) table->setItem(row, c, new QTableWidgetItem(cells[c]));
            }
        };
        QObject::connect(refresh, &QPushButton::clicked, w, load);
        QObject::connect(search, &QLineEdit::textChanged, w, [table](const QString &term) {
            for (int r = 0; r < table->rowCount(); ++r) {
                bool match = term.trimmed().isEmpty();
                for (int c = 0; c < table->columnCount(); ++c)
                    if (table->item(r,c) && table->item(r,c)->text().contains(term, Qt::CaseInsensitive)) match = true;
                table->setRowHidden(r, !match);
            }
        });
        auto *timer = new QTimer(w); timer->setInterval(30000);
        QObject::connect(timer, &QTimer::timeout, w, load); timer->start();
        load();
        return w;
    }

QWidget * RestaurantWindow::makeDepositMonitorPage() {
        auto *w = new QWidget;
        auto *v = createPageTemplate(w);
        auto *head = new QHBoxLayout;
        head->addWidget(label("Theo dõi tiền cọc", "pageTitle")); head->addStretch();
        auto *refresh = new QPushButton("↻ Làm mới"); refresh->setObjectName("soft"); head->addWidget(refresh); v->addLayout(head);
        v->addWidget(label("Theo dõi tiền cọc đang chờ, đã thu, đã trừ vào hóa đơn, mất cọc và hoàn lại khách.", "muted"));
        auto *stats = new QGridLayout; stats->setSpacing(8);
        auto makeStat = [&](const QString &title, const QString &name) {
            auto *box = panel(); auto *l = new QVBoxLayout(box); l->setContentsMargins(12,10,12,10);
            l->addWidget(label(title,"statTitle")); auto *value=label("0 đ",name); l->addWidget(value); return std::pair<QFrame*,QLabel*>(box,value);
        };
        auto a=makeStat("Tổng tiền cọc đã thu","statValue"); auto b=makeStat("Tiền cọc đang chờ","statValue");
        auto c=makeStat("Tiền đã mất cọc","statValue"); auto d=makeStat("Đã trừ vào hóa đơn","statValue");
        auto e=makeStat("Đã hoàn khách","statValue");
        stats->addWidget(a.first,0,0); stats->addWidget(b.first,0,1); stats->addWidget(c.first,0,2); stats->addWidget(d.first,0,3); stats->addWidget(e.first,0,4); v->addLayout(stats);
        auto *tools=new QHBoxLayout; auto *search=new QLineEdit; search->setPlaceholderText("Tìm mã lượt, khách hàng, bàn hoặc trạng thái..."); tools->addWidget(search,1); v->addLayout(tools);
        auto *table=new QTableWidget(0,9);
        table->setHorizontalHeaderLabels({"Mã lượt","Khách hàng","Bàn","Mức cọc","Trạng thái đặt bàn","Trạng thái cọc","Đã trừ bill","Hoàn khách","Ngày thu cọc"});
        table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch); table->setSelectionBehavior(QAbstractItemView::SelectRows); table->setEditTriggers(QAbstractItemView::NoEditTriggers); table->setAlternatingRowColors(true); table->verticalHeader()->setDefaultSectionSize(34);
        table->setStyleSheet("QTableWidget{background:#FFFFFF;color:#17251B;alternate-background-color:#F0F7F0;gridline-color:#DCE9D9;border:1px solid #DCE9D9;} QHeaderView::section{background:#DDEEDD;color:#17251B;border:0;border-bottom:1px solid #DCE9D9;padding:9px;} QHeaderView:vertical::section{background:#DDEEDD;color:#17251B;border:0;border-right:1px solid #DCE9D9;padding:6px;} QTableCornerButton::section{background:#DDEEDD;border:0;}");
        v->addWidget(table,1);
        auto money=[](qlonglong n){return QLocale(QLocale::Vietnamese).toString(n)+" đ";};
        auto load=[=]() {
            table->setRowCount(0);
            GiaoDienDataService::Rows snapshots, settlements;
            GiaoDienDataService::layMucCocDatBan(snapshots); GiaoDienDataService::layLichSuQuyetToan(settlements);
            QMap<QString,qlonglong> amountById, usedById, refundById;
            for(const auto &r:snapshots) if(r.size()>=3) amountById[QString::fromUtf8(r[0].c_str())]=QString::fromStdString(r[2]).toLongLong();
            for(const auto &r:settlements) if(r.size()>=5) {QString id=QString::fromUtf8(r[0].c_str()); usedById[id]=QString::fromStdString(r[2]).toLongLong(); refundById[id]=QString::fromStdString(r[4]).toLongLong();}
            DatCocService service; qlonglong totalCollected=0,totalPending=0,totalLost=0,totalUsed=0,totalRefund=0;
            DatBanService bookingService;
            const auto &allBookings = bookingService.getDanhSachDatBan();
            for(const auto &booking : allBookings) {
                QString id=QString::fromUtf8(booking.getMaDatBan().c_str()); QString bookingStatus=QString::fromUtf8(booking.getTrangThai().c_str());
                qlonglong expected=amountById.value(id,0); const DatCoc *dep=service.timTheoDatBan(booking.getMaDatBan());
                QString depositStatus="Chờ cọc"; qlonglong collected=0; QString date="-";
                if(dep) { collected=dep->getSoTien(); date=QString::fromUtf8(dep->getNgayDatCoc().c_str());
                    if(dep->getTrangThai()==DatCoc::MAT_COC || dep->getTrangThai()=="Mất cọc") depositStatus="Mất cọc";
                    else if(dep->getTrangThai()==DatCoc::DA_HOAN_COC || dep->getTrangThai()=="Đã hoàn cọc") depositStatus="Đã hoàn cọc";
                    else depositStatus="Đã thu cọc";
                } else if(expected<=0) depositStatus="Không yêu cầu cọc";
                qlonglong used=usedById.value(id,0), refund=refundById.value(id,0);
                if(bookingStatus=="Đã hủy" || bookingStatus=="Đã hủy đặt bàn" || bookingStatus=="Không đến" || bookingStatus=="Da huy" || bookingStatus=="Khong den") {
                    if(dep && depositStatus!="Mất cọc" && depositStatus!="Đã hoàn cọc") depositStatus="Đã hủy";
                }
                if(dep && depositStatus=="Đã thu cọc") totalCollected+=collected;
                if(!dep && expected>0 && bookingStatus!="Đã hủy" && bookingStatus!="Đã hủy đặt bàn" && bookingStatus!="Không đến") totalPending+=expected;
                if(depositStatus=="Mất cọc") totalLost+=collected;
                totalUsed+=used; totalRefund+=refund;
                if(expected<=0 && !dep && used==0 && refund==0) continue;
                QStringList cells={id,GiaoDienDataService::customerName(QString::fromUtf8(booking.getMaKH().c_str())),GiaoDienDataService::tableName(QString::fromUtf8(booking.getMaBan().c_str())),money(dep?collected:expected),bookingStatus,depositStatus,money(used),money(refund),date};
                int row=table->rowCount(); table->insertRow(row); for(int col=0;col<cells.size();++col)table->setItem(row,col,new QTableWidgetItem(cells[col]));
            }
            a.second->setText(money(totalCollected)); b.second->setText(money(totalPending)); c.second->setText(money(totalLost)); d.second->setText(money(totalUsed)); e.second->setText(money(totalRefund));
        };
        QObject::connect(refresh,&QPushButton::clicked,w,load);
        QObject::connect(search,&QLineEdit::textChanged,w,[table](const QString &term){for(int r=0;r<table->rowCount();++r){bool match=term.trimmed().isEmpty();for(int col=0;col<table->columnCount();++col)if(table->item(r,col)&&table->item(r,col)->text().contains(term,Qt::CaseInsensitive))match=true;table->setRowHidden(r,!match);}});
        auto *timer=new QTimer(w);timer->setInterval(30000);QObject::connect(timer,&QTimer::timeout,w,load);timer->start();load();return w;
    }

QWidget * RestaurantWindow::makeDepositSettingsPage() {
        auto *w = new QWidget;
        auto *root = createPageTemplate(w);
        addPageHeader(root, "Cấu hình tiền đặt cọc theo khu vực",
                      "Mức cọc áp dụng cho lượt đặt mới. Lượt đã tạo giữ nguyên mức cọc tại thời điểm tạo.");

        auto *formPanel = panel();
        auto *form = new QFormLayout(formPanel);
        auto *area = new QComboBox;
        auto *amount = new QSpinBox;
        amount->setRange(0, 1000000000);
        amount->setSingleStep(50000);
        amount->setSuffix(" đ");
        auto *save = new QPushButton("Lưu mức cọc khu vực");
        save->setObjectName("primary");
        form->addRow("Khu vực", area);
        form->addRow("Tiền cọc (0 = không yêu cầu)", amount);
        form->addRow(save);
        root->addWidget(formPanel);

        auto *table = new QTableWidget(0,3);
        table->setHorizontalHeaderLabels({"Mã khu vực","Tên khu vực","Mức cọc"});
        table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        table->setSelectionBehavior(QAbstractItemView::SelectRows);
        table->verticalHeader()->setDefaultSectionSize(36);
        table->setStyleSheet("QTableWidget{background:#FFFFFF;color:#17251B;gridline-color:#DCE9D9;border:1px solid #DCE9D9;} QHeaderView::section{background:#DDEEDD;color:#17251B;border:0;border-bottom:1px solid #DCE9D9;padding:10px;} QHeaderView:vertical::section{background:#DDEEDD;color:#17251B;border:0;border-right:1px solid #DCE9D9;padding:6px;} QTableCornerButton::section{background:#DDEEDD;border:0;}");
        root->addWidget(table,1);

        auto load = [area, amount, table]() {
            area->clear(); table->setRowCount(0);
            GiaoDienDataService::Rows config;
            GiaoDienDataService::layCauHinhDatCoc(config);
            QMap<QString, qlonglong> values;
            for (const auto &r : config)
                if (r.size() >= 2) values[QString::fromUtf8(r[0].c_str())] = QString::fromStdString(r[1]).toLongLong();
            for (const auto &kv : KhuVucService().getDanhSachKhuVuc()) {
                const QString id = QString::fromUtf8(kv.getMaKhuVuc().c_str());
                const QString name = QString::fromUtf8(kv.getTenKhuVuc().c_str());
                area->addItem(name + " (" + id + ")", id);
                const int row = table->rowCount(); table->insertRow(row);
                table->setItem(row,0,new QTableWidgetItem(id));
                table->setItem(row,1,new QTableWidgetItem(name));
                table->setItem(row,2,new QTableWidgetItem(QLocale(QLocale::Vietnamese).toString(values.value(id,0)) + " đ"));
            }
            if (area->count()) amount->setValue(values.value(area->currentData().toString(),0));
        };
        QObject::connect(area, qOverload<int>(&QComboBox::currentIndexChanged), w, [area,amount](int) {
            GiaoDienDataService::Rows rows; GiaoDienDataService::layCauHinhDatCoc(rows);
            const QString id=area->currentData().toString();
            for(const auto &r:rows) if(r.size()>=2 && QString::fromUtf8(r[0].c_str())==id) { amount->setValue(QString::fromStdString(r[1]).toInt()); return; }
            amount->setValue(0);
        });
        QObject::connect(save,&QPushButton::clicked,w,[area,amount,load]() {
            if(area->currentIndex()<0) { QMessageBox::warning(nullptr,"Thiếu khu vực","Hãy tạo khu vực trước."); return; }
            const std::string id = area->currentData().toString().toStdString();
            if (!GiaoDienDataService::capNhatMucCocTheoKhuVuc(id, amount->value())) {
                QMessageBox::critical(nullptr, "Lỗi lưu", "Không thể lưu cấu hình tiền cọc.");
                return;
            }
            load(); QMessageBox::information(nullptr,"Đã lưu","Đã cập nhật mức cọc cho khu vực. Lượt đặt cũ không bị thay đổi.");
        });
        load();
        return w;
    }

QWidget * RestaurantWindow::makeGenericPage(const QString &name) {
        auto *w = new QWidget;
        auto *layout = createPageTemplate(w);
        auto *heading = new QHBoxLayout;
        heading->addWidget(label(name, "pageTitle"));
        heading->addStretch();
        auto *refresh = new QPushButton("↻  Làm mới");
        refresh->setObjectName("soft");
        heading->addWidget(refresh);
        layout->addLayout(heading);
        layout->addWidget(label("Danh sách khách hàng được quản lý từ dữ liệu của KhachHangService.", "muted"));
        auto *search = new QLineEdit;
        search->setPlaceholderText("Tìm kiếm khách hàng...");
        layout->addWidget(search);
        auto *table = new QTableWidget(0, 3);
        table->setHorizontalHeaderLabels({"Mã khách hàng", "Tên khách hàng", "Số điện thoại"});
        table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        table->setSelectionBehavior(QAbstractItemView::SelectRows);
        table->setSelectionMode(QAbstractItemView::SingleSelection);
        table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        table->verticalHeader()->setVisible(false);
        table->setAlternatingRowColors(true);
        table->setMinimumHeight(300);
        layout->addWidget(table, 1);
        auto *detail = label("Chưa chọn khách hàng.", "muted");
        detail->setWordWrap(true);
        layout->addWidget(detail);
        auto load = [table, detail]() {
            table->setRowCount(0);
            const auto customers = KhachHangService().getDanhSachKhachHang();
            for (const auto &customer : customers) {
                const int row = table->rowCount();
                table->insertRow(row);
                table->setItem(row, 0, new QTableWidgetItem(QString::fromUtf8(customer.getMaKH().c_str())));
                table->setItem(row, 1, new QTableWidgetItem(QString::fromUtf8(customer.getHoTen().c_str())));
                table->setItem(row, 2, new QTableWidgetItem(QString::fromUtf8(customer.getSoDienThoai().c_str())));
            }
            if (table->rowCount() == 0) {
                table->insertRow(0);
                table->setSpan(0, 0, 1, 3);
                table->setItem(0, 0, new QTableWidgetItem("Chưa có dữ liệu khách hàng."));
                detail->setText("Danh sách khách hàng hiện đang trống.");
            } else detail->setText(QString("Đã tải %1 khách hàng.").arg(table->rowCount()));
        };
        connect(refresh, &QPushButton::clicked, w, load);
        connect(search, &QLineEdit::textChanged, w, [table](const QString &term) {
            for (int row = 0; row < table->rowCount(); ++row) {
                bool found = false;
                for (int col = 0; col < table->columnCount(); ++col)
                    if (table->item(row, col) && table->item(row, col)->text().contains(term, Qt::CaseInsensitive)) found = true;
                table->setRowHidden(row, !found);
            }
        });
        connect(table, &QTableWidget::itemSelectionChanged, w, [table, detail]() {
            const int row = table->currentRow();
            if (row < 0) return;
            detail->setText("Khách hàng: " + table->item(row, 1)->text() + "  |  Số điện thoại: " + table->item(row, 2)->text());
        });
        load();
        return w;
    }

QMainWindow *createRestaurantWindowForRole(const QString &username, const QString &role, std::function<void()> logoutCallback) { return new RestaurantWindow(username, role, std::move(logoutCallback)); }
