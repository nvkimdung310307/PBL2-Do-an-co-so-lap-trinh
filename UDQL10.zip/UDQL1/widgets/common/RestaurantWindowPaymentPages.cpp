#include "widgets/common/RestaurantWindowFactory.h"

QWidget * RestaurantWindow::makeDepositCollectionPage() {
        auto *w = new QWidget;
        auto *root = createPageTemplate(w);
        auto *heading = new QHBoxLayout;
        heading->addWidget(label("Thu tiền cọc giữ bàn", "pageTitle"));
        heading->addStretch();
        auto *refresh = new QPushButton("↻ Làm mới"); refresh->setObjectName("soft");
        auto *collect = new QPushButton("Thu tiền cọc"); collect->setObjectName("primary");
        heading->addWidget(refresh); heading->addWidget(collect);
        root->addLayout(heading);
        root->addWidget(label("Chỉ hiển thị lượt đặt còn hiệu lực và chưa thu cọc. Đặt bàn không cọc vẫn hợp lệ.", "muted"));
        auto *table = new QTableWidget(0,7);
        table->setHorizontalHeaderLabels({"Mã lượt","Khách hàng","Bàn","Khu vực","Ngày","Giờ","Tiền cọc"});
        table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        table->setSelectionBehavior(QAbstractItemView::SelectRows);
        table->setSelectionMode(QAbstractItemView::SingleSelection);
        table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        root->addWidget(table,1);
        auto load = [table]() {
            table->setRowCount(0);
            DatCocService depositService;
            const auto pendingDeposits = depositService.getDanhSachChoThuTienCoc();

            for (const auto& item : pendingDeposits) {
                const QStringList cells = {
                    QString::fromUtf8(item.maDatBan.c_str()),
                    GiaoDienDataService::customerName(QString::fromUtf8(item.maKhachHang.c_str())),
                    QString::fromUtf8(item.maBan.c_str()),
                    QString::fromUtf8(item.maKhuVuc.c_str()),
                    QString::fromUtf8(item.ngayDat.c_str()),
                    QString::fromUtf8(item.gioDat.c_str()),
                    QLocale(QLocale::Vietnamese).toString(item.soTien) + " đ"
                };
                const int row = table->rowCount();
                table->insertRow(row);
                for (int column = 0; column < cells.size(); ++column) {
                    table->setItem(row, column, new QTableWidgetItem(cells[column]));
                }
            }
        };

        QObject::connect(refresh,&QPushButton::clicked,w,load);
        QObject::connect(collect,&QPushButton::clicked,w,[table,load]() {
            const int row=table->currentRow();
            if(row<0) { QMessageBox::information(nullptr,"Chọn lượt đặt","Chọn lượt đặt bàn cần thu cọc."); return; }
            const QString bookingId=table->item(row,0)->text();
            bool ok=false;
            const qlonglong amount=QLocale(QLocale::Vietnamese).toLongLong(table->item(row,6)->text().remove(" đ"),&ok);
            if(!ok || amount<=0) { QMessageBox::warning(nullptr,"Lỗi số tiền","Không đọc được mức cọc."); return; }
            if(QMessageBox::question(nullptr,"Xác nhận thu cọc",
                QString("Thu %1 đ tiền cọc cho lượt %2?").arg(QLocale(QLocale::Vietnamese).toString(amount),bookingId)
                )!=QMessageBox::Yes) return;
            DatCoc deposit("",bookingId.toStdString(),amount,QDate::currentDate().toString("yyyy-MM-dd").toStdString(),DatCoc::DA_DAT_COC);
            if(!DatCocService().themDatCoc(deposit)) { QMessageBox::critical(nullptr,"Không thu được cọc","Không thể ghi nhận tiền cọc. Có thể lượt đặt đã được thu trước đó."); return; }
            QMessageBox::information(nullptr,"Đã thu cọc","Đã ghi nhận tiền cọc thành công.");
            load();
        });
        auto *timer=new QTimer(w); timer->setInterval(30000); QObject::connect(timer,&QTimer::timeout,w,load); timer->start();
        load();
        return w;
    }

QWidget * RestaurantWindow::makePosPage() {
        // Trang thông tin bàn: giữ nguyên vị trí trang trong QStackedWidget
        // để không làm xáo trộn bố cục/menu gốc. Không còn giao diện POS.
        auto *w = new QWidget;
        w->setObjectName("tableStatusPage");
        auto *root = new QVBoxLayout(w);
        root->setContentsMargins(2, 2, 2, 2);
        root->setSpacing(12);

        root->addWidget(label("THÔNG TIN TRẠNG THÁI BÀN", "pageTitle"));
        root->addWidget(label("Chọn bàn trên sơ đồ để xem thông tin. Trang này chỉ hiển thị trạng thái và hỗ trợ chuyển bàn.", "muted"));

        auto *infoPanel = panel();
        auto *infoLayout = new QVBoxLayout(infoPanel);
        infoLayout->setContentsMargins(18, 18, 18, 18);
        infoLayout->setSpacing(10);

        auto *tableTitle = label("Chưa chọn bàn", "sectionTitle");
        auto *tableInfo = label("Hãy quay lại sơ đồ bàn và nhấn vào bàn cần xem.", "muted");
        tableInfo->setWordWrap(true);
        tableInfo->setMinimumHeight(100);
        tableInfo->setStyleSheet(
            "QLabel{background:#F7FBF7;border:1px solid #DCEADD;border-radius:10px;"
            "padding:14px 16px;color:#263B2D;font-size:13px;}"
        );
        infoLayout->addWidget(tableTitle);
        infoLayout->addWidget(tableInfo);

        auto *transferButton = new QPushButton("↔  Chuyển bàn");
        transferButton->setObjectName("soft");
        const bool orderStaffView =
            userRole == QStringLiteral("NhanVien") ||
            userRole == QStringLiteral("PhucVu");
        transferButton->setVisible(orderStaffView && orderStaffCanTransferTables());
        infoLayout->addWidget(transferButton, 0, Qt::AlignLeft);
        root->addWidget(infoPanel);
        root->addStretch(1);

        auto refreshSelectedTable = [this, tableTitle, tableInfo]() {
            if (pendingTableId.isEmpty()) {
                tableTitle->setText("Chưa chọn bàn");
                tableInfo->setText("Hãy quay lại sơ đồ bàn và nhấn vào bàn cần xem.");
                return;
            }

            BanService tableService;
            const Ban *table = tableService.timBan(GiaoDienDataService::utf8(pendingTableId));
            if (!table) {
                tableTitle->setText("Không tìm thấy bàn");
                tableInfo->setText("Mã bàn: " + pendingTableId);
                return;
            }

            const QString name = QString::fromUtf8(table->getTenBan().c_str());
            const QString area = GiaoDienDataService::areaName(
                QString::fromUtf8(table->getMaKhuVuc().c_str()));
            const QString status = QString::fromUtf8(table->getTrangThai().c_str());
            const QString color = status == "Trống" || status == "Trong" ? "#2E7D32" :
                                  status == "Đã đặt" || status == "Da dat" ? "#B7791F" :
                                  status == "Đang sử dụng" ? "#B42318" : "#667085";

            tableTitle->setText(name + " · " + pendingTableId);
            tableInfo->setText(QString(
                "<b>Khu vực:</b> %1<br><b>Sức chứa:</b> %2 chỗ<br>"
                "<b>Trạng thái:</b> <span style='color:%3;font-weight:700'>%4</span>")
                .arg(area)
                .arg(table->getSoCho())
                .arg(color, status));
        };

        openTableInPos = [this, refreshSelectedTable](const QString &tableId) {
            pendingTableId = tableId;
            refreshSelectedTable();
            showPage(9);
        };

        connect(transferButton, &QPushButton::clicked, w,
                [this, refreshSelectedTable, w]() {
            if (pendingTableId.isEmpty()) {
                QMessageBox::information(w, "Chưa chọn bàn",
                    "Hãy chọn một bàn trên sơ đồ trước khi chuyển.");
                return;
            }

            QString bookingId;
            int partySize = 0;
            const QString today = GiaoDienDataService::dateToday();
            DatBanService bookingService;
            for (const auto &booking : bookingService.getDanhSachDatBan()) {
                if (QString::fromUtf8(booking.getMaBan().c_str()) == pendingTableId &&
                    QString::fromUtf8(booking.getNgayDat().c_str()) == today &&
                    (booking.getTrangThai() == "Đã đặt" ||
                     booking.getTrangThai() == "Đã nhận bàn")) {
                    bookingId = QString::fromUtf8(booking.getMaDatBan().c_str());
                    partySize = booking.getSoNguoi();
                    break;
                }
            }
            if (bookingId.isEmpty()) {
                QMessageBox::information(w, "Không có lượt đặt phù hợp",
                    "Bàn này không có lượt đặt bàn hôm nay để chuyển.");
                return;
            }

            BanService tableService;
            const auto tables = tableService.getDanhSachBan();
            QStringList choices;
            QStringList ids;
            for (const auto &table : tables) {
                const QString id = QString::fromUtf8(table.getMaBan().c_str());
                const QString status = QString::fromUtf8(table.getTrangThai().c_str());
                if (id == pendingTableId ||
                    (status != "Trống" && status != "Trong") ||
                    table.getSoCho() < partySize) continue;
                ids << id;
                choices << QString("%1 · %2 · %3 chỗ")
                    .arg(id, QString::fromUtf8(table.getTenBan().c_str()))
                    .arg(table.getSoCho());
            }
            if (choices.isEmpty()) {
                QMessageBox::information(w, "Không có bàn phù hợp",
                    "Không có bàn trống đủ sức chứa để chuyển lượt đặt này.");
                return;
            }

            bool ok = false;
            const QString selected = QInputDialog::getItem(
                w, "Chuyển bàn", "Chọn bàn đích:", choices, 0, false, &ok);
            if (!ok) return;
            const int index = choices.indexOf(selected);
            if (index < 0) return;

            if (QMessageBox::question(w, "Xác nhận chuyển bàn",
                QString("Chuyển lượt đặt %1 từ bàn %2 sang bàn %3?")
                    .arg(bookingId, pendingTableId, ids[index]),
                QMessageBox::Yes | QMessageBox::No, QMessageBox::No) != QMessageBox::Yes)
                return;

            BanService banService;
            DatBanService datBan;
            ChuyenBanService transferService(banService, datBan);
            if (!transferService.chuyenBan(
                    GiaoDienDataService::utf8(bookingId),
                    GiaoDienDataService::utf8(ids[index]))) {
                QMessageBox::warning(w, "Chuyển bàn thất bại",
                    "Không thể chuyển bàn. Hãy kiểm tra trạng thái bàn và lượt đặt.");
                return;
            }

            pendingTableId = ids[index];
            refreshSelectedTable();
            QMessageBox::information(w, "Thành công",
                "Đã chuyển lượt đặt sang bàn mới.");
        });

        refreshSelectedTable();
        return w;
    }
