#pragma once

inline const char *appStyleSheet() {
    static const char style[] = R"STYLE(
* { font-family: 'Segoe UI'; }
QLabel { color: #000000; }
/* Dialogs and alerts: consistently light background + dark text for clear contrast. */
QDialog, QMessageBox, QInputDialog { background-color: #F7FAF5; color: #202820; }
QDialog QLabel, QMessageBox QLabel, QInputDialog QLabel { color: #202820; background-color: transparent; }
QDialog QLineEdit, QDialog QTextEdit, QDialog QComboBox, QDialog QSpinBox,
QInputDialog QLineEdit { background-color: #FFFFFF; color: #202820; border: 1px solid #C9DCCB; border-radius: 7px; selection-background-color: #CDE8D0; selection-color: #17251B; padding: 6px; }
QDialog QPushButton, QMessageBox QPushButton, QInputDialog QPushButton { color: #202820; background-color: #E4EFE2; border: 1px solid #C7DCC8; border-radius: 7px; padding: 7px 16px; min-width: 64px; }
QDialog QPushButton:hover, QMessageBox QPushButton:hover, QInputDialog QPushButton:hover { background-color: #CDE3CE; border-color: #9EBFA2; }
QDialog QPushButton:pressed, QMessageBox QPushButton:pressed, QInputDialog QPushButton:pressed { background-color: #B8D5BB; }
QMainWindow, QWidget#root { background: #F5F0E4; color: #000000; }
QStackedWidget { background: #F5F0E4; border: 0; }
QStackedWidget > QWidget { background: #F5F0E4; color: #000000; }
QScrollArea#pageScroll { background: #F5F0E4; border: 0; }
QScrollArea#pageScroll QWidget#qt_scrollarea_viewport { background: #F5F0E4; }
QFrame#sidebar { background: #B9D3BA; border: 1px solid #A8C8AA; border-radius: 18px; }
QLabel#brand { color: #000000; font-size: 21px; font-weight: 700; }
QLabel#subbrand { color: #000000; font-size: 11px; }
QPushButton#nav { text-align: left; padding: 12px 15px; border: 0; border-radius: 12px; color: #000000; font-size: 14px; background: transparent; }
QPushButton#nav:hover, QPushButton#nav[active="true"] { background: #91BA96; color: #17251B; font-weight: 600; }
QFrame#panel, QFrame#stat { background: #FFFFFF; border: 1px solid #E8EEE5; border-radius: 18px; }
QLabel#pageTitle { font-size: 25px; font-weight: 700; color: #000000; }
QLabel#muted { color: #000000; font-size: 12px; }
QLabel#statTitle { color: #000000; font-size: 12px; }
QLabel#statValue { color: #000000; font-size: 25px; font-weight: 700; }
QPushButton#primary { color: #000000; background: #79A987; border: none; border-radius: 11px; padding: 11px 18px; font-weight: 600; }
QPushButton#primary:hover { background: #659875; }
QPushButton#soft { color: #000000; background: #EDF5ED; border: 1px solid #DCEADD; border-radius: 10px; padding: 9px 14px; }
QLineEdit, QComboBox, QDateEdit, QTimeEdit, QTextEdit, QSpinBox, QDoubleSpinBox { background: #FBFCF9; border: 1px solid #DDE7DC; border-radius: 10px; padding: 9px; color: #17251B; selection-background-color: #CDE8D0; selection-color: #17251B; }
QComboBox QAbstractItemView { background: #FFFFFF; color: #17251B; selection-background-color: #DDEFE0; selection-color: #17251B; border: 1px solid #D4E4D5; outline: 0; padding: 4px; }
QComboBox QAbstractItemView::item { min-height: 28px; padding: 6px 8px; background: #FFFFFF; color: #17251B; }
QComboBox QAbstractItemView::item:hover { background: #EDF7ED; color: #17251B; }
QComboBox QAbstractItemView::item:selected { background: #DDEFE0; color: #17251B; }
QComboBox::drop-down, QDateEdit::drop-down, QTimeEdit::drop-down { background: #EDF5ED; border: 0; border-left: 1px solid #DDE7DC; border-top-right-radius: 9px; border-bottom-right-radius: 9px; width: 26px; }
QCalendarWidget QWidget { background: #FFFFFF; color: #17251B; alternate-background-color: #F3F8F2; }
QCalendarWidget QToolButton { background: #E4F1E3; color: #17251B; border: 0; padding: 6px; }
QCalendarWidget QMenu { background: #FFFFFF; color: #17251B; }
QScrollArea { background: #FFFFFF; border: 0; }
QScrollArea QWidget#qt_scrollarea_viewport { background: #FFFFFF; }
QToolTip { background: #F8FCF7; color: #17251B; border: 1px solid #D4E4D5; }
QTableWidget { background: #FFFFFF; alternate-background-color: #EDF6ED; border: 1px solid #E3EDE0; gridline-color: #E3EDE0; border-radius: 12px; color: #000000; selection-background-color: #D9EED9; selection-color: #000000; }
QHeaderView::section { background: #DDEEDD; color: #000000; border: 0; border-bottom: 1px solid #DCE9D9; padding: 11px; font-weight: 600; }
QTableWidget::item { padding: 8px; color: #000000; }
QTableWidget::item:hover { background: #F5F9FF; }
QTableCornerButton::section { background: #DDEEDD; border: 0; border-bottom: 1px solid #DCE9D9; }
QTableView QHeaderView::section:vertical { background: #DDEEDD; color: #17251B; border: 0; border-right: 1px solid #DCE9D9; border-bottom: 1px solid #DCE9D9; padding: 7px; }
QTableView QTableCornerButton::section { background: #DDEEDD; border: 0; }
QLabel#pill { background: #E5F3E7; color: #000000; border-radius: 9px; padding: 5px 9px; }
)STYLE";
    return style;
}
