#pragma once
#include <QMainWindow>
#include <QString>
#include <QVector>
#include <QWidget>
#include <QFrame>
#include <QLabel>
#include <QPushButton>
#include <QCheckBox>
#include <QLineEdit>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QStackedWidget>
#include <QTableWidget>
#include <QToolButton>
#include <QAbstractItemView>
#include <QRegularExpression>
#include <QLocale>
#include <QHeaderView>
#include <QMessageBox>
#include <QDialog>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QDate>
#include <QDateTime>
#include <QDateEdit>
#include <QTimeEdit>
#include <QComboBox>
#include <QInputDialog>
#include <QGraphicsDropShadowEffect>
#include <QColor>
#include <QTime>
#include <QSpinBox>
#include <QDoubleSpinBox>
#include <QScrollArea>
#include <QSizePolicy>
#include <QTimer>
#include <QMap>
#include <QSet>
#include <memory>
#include <QVariant>
#include <QObject>
#include <functional>
#include <utility>
#include "taikhoan/TaiKhoanService.h"
#include "taikhoan/DangNhapService.h"
#include "taikhoan/PhanQuyen.h"
#include "oop/TaiKhoan.h"
#include "services/GiaoDienDataService.h"
#include "oop/DatBan.h"
#include "oop/DatCoc.h"
#include "services/DatCocService.h"
#include "oop/KhachHang.h"
#include "oop/NhanVien.h"
#include "services/BanService.h"
#include "services/KhuVucService.h"
#include "services/BoTriBanService.h"
#include "services/DatBanService.h"
#include "services/ChuyenBanService.h"
#include "services/KhachHangService.h"
#include "services/NhanVienService.h"
#include "widgets/login/DangNhapWidget.h"
#include "widgets/admin/AdminWidget.h"
#include "widgets/nhanvien/NhanVienWidget.h"
#include <vector>
#include <string>

#include <algorithm>
#include <QStringList>

#include "services/GiaoDienDataService.h"
#include "oop/Ban.h"
#include "oop/KhuVuc.h"
#include "oop/BoTriBan.h"
#include "widgets/common/AppStyle.h"

inline QLabel *label(const QString &text, const QString &id = QString()) { auto *l = new QLabel(text); if (!id.isEmpty()) l->setObjectName(id); return l; }
inline QFrame *panel() { auto *f = new QFrame; f->setObjectName("panel"); return f; }

// Template trang dung chung: thong nhat nen, le, khoang cach va tieu de.
// Cac trang chi can them widget nghiep vu vao layout, khong thay doi xu ly du lieu.
inline QVBoxLayout *createPageTemplate(QWidget *page) {
    page->setObjectName("contentPage");
    page->setStyleSheet("QWidget#contentPage{background:transparent;color:#202820;}");
    auto *layout = new QVBoxLayout(page);
    layout->setContentsMargins(14, 12, 14, 12);
    layout->setSpacing(10);
    return layout;
}
inline void addPageHeader(QVBoxLayout *layout, const QString &title,
                          const QString &subtitle = QString()) {
    layout->addWidget(label(title, "pageTitle"));
    if (!subtitle.isEmpty()) layout->addWidget(label(subtitle, "muted"));
}
inline void shadow(QWidget *w) { auto *s = new QGraphicsDropShadowEffect(w); s->setBlurRadius(22); s->setOffset(0, 4); s->setColor(QColor(47, 82, 54, 14)); w->setGraphicsEffect(s); }
namespace RestaurantWindowData {
using UiRows = GiaoDienDataService::Rows;
inline bool orderStaffCanTransferTables() { return GiaoDienDataService::layQuyenChuyenBan(); }
inline bool saveOrderStaffTransferPermission(bool enabled) { return GiaoDienDataService::capNhatQuyenChuyenBan(enabled); }
template <typename T, typename Mapper> inline UiRows mapToUiRows(const std::vector<T>& items, Mapper mapper) { UiRows rows; rows.reserve(items.size()); for (const auto& item : items) rows.push_back(mapper(item)); return rows; }
inline UiRows uiRowsFrom(const std::vector<Ban>& a) { return mapToUiRows(a, [](const Ban& x){ return GiaoDienDataService::Row{x.getMaBan(),x.getTenBan(),std::to_string(x.getSoCho()),x.getTrangThai(),x.getMaKhuVuc()}; }); }
inline UiRows uiRowsFrom(const std::vector<KhuVuc>& a) { return mapToUiRows(a, [](const KhuVuc& x){ return GiaoDienDataService::Row{x.getMaKhuVuc(),x.getTenKhuVuc(),x.getMoTa()}; }); }
inline UiRows uiRowsFrom(const std::vector<BoTriBan>& a) { return mapToUiRows(a, [](const BoTriBan& x){ return GiaoDienDataService::Row{x.getMaBan(),std::to_string(x.getCot()),std::to_string(x.getHang()),std::to_string(x.getThuTu())}; }); }
inline UiRows uiRowsFrom(const std::vector<DatBan>& a) { return mapToUiRows(a, [](const DatBan& x){ return GiaoDienDataService::Row{x.getMaDatBan(),x.getMaKH(),x.getMaBan(),x.getMaNV(),x.getNgayDat(),x.getGioDat(),std::to_string(x.getSoNguoi()),x.getTrangThai(),x.getGhiChu(),x.getNgayTao(),x.getGioTao()}; }); }
inline UiRows uiRowsFrom(const std::vector<KhachHang>& a) { return mapToUiRows(a, [](const KhachHang& x){ return GiaoDienDataService::Row{x.getMaKH(),x.getHoTen(),x.getSoDienThoai()}; }); }
inline UiRows uiRowsFrom(const std::vector<NhanVien>& a) { return mapToUiRows(a, [](const NhanVien& x){ return GiaoDienDataService::Row{x.getMaNV(),x.getHoTen(),x.getGioiTinh(),x.getNgaySinh(),x.getSoDienThoai(),x.getEmail(),x.getChucVu(),std::to_string(x.getLuong()),x.getTrangThai()}; }); }
inline UiRows uiRowsFrom(const std::vector<TaiKhoan>& a) { return mapToUiRows(a, [](const TaiKhoan& x){ return GiaoDienDataService::Row{x.getMaTK(),x.getTenDangNhap(),x.getMatKhau(),x.getVaiTro(),x.getMaNV(),x.getTrangThai()}; }); }
}
using RestaurantWindowData::uiRowsFrom; using RestaurantWindowData::orderStaffCanTransferTables; using RestaurantWindowData::saveOrderStaffTransferPermission;
class RestaurantWindow : public QMainWindow {
public: explicit RestaurantWindow(const QString&, const QString&, std::function<void()>);
private:
 QString user,userRole,pendingTableId; QVector<QPushButton*> navButtons; QVector<bool> pageInitialized; QStackedWidget *pages{}; QScrollArea *pageScroll{}; std::function<void()> onLogout; std::function<void(const QString&)> openTableInPos; std::function<void()> refreshDashboard;
 void ensurePageInitialized(int);
 void showPage(int);
 QWidget *makeDashboard();
 QWidget *makeBookingMonitorPage();
 QWidget *makeDepositMonitorPage();
 QWidget *makeDepositSettingsPage();
 QWidget *makeGenericPage(const QString &name);
 QWidget *makeFloorDesignPage();
 QWidget *makeEmployeePage();
 QWidget *makeBookingPage();
 QWidget *makeTablesPage();
 QWidget *makeDepositCollectionPage();
 QWidget *makeSettlementPage();
 QWidget *makePosPage();
};
QMainWindow *createRestaurantWindowForRole(const QString&, const QString&, std::function<void()>);
