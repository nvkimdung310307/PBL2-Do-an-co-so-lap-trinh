#include <QMainWindow>
#include <QWidget>
#include <QFrame>
#include <QLabel>
#include <QPushButton>
#include <QCheckBox>
#include <QLineEdit>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QStackedWidget>
#include <QTableWidget>
#include <QToolButton>
#include <QAbstractItemView>
#include <QRegularExpression>
#include <QLocale>
#include <QHeaderView>
#include <QMessageBox>
#include <QDialog>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QDate>
#include <QDateTime>
#include <QDateEdit>
#include <QTimeEdit>
#include <QComboBox>
#include <QInputDialog>
#include <QGraphicsDropShadowEffect>
#include <QColor>
#include <QTime>
#include <QSpinBox>
#include <QDoubleSpinBox>
#include <QScrollArea>
#include <QSizePolicy>
#include <QTimer>
#include <QMap>
#include <QSet>
#include <memory>
#include <QVariant>
#include <QObject>
#include <functional>
#include <utility>
#include "taikhoan/TaiKhoanService.h"
#include "taikhoan/DangNhapService.h"
#include "taikhoan/PhanQuyen.h"
#include "oop/TaiKhoan.h"
#include "services/GiaoDienDataService.h"
#include "oop/DatBan.h"
#include "oop/DatCoc.h"
#include "services/DatCocService.h"
#include "oop/KhachHang.h"
#include "oop/NhanVien.h"
#include "services/BanService.h"
#include "services/KhuVucService.h"
#include "services/BoTriBanService.h"
#include "services/DatBanService.h"
#include "services/ChuyenBanService.h"
#include "services/KhachHangService.h"
#include "services/NhanVienService.h"
#include "widgets/login/DangNhapWidget.h"
#include "widgets/admin/AdminWidget.h"
#include "widgets/nhanvien/NhanVienWidget.h"
#include "widgets/common/RestaurantWindowFactory.h"
#include <vector>
#include <string>

#include <algorithm>
#include <QStringList>

#include "widgets/common/RestaurantWindowFactory.h"
QWidget * RestaurantWindow::makeFloorDesignPage() {
        auto *w = new QWidget;
        auto *root = createPageTemplate(w);
        addPageHeader(root, "Thiết kế sơ đồ bàn",
                      "Chỉ Admin được cấu hình khu vực, số bàn và vị trí. Cấu hình được lưu trong file TXT.");

        // BoTriBan.txt lưu vị trí sơ đồ bàn; khởi tạo vị trí mặc định một lần.
        BoTriBanService positionService;
        if (positionService.getDanhSach().empty()) {
            QMap<QString,int> areaIndex;
            BanService tableService;
            for (const auto &tableItem : tableService.getDanhSachBan()) {
                const QString areaKey = QString::fromUtf8(tableItem.getMaKhuVuc().c_str());
                const int index = areaIndex[areaKey]++;
                positionService.datViTri(tableItem.getMaBan(), index % 4, index / 4, index + 1);
            }
        }

        auto *areaPanel = panel(); auto *areaRow = new QHBoxLayout(areaPanel);
        auto *areaBox = new QComboBox; areaBox->setMinimumWidth(210);
        auto *areaName = new QLineEdit; areaName->setPlaceholderText("Tên khu vực mới, ví dụ: Tầng 3");
        auto *areaId = new QLineEdit; areaId->setPlaceholderText("Mã khu vực, ví dụ: T3"); areaId->setMaximumWidth(150);
        auto *addArea = new QPushButton("＋ Thêm khu vực"); addArea->setObjectName("primary");
        auto *renameArea = new QPushButton("Đổi tên khu vực"); renameArea->setObjectName("soft");
        auto *deleteArea = new QPushButton("Xóa khu vực"); deleteArea->setObjectName("soft");
        areaRow->addWidget(label("Khu vực")); areaRow->addWidget(areaBox); areaRow->addWidget(areaId); areaRow->addWidget(areaName,1); areaRow->addWidget(addArea); areaRow->addWidget(renameArea); areaRow->addWidget(deleteArea);
        root->addWidget(areaPanel);

        auto *body = new QHBoxLayout; body->setSpacing(10);
        auto *left = panel(); auto *leftLayout = new QVBoxLayout(left);
        leftLayout->addWidget(label("Danh sách bàn trong khu vực", "sectionTitle"));
        auto *table = new QTableWidget(0,5); table->setHorizontalHeaderLabels({"Mã bàn","Tên bàn","Số chỗ","Cột","Hàng"});
        table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch); table->setSelectionBehavior(QAbstractItemView::SelectRows); table->setSelectionMode(QAbstractItemView::SingleSelection); table->setEditTriggers(QAbstractItemView::NoEditTriggers); table->verticalHeader()->setVisible(false); table->setMinimumHeight(120); table->setMaximumHeight(230); leftLayout->addWidget(table,0);
        auto *tableForm = new QGridLayout;
        auto *tableId = new QLineEdit; tableId->setPlaceholderText("B01");
        auto *tableName = new QLineEdit; tableName->setPlaceholderText("Bàn 01");
        auto *seats = new QSpinBox; seats->setRange(1,100); seats->setValue(4);
        auto *col = new QSpinBox; col->setRange(0,19); col->setValue(0);
        auto *row = new QSpinBox; row->setRange(0,19); row->setValue(0);
        tableForm->addWidget(label("Mã bàn"),0,0); tableForm->addWidget(tableId,1,0);
        tableForm->addWidget(label("Tên bàn"),0,1); tableForm->addWidget(tableName,1,1);
        tableForm->addWidget(label("Số chỗ"),0,2); tableForm->addWidget(seats,1,2);
        tableForm->addWidget(label("Cột (0–19)"),2,0); tableForm->addWidget(col,3,0);
        tableForm->addWidget(label("Hàng (0–19)"),2,1); tableForm->addWidget(row,3,1);
        leftLayout->addLayout(tableForm);
        auto *actions = new QHBoxLayout;
        auto *addTable = new QPushButton("＋ Thêm bàn"); addTable->setObjectName("primary");
        auto *moreTables = new QPushButton("▾ Xem thêm / Tạo nhanh bàn"); moreTables->setObjectName("soft");
        auto *saveLayout = new QPushButton("Lưu vị trí bàn"); saveLayout->setObjectName("soft");
        auto *deleteTable = new QPushButton("Xóa bàn đã chọn"); deleteTable->setObjectName("soft");
        auto *refresh = new QPushButton("↻ Làm mới"); refresh->setObjectName("soft");
        actions->addWidget(addTable); actions->addWidget(moreTables); actions->addWidget(saveLayout); actions->addWidget(deleteTable); actions->addWidget(refresh); leftLayout->addLayout(actions);
        body->addWidget(left,3);

        auto *previewPanel = panel(); auto *previewLayout = new QVBoxLayout(previewPanel);
        previewLayout->addWidget(label("Xem trước sơ đồ", "sectionTitle"));
        auto *previewScroll = new QScrollArea; previewScroll->setObjectName("floorPreviewScroll"); previewScroll->setWidgetResizable(true); previewScroll->setFrameShape(QFrame::NoFrame); previewScroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded); previewScroll->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded); previewScroll->setStyleSheet("QScrollArea#floorPreviewScroll{background:#F8FBF7;border:0;} QScrollArea#floorPreviewScroll QWidget#qt_scrollarea_viewport{background:#F8FBF7;} QScrollBar:vertical{width:10px;background:#EAF2E8;margin:1px;border-radius:5px;} QScrollBar::handle:vertical{background:#A8C8AA;min-height:24px;border-radius:5px;} QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0;}");
        auto *preview = new QWidget; preview->setStyleSheet("background:#F8FBF7;color:#17251B;"); preview->setAutoFillBackground(true); auto *previewGrid = new QGridLayout(preview); previewGrid->setSpacing(6); previewGrid->setContentsMargins(6,6,6,6); previewScroll->setWidget(preview); previewLayout->addWidget(previewScroll,1);
        body->addWidget(previewPanel,2); root->addLayout(body,0); root->addStretch(1);

        auto reloadAreas = [this,areaBox](){
            const QString current=areaBox->currentData().toString();areaBox->clear();
            KhuVucService areaService;
            for(const auto &area : areaService.getDanhSachKhuVuc())
                areaBox->addItem(QString::fromUtf8(area.getTenKhuVuc().c_str()),
                                 QString::fromUtf8(area.getMaKhuVuc().c_str()));
            const int i=areaBox->findData(current);if(i>=0)areaBox->setCurrentIndex(i);
        };
        auto reload = [this,areaBox,table,preview,previewGrid,tableId,tableName,seats,col,row](){
            while(QLayoutItem *it=previewGrid->takeAt(0)){if(it->widget())it->widget()->deleteLater();delete it;}
            table->setRowCount(0);const QString selectedArea=areaBox->currentData().toString();if(selectedArea.isEmpty())return;
            BanService tableService;
            BoTriBanService positionService;
            const auto tableRows = tableService.getDanhSachBan();
            const auto positions = positionService.getDanhSach();
            std::vector<std::pair<int,int>> usedPositions;
            for (const auto& pos : positions) {
                for (const auto& tableItem : tableRows) {
                    if (tableItem.getMaBan() == pos.getMaBan() &&
                        QString::fromUtf8(tableItem.getMaKhuVuc().c_str()) == selectedArea) {
                        usedPositions.push_back({pos.getCot(), pos.getHang()});
                        break;
                    }
                }
            }
            for(const auto &tr:tableRows){
                if(QString::fromUtf8(tr.getMaKhuVuc().c_str())!=selectedArea)continue;
                const QString id=QString::fromUtf8(tr.getMaBan().c_str());
                const QString name=QString::fromUtf8(tr.getTenBan().c_str());
                const QString status=QString::fromUtf8(tr.getTrangThai().c_str());
                const QString seatsText=QString::number(tr.getSoCho());
                int x=0,y=0;bool hasPosition=false;
                for(const auto &pos:positions)if(QString::fromUtf8(pos.getMaBan().c_str())==id){x=pos.getCot();y=pos.getHang();hasPosition=true;break;}
                if(!hasPosition){
                    int index=0;
                    do { x=index%4; y=index/4; ++index; }
                    while(std::find(usedPositions.begin(),usedPositions.end(),std::make_pair(x,y))!=usedPositions.end());
                    if(positionService.datViTri(id.toStdString(),x,y,table->rowCount()+1))
                        usedPositions.push_back({x,y});
                }
                const int r=table->rowCount();table->insertRow(r);QStringList cells={id,name,seatsText,QString::number(x),QString::number(y)};for(int c=0;c<5;++c)table->setItem(r,c,new QTableWidgetItem(cells[c]));
                auto *b=new QPushButton(QString("%1\n%2 chỗ\n%3").arg(name).arg(seatsText).arg(status));b->setMinimumSize(100,72);QString bg="#BFE2C5";if(status=="Đã đặt")bg="#F8E3AF";else if(status=="Đang sử dụng")bg="#F3C8C7";else if(status=="Bảo trì")bg="#D9D9D6";b->setStyleSheet(QString("QPushButton{background:%1;border:1px solid #B7D7BE;border-radius:12px;color:#000000;padding:8px;} QPushButton:hover{border:2px solid #4F8963;}").arg(bg));previewGrid->addWidget(b,y,x);
                QObject::connect(b,&QPushButton::clicked,table,[table,id,tableId,tableName,seats,col,row](){for(int rr=0;rr<table->rowCount();++rr)if(table->item(rr,0)&&table->item(rr,0)->text()==id){table->selectRow(rr);tableId->setText(table->item(rr,0)->text());tableName->setText(table->item(rr,1)->text());seats->setValue(table->item(rr,2)->text().toInt());col->setValue(table->item(rr,3)->text().toInt());row->setValue(table->item(rr,4)->text().toInt());break;}});
            }
        };
        QObject::connect(areaBox,QOverload<int>::of(&QComboBox::currentIndexChanged),w,[reload](int){reload();});
        QObject::connect(refresh,&QPushButton::clicked,w,[reloadAreas,reload](){reloadAreas();reload();});
        QObject::connect(addArea,&QPushButton::clicked,w,[this,areaId,areaName,reloadAreas](){
            const QString id=areaId->text().trimmed(),name=areaName->text().trimmed();if(id.isEmpty()||name.isEmpty()){QMessageBox::warning(this,"Thiếu thông tin","Nhập mã và tên khu vực.");return;}
            KhuVucService areaService;
            if(!areaService.themKhuVuc(KhuVuc(id.toStdString(),name.toStdString(),""))){QMessageBox::critical(this,"Không thêm được khu vực","Mã khu vực đã tồn tại hoặc thông tin không hợp lệ.");return;}
            areaId->clear();areaName->clear();reloadAreas();QMessageBox::information(this,"Thành công","Đã tạo khu vực.");
        });
        QObject::connect(renameArea,&QPushButton::clicked,w,[this,areaBox,areaName,reloadAreas](){
            const QString id=areaBox->currentData().toString(),name=areaName->text().trimmed();if(id.isEmpty()||name.isEmpty()){QMessageBox::warning(this,"Thiếu thông tin","Chọn khu vực và nhập tên mới.");return;}
            KhuVucService areaService;
            const KhuVuc* current=areaService.timTheoMa(id.toStdString());
            if(!current){QMessageBox::critical(this,"Không đổi được tên","Không tìm thấy khu vực.");return;}
            const KhuVuc updated(id.toStdString(),name.toStdString(),current->getMoTa());
            if(!areaService.suaKhuVuc(id.toStdString(),updated)){QMessageBox::critical(this,"Không đổi được tên","Không thể cập nhật khu vực.");return;}
            areaName->clear();reloadAreas();QMessageBox::information(this,"Thành công","Đã đổi tên khu vực.");
        });
        QObject::connect(deleteArea,&QPushButton::clicked,w,[this,areaBox,reloadAreas,reload](){
            const QString id=areaBox->currentData().toString();if(id.isEmpty())return;if(QMessageBox::question(this,"Xóa khu vực","Chỉ xóa được khu vực chưa có bàn. Tiếp tục?",QMessageBox::Yes|QMessageBox::No)!=QMessageBox::Yes)return;
            KhuVucService areaService;
            if(!areaService.xoaKhuVuc(id.toStdString())){QMessageBox::warning(this,"Không xóa được","Khu vực không tồn tại hoặc vẫn đang có bàn.");return;}
            reloadAreas();reload();
            if (refreshDashboard) refreshDashboard();
        });
        QObject::connect(addTable,&QPushButton::clicked,w,[this,areaBox,tableId,tableName,seats,col,row,reload](){
            const QString id=tableId->text().trimmed(),name=tableName->text().trimmed(),area=areaBox->currentData().toString();if(id.isEmpty()||name.isEmpty()||area.isEmpty()){QMessageBox::warning(this,"Thiếu thông tin","Chọn khu vực và nhập mã/tên bàn.");return;}
            BanService tableService;
            if(!tableService.themBan(Ban(id.toStdString(),name.toStdString(),seats->value(),"Trống",area.toStdString()))){QMessageBox::warning(this,"Không thêm được bàn","Mã bàn đã tồn tại hoặc dữ liệu bàn/khu vực không hợp lệ.");return;}
            BoTriBanService positionService;
            if(!positionService.datViTri(id.toStdString(),col->value(),row->value(),0)){
                tableService.xoaBan(id.toStdString());
                QMessageBox::critical(this,"Không thêm được bàn","Không thể lưu vị trí bàn; thao tác thêm bàn đã được hoàn tác.");return;
            }
            reload();QMessageBox::information(this,"Thành công","Đã thêm bàn và lưu vị trí.");
        });
        QObject::connect(moreTables,&QPushButton::clicked,w,[this,areaBox,reload](){
            QString area=areaBox->currentData().toString();
            if(area.isEmpty()){QMessageBox::information(this,"Chọn khu vực","Hãy chọn khu vực muốn tạo bàn trước.");return;}
            QDialog d(this); d.setWindowTitle("Xem thêm — Tạo nhanh nhiều bàn"); d.setMinimumWidth(430);
            QFormLayout form(&d);
            QLineEdit prefix; prefix.setText("B"); prefix.setMaxLength(6);
            QSpinBox startNo; startNo.setRange(1,9999); startNo.setValue(1);
            QSpinBox count; count.setRange(1,100); count.setValue(10);
            QSpinBox seatCount; seatCount.setRange(1,100); seatCount.setValue(4);
            QSpinBox columns; columns.setRange(1,10); columns.setValue(4);
            QLineEdit namePrefix; namePrefix.setText("Bàn");
            form.addRow("Tiền tố mã bàn",&prefix);
            form.addRow("Số bắt đầu",&startNo);
            form.addRow("Số bàn cần tạo",&count);
            form.addRow("Tên hiển thị",&namePrefix);
            form.addRow("Số chỗ mỗi bàn",&seatCount);
            form.addRow("Số cột trên sơ đồ",&columns);
            auto *note=new QLabel("Ví dụ: tiền tố B, bắt đầu 1, tạo 10 bàn → B01…B10.\\nBàn sẽ được lưu vào file TXT và tự xuất hiện trên sơ đồ.");
            note->setWordWrap(true); form.addRow(note);
            auto *buttons=new QHBoxLayout; auto *create=new QPushButton("Tạo bàn và lưu"); create->setObjectName("primary"); auto *cancel=new QPushButton("Hủy"); cancel->setObjectName("soft"); buttons->addWidget(create); buttons->addWidget(cancel); form.addRow(buttons);
            QObject::connect(cancel,&QPushButton::clicked,&d,&QDialog::reject);
            QObject::connect(create,&QPushButton::clicked,&d,&QDialog::accept);
            if(d.exec()!=QDialog::Accepted)return;
            QString pfx=prefix.text().trimmed(), nmPrefix=namePrefix.text().trimmed();
            if(pfx.isEmpty()||nmPrefix.isEmpty()){QMessageBox::warning(this,"Thiếu thông tin","Nhập tiền tố mã và tên bàn.");return;}
            BanService tableService;
            BoTriBanService positionService;
            const auto existingTables = tableService.getDanhSachBan();
            const auto existingPositions = positionService.getDanhSach();
            int created=0,colCount=columns.value();
            std::vector<std::pair<int,int>> usedPositions;
            for (const auto& pos : existingPositions) {
                for (const auto& tableItem : existingTables) {
                    if (tableItem.getMaBan() == pos.getMaBan() &&
                        tableItem.getMaKhuVuc() == area.toStdString()) {
                        usedPositions.push_back({pos.getCot(), pos.getHang()});
                        break;
                    }
                }
            }
            std::vector<std::string> createdIds;
            for(int i=0;i<count.value();++i){
                const int number=startNo.value()+i;const QString id=pfx+QString("%1").arg(number,2,10,QChar('0'));const QString nm=nmPrefix+" "+QString("%1").arg(number,2,10,QChar('0'));
                const bool duplicate=std::any_of(existingTables.begin(),existingTables.end(),[&](const Ban& item){return item.getMaBan()==id.toStdString();});
                if(duplicate)continue;
                if(!tableService.themBan(Ban(id.toStdString(),nm.toStdString(),seatCount.value(),"Trống",area.toStdString())))continue;
                int cell=0, newCol=0, newRow=0;
                do { newCol=cell%colCount; newRow=cell/colCount; ++cell; }
                while(std::find(usedPositions.begin(),usedPositions.end(),std::make_pair(newCol,newRow))!=usedPositions.end());
                if(!positionService.datViTri(id.toStdString(),newCol,newRow,number)){
                    tableService.xoaBan(id.toStdString());
                    for(const auto& rollbackId:createdIds){tableService.xoaBan(rollbackId);positionService.xoaViTri(rollbackId);}
                    QMessageBox::critical(this,"Không lưu được","Không thể lưu vị trí bàn. Các bàn vừa tạo đã được hoàn tác.");return;
                }
                usedPositions.push_back({newCol,newRow});
                createdIds.push_back(id.toStdString());++created;
            }
            d.accept(); reload();
            if (refreshDashboard) refreshDashboard();
            QMessageBox::information(this,"Đã tạo bàn",QString("Đã tạo %1 bàn trong khu vực đã chọn. Sơ đồ được cập nhật tự động.").arg(created));
        });
        QObject::connect(table,&QTableWidget::itemSelectionChanged,w,[table,tableId,tableName,seats,col,row](){int r=table->currentRow();if(r<0)return;tableId->setText(table->item(r,0)->text());tableName->setText(table->item(r,1)->text());seats->setValue(table->item(r,2)->text().toInt());col->setValue(table->item(r,3)->text().toInt());row->setValue(table->item(r,4)->text().toInt());});
        QObject::connect(saveLayout,&QPushButton::clicked,w,[this,table,tableId,tableName,seats,col,row,reload](){
            const int r=table->currentRow();if(r<0){QMessageBox::information(this,"Chọn bàn","Chọn một bàn trong danh sách trước.");return;}const QString id=table->item(r,0)->text();
            BanService tableService;
            const Ban* current=tableService.timBan(id.toStdString());
            if(!current){QMessageBox::critical(this,"Không lưu được","Không tìm thấy bàn.");return;}
            const Ban updated(id.toStdString(),tableName->text().trimmed().toStdString(),seats->value(),current->getTrangThai(),current->getMaKhuVuc());
            if(!tableService.suaBan(id.toStdString(),updated)){QMessageBox::critical(this,"Không lưu được","Thông tin bàn không hợp lệ hoặc không thể cập nhật.");return;}
            BoTriBanService positionService;
            if(!positionService.datViTri(id.toStdString(),col->value(),row->value(),0)){QMessageBox::critical(this,"Không lưu được","Đã cập nhật thông tin bàn nhưng không lưu được vị trí sơ đồ.");return;}
            reload();
            if (refreshDashboard) refreshDashboard();
            QMessageBox::information(this,"Đã lưu","Đã lưu thông tin và vị trí bàn. Sơ đồ trang chủ đã được cập nhật.");
        });
        QObject::connect(deleteTable,&QPushButton::clicked,w,[this,table,reload](){
            const int r=table->currentRow();if(r<0){QMessageBox::information(this,"Chọn bàn","Chọn bàn cần xóa.");return;}const QString id=table->item(r,0)->text();if(QMessageBox::question(this,"Xóa bàn","Chỉ xóa bàn chưa có lịch đặt/hóa đơn liên quan. Tiếp tục?",QMessageBox::Yes|QMessageBox::No)!=QMessageBox::Yes)return;
            BanService tableService;
            if(!tableService.xoaBan(id.toStdString())){QMessageBox::warning(this,"Không xóa được","Bàn không tồn tại, không ở trạng thái trống hoặc đang có lịch đặt liên quan.");return;}
            BoTriBanService positionService;
            if(!positionService.xoaViTri(id.toStdString())){QMessageBox::warning(this,"Đã xóa bàn","Bàn đã được xóa nhưng không thể xóa vị trí khỏi sơ đồ.");return;}
            reload();
            if (refreshDashboard) refreshDashboard();
        });
        reloadAreas(); reload(); return w;
    }

QWidget * RestaurantWindow::makeEmployeePage() {
        auto *w = new QWidget;
        auto *root = createPageTemplate(w);
        addPageHeader(root, "Nhân viên & tài khoản",
                      "Admin tạo tài khoản và phân quyền theo chức vụ: Phục Vụ hoặc Thu ngân. Xác thực Admin trước khi cấp lại mật khẩu, cập nhật trạng thái hoặc xóa tài khoản. Mật khẩu được mã hóa một chiều; mật khẩu mới chỉ hiển thị sau khi cấp.");

        auto *formPanel = panel();
        auto *formLayout = new QVBoxLayout(formPanel);
        formLayout->addWidget(label("＋  Tạo nhân viên mới", "pageTitle"));
        auto *form = new QGridLayout;
        auto *fullName = new QLineEdit; fullName->setPlaceholderText("Họ và tên nhân viên");
        auto *username = new QLineEdit; username->setPlaceholderText("Tên đăng nhập duy nhất");
        auto *password = new QLineEdit; password->setPlaceholderText("Mật khẩu ban đầu (ít nhất 10 ký tự)"); password->setEchoMode(QLineEdit::Password);
        auto *showInitialPassword = new QPushButton("Hiện"); showInitialPassword->setObjectName("soft"); showInitialPassword->setCheckable(true);
        connect(showInitialPassword, &QPushButton::toggled, password, [password, showInitialPassword](bool visible) {
            password->setEchoMode(visible ? QLineEdit::Normal : QLineEdit::Password);
            showInitialPassword->setText(visible ? "Ẩn" : "Hiện");
        });
        auto *passwordField = new QWidget; auto *passwordFieldLayout = new QHBoxLayout(passwordField);
        passwordFieldLayout->setContentsMargins(0,0,0,0); passwordFieldLayout->setSpacing(6);
        passwordFieldLayout->addWidget(password,1); passwordFieldLayout->addWidget(showInitialPassword);
        auto *phone = new QLineEdit; phone->setPlaceholderText("Số điện thoại");
        auto *email = new QLineEdit; email->setPlaceholderText("Email");
        auto *gender = new QComboBox; gender->addItems({"Chưa cập nhật", "Nam", "Nữ", "Khác"});
        auto *birthDate = new QDateEdit(QDate(2000,1,1)); birthDate->setCalendarPopup(true); birthDate->setDisplayFormat("dd/MM/yyyy"); birthDate->setSpecialValueText("Chưa cập nhật"); birthDate->setMinimumDate(QDate(1900,1,1));
        auto *position = new QComboBox; position->addItems({"Phục Vụ", "Thu ngân"});
        auto *salary = new QDoubleSpinBox; salary->setRange(0,1000000000); salary->setDecimals(0); salary->setSuffix(" đ/tháng"); salary->setSingleStep(500000);
        form->addWidget(label("Họ và tên"),0,0); form->addWidget(fullName,1,0);
        form->addWidget(label("Tên đăng nhập"),0,1); form->addWidget(username,1,1);
        form->addWidget(label("Mật khẩu ban đầu"),0,2); form->addWidget(passwordField,1,2);
        form->addWidget(label("Số điện thoại"),2,0); form->addWidget(phone,3,0);
        form->addWidget(label("Email"),2,1); form->addWidget(email,3,1);
        form->addWidget(label("Giới tính"),2,2); form->addWidget(gender,3,2);
        form->addWidget(label("Ngày sinh"),4,0); form->addWidget(birthDate,5,0);
        form->addWidget(label("Chức vụ"),4,1); form->addWidget(position,5,1);
        form->addWidget(label("Lương"),4,2); form->addWidget(salary,5,2);
        formLayout->addLayout(form);
        auto *createButton = new QPushButton("Tạo nhân viên và cấp tài khoản"); createButton->setObjectName("primary");
        formLayout->addWidget(createButton,0,Qt::AlignLeft);
        root->addWidget(formPanel);

        auto *listPanel = panel(); auto *listLayout = new QVBoxLayout(listPanel);
        auto *toolbar = new QHBoxLayout;
        auto *filter = new QLineEdit; filter->setPlaceholderText("Tìm nhân viên, tên đăng nhập, điện thoại...");
        auto *refresh = new QPushButton("Làm mới"); refresh->setObjectName("soft");
        auto *toggle = new QPushButton("Khóa / mở tài khoản"); toggle->setObjectName("soft");
        auto *remove = new QPushButton("Xóa tài khoản"); remove->setObjectName("primary"); remove->setStyleSheet("QPushButton#primary{background:#C96F68;}");
        auto *resetPassword = new QPushButton("Đặt lại mật khẩu"); resetPassword->setObjectName("soft");
        toolbar->addWidget(filter,1); toolbar->addWidget(refresh); toolbar->addWidget(toggle); toolbar->addWidget(resetPassword); toolbar->addWidget(remove); listLayout->addLayout(toolbar);
        auto *table = new QTableWidget(0,10); table->setHorizontalHeaderLabels({"Mã NV","Họ tên","Tên đăng nhập","Điện thoại","Email","Chức vụ","Vai trò","Trạng thái","Mật khẩu","Thao tác"}); table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch); table->verticalHeader()->setVisible(false); table->setSelectionBehavior(QAbstractItemView::SelectRows); table->setSelectionMode(QAbstractItemView::SingleSelection); table->setEditTriggers(QAbstractItemView::NoEditTriggers); listLayout->addWidget(table,1); root->addWidget(listPanel,1);

        auto loadEmployees = [this,table]() {
            table->setRowCount(0);
            NhanVienService employeeService;
            const auto employees = employeeService.getDanhSachNhanVienCoTaiKhoan();
            for (const auto& record : employees) {
                const auto& employee = record.nhanVien;
                const auto& account = record.taiKhoan;
                const QString role = QString::fromUtf8(account.getVaiTro().c_str());
                const QString employeeId = QString::fromUtf8(employee.getMaNV().c_str());
                const int r=table->rowCount();table->insertRow(r);
                const QString accountId=QString::fromUtf8(account.getMaTK().c_str());
                const QList<QString> values={employeeId,QString::fromUtf8(employee.getHoTen().c_str()),
                    QString::fromUtf8(account.getTenDangNhap().c_str()),
                    QString::fromUtf8(employee.getSoDienThoai().c_str()),
                    QString::fromUtf8(employee.getEmail().c_str()),
                    QString::fromUtf8(employee.getChucVu().c_str()),role,
                    QString::fromUtf8(account.getTrangThai().c_str()),QStringLiteral("••••••••••")};
                for(int c=0;c<values.size();++c){auto *it=new QTableWidgetItem(values[c]);if(c==0)it->setData(Qt::UserRole,accountId);if(c==8){it->setToolTip("Mật khẩu được lưu bằng PBKDF2 nên không thể xem ngược mật khẩu cũ. Nhấn nút Xem để xác thực Admin và cấp mật khẩu mới nếu cần.");it->setForeground(QColor("#597260"));}table->setItem(r,c,it);}
                auto *viewPassword=new QPushButton("👁 Xem / cấp lại");viewPassword->setObjectName("soft");viewPassword->setCursor(Qt::PointingHandCursor);
                QObject::connect(viewPassword,&QPushButton::clicked,this,[this,accountId,table,r](){
                    if(userRole!="Admin"){QMessageBox::warning(this,"Không đủ quyền","Chỉ Admin mới được xem/cấp lại mật khẩu nhân viên.");return;}bool ok=false;const QString adminUsername=QInputDialog::getText(this,"Xác thực Admin","Nhập tên đăng nhập Admin:",QLineEdit::Normal,QString(),&ok).trimmed();if(!ok||adminUsername.isEmpty())return;const QString adminPassword=QInputDialog::getText(this,"Xác thực Admin","Nhập mật khẩu Admin để tiếp tục:",QLineEdit::Password,QString(),&ok);if(!ok)return;
                    TaiKhoanService accountService;DangNhapService loginService(accountService);const TaiKhoan *verified=loginService.dangNhap(adminUsername.toStdString(),adminPassword.toStdString());if(!verified||(verified->getVaiTro()!="Admin"&&verified->getVaiTro()!="Quản lý")){QMessageBox::warning(this,"Xác thực thất bại","Tên đăng nhập/mật khẩu Admin không đúng hoặc tài khoản không có quyền Admin.");return;}
                    QMessageBox::information(this,"Không thể khôi phục mật khẩu cũ","Mật khẩu cũ được lưu bằng PBKDF2 nên không thể giải mã. Bạn có thể cấp mật khẩu mới rồi xem mật khẩu mới một lần để gửi cho nhân viên.");const QString newPassword=QInputDialog::getText(this,"Cấp mật khẩu mới","Nhập mật khẩu mới (ít nhất 10 ký tự):",QLineEdit::Password,QString(),&ok);if(!ok)return;if(newPassword.size()<10){QMessageBox::warning(this,"Mật khẩu chưa hợp lệ","Mật khẩu phải có ít nhất 10 ký tự.");return;}
                    if(!accountService.capLaiMatKhau(accountId.toStdString(),newPassword.toStdString())){QMessageBox::critical(this,"Không cấp được mật khẩu","Tài khoản không tồn tại, không hoạt động hoặc không thể cập nhật mật khẩu.");return;}
                    if(table->item(r,8))table->item(r,8)->setText(newPassword);QMessageBox::information(this,"Mật khẩu mới đã được cấp",QString("Mật khẩu mới của nhân viên là:\n\n%1\n\nHãy chuyển mật khẩu này trực tiếp cho nhân viên. Mật khẩu sẽ không thể xem lại sau khi đóng/mở lại trang.").arg(newPassword));
                });table->setCellWidget(r,9,viewPassword);
            }
        };
        // Nhan dup vao nhan vien de xem day du ho so; Admin co the sua thong tin tai day.
        connect(table, &QTableWidget::cellDoubleClicked, this, [this, table, loadEmployees](int row, int) {
            if (row < 0 || !table->item(row, 0)) return;
            const QString employeeId = table->item(row, 0)->text();
            const QString accountId = table->item(row, 0)->data(Qt::UserRole).toString();
            NhanVienService employeeService;
            TaiKhoanService accountService;
            const NhanVien *employee = employeeService.timTheoMa(employeeId.toStdString());
            const TaiKhoan *account = accountService.timTheoMa(accountId.toStdString());
            if (!employee || !account) {
                QMessageBox::warning(this, "Không tìm thấy hồ sơ", "Không đọc được đầy đủ thông tin nhân viên hoặc tài khoản trong file TXT.");
                return;
            }

            const QString name = QString::fromUtf8(employee->getHoTen().c_str());
            const QString gender = QString::fromUtf8(employee->getGioiTinh().c_str());
            const QString birth = QString::fromUtf8(employee->getNgaySinh().c_str());
            const QString phoneValue = QString::fromUtf8(employee->getSoDienThoai().c_str());
            const QString emailValue = QString::fromUtf8(employee->getEmail().c_str());
            const QString positionValue = QString::fromUtf8(employee->getChucVu().c_str());
            const double salaryValue = employee->getLuong();
            const QString employeeStatus = QString::fromUtf8(employee->getTrangThai().c_str());
            const QString accountName = QString::fromUtf8(account->getTenDangNhap().c_str());
            const QString accountRole = QString::fromUtf8(account->getVaiTro().c_str());
            const QString accountStatus = QString::fromUtf8(account->getTrangThai().c_str());

            QDialog dialog(this);
            dialog.setWindowTitle("Thông tin nhân viên - " + employeeId);
            dialog.setMinimumSize(560, 560);
            auto *layout = new QVBoxLayout(&dialog);
            layout->setContentsMargins(24, 22, 24, 22);
            layout->setSpacing(12);
            layout->addWidget(label("HỒ SƠ NHÂN VIÊN", "pageTitle"));
            auto *details = new QFormLayout;
            details->setLabelAlignment(Qt::AlignLeft);
            auto addDetail = [details](const QString &caption, const QString &value) {
                auto *valueLabel = new QLabel(value.isEmpty() ? "Chưa cập nhật" : value);
                valueLabel->setWordWrap(true);
                valueLabel->setTextInteractionFlags(Qt::TextSelectableByMouse);
                details->addRow(caption + ":", valueLabel);
            };
            QString birthDisplay = birth;
            if (!birthDisplay.isEmpty()) { const QDate date = QDate::fromString(birthDisplay, "yyyy-MM-dd"); if (date.isValid()) birthDisplay = date.toString("dd/MM/yyyy"); }
            addDetail("Mã nhân viên", employeeId);
            addDetail("Họ và tên", name);
            addDetail("Giới tính", gender);
            addDetail("Ngày sinh", birthDisplay);
            addDetail("Số điện thoại", phoneValue);
            addDetail("Email", emailValue);
            addDetail("Chức vụ", positionValue);
            addDetail("Lương", QLocale(QLocale::Vietnamese).toString(salaryValue, 'f', 0) + " đ/tháng");
            addDetail("Trạng thái nhân viên", employeeStatus);
            addDetail("Mã tài khoản", accountId);
            addDetail("Tên đăng nhập", accountName);
            addDetail("Vai trò hệ thống", accountRole);
            addDetail("Trạng thái tài khoản", accountStatus);
            addDetail("Mật khẩu", "Đã được mã hóa; không thể xem mật khẩu gốc");
            layout->addLayout(details);

            auto *buttons = new QHBoxLayout;
            auto *editButton = new QPushButton("Chỉnh sửa thông tin"); editButton->setObjectName("primary");
            auto *closeButton = new QPushButton("Đóng"); closeButton->setObjectName("soft");
            buttons->addStretch(); buttons->addWidget(editButton); buttons->addWidget(closeButton);
            layout->addLayout(buttons);
            connect(closeButton, &QPushButton::clicked, &dialog, &QDialog::accept);
            connect(editButton, &QPushButton::clicked, &dialog, [this, &dialog, employeeId, name, gender, birth, phoneValue, emailValue, positionValue, salaryValue, employeeStatus, loadEmployees]() {
                if (userRole != "Admin") {
                    QMessageBox::warning(&dialog, "Không đủ quyền", "Chỉ Admin mới được chỉnh sửa hồ sơ nhân viên.");
                    return;
                }
                QDialog editDialog(&dialog);
                editDialog.setWindowTitle("Chỉnh sửa nhân viên - " + employeeId);
                editDialog.setMinimumWidth(460);
                QFormLayout form(&editDialog);
                auto *editName = new QLineEdit(name);
                auto *editGender = new QComboBox; editGender->addItems({"Chưa cập nhật", "Nam", "Nữ", "Khác"});
                int genderIndex = editGender->findText(gender.isEmpty() ? "Chưa cập nhật" : gender);
                if (genderIndex >= 0) editGender->setCurrentIndex(genderIndex);
                auto *editBirth = new QDateEdit; editBirth->setCalendarPopup(true); editBirth->setDisplayFormat("dd/MM/yyyy");
                editBirth->setMinimumDate(QDate(1900,1,1)); editBirth->setSpecialValueText("Chưa cập nhật");
                const QDate parsedBirth = QDate::fromString(birth, "yyyy-MM-dd");
                editBirth->setDate(parsedBirth.isValid() ? parsedBirth : editBirth->minimumDate());
                auto *editPhone = new QLineEdit(phoneValue);
                auto *editEmail = new QLineEdit(emailValue);
                auto *editPosition = new QComboBox;
                editPosition->addItems({"Phục Vụ", "Thu ngân"});
                if (!positionValue.isEmpty() && editPosition->findText(positionValue) < 0)
                    editPosition->addItem(positionValue);
                editPosition->setCurrentText(positionValue.isEmpty() ? "Phục Vụ" : positionValue);
                auto *editSalary = new QDoubleSpinBox; editSalary->setRange(0,1000000000); editSalary->setDecimals(0); editSalary->setSuffix(" đ/tháng"); editSalary->setValue(salaryValue);
                auto *editStatus = new QComboBox; editStatus->addItems({"Đang làm", "Tạm nghỉ", "Đã nghỉ việc"});
                int statusIndex = editStatus->findText(employeeStatus); if (statusIndex < 0 && !employeeStatus.isEmpty()) editStatus->addItem(employeeStatus); editStatus->setCurrentText(employeeStatus.isEmpty() ? "Đang làm" : employeeStatus);
                form.addRow("Mã nhân viên:", new QLabel(employeeId + " (không thể sửa)"));
                form.addRow("Họ và tên:", editName);
                form.addRow("Giới tính:", editGender);
                form.addRow("Ngày sinh:", editBirth);
                form.addRow("Số điện thoại:", editPhone);
                form.addRow("Email:", editEmail);
                form.addRow("Chức vụ:", editPosition);
                form.addRow("Lương:", editSalary);
                form.addRow("Trạng thái nhân viên:", editStatus);
                auto *editButtons = new QDialogButtonBox(QDialogButtonBox::Save | QDialogButtonBox::Cancel);
                form.addRow(editButtons);
                connect(editButtons, &QDialogButtonBox::rejected, &editDialog, &QDialog::reject);
                connect(editButtons, &QDialogButtonBox::accepted, &editDialog, [&]() {
                    const QString newName = editName->text().trimmed();
                    const QString newPhone = editPhone->text().trimmed();
                    const QString newEmail = editEmail->text().trimmed();
                    if (newName.isEmpty()) { QMessageBox::warning(&editDialog, "Thiếu thông tin", "Họ tên không được để trống."); return; }
                    if (!newPhone.isEmpty() && !QRegularExpression("^[0-9+(). -]{8,15}$").match(newPhone).hasMatch()) { QMessageBox::warning(&editDialog, "Số điện thoại không hợp lệ", "Kiểm tra lại số điện thoại (8–15 ký tự số). "); return; }
                    if (!newEmail.isEmpty() && !QRegularExpression("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$").match(newEmail).hasMatch()) { QMessageBox::warning(&editDialog, "Email không hợp lệ", "Vui lòng nhập email đúng định dạng."); return; }
                    const QString newGender = editGender->currentText() == "Chưa cập nhật" ? QString() : editGender->currentText();
                    const QString newBirth = editBirth->date() == editBirth->minimumDate() ? QString() : editBirth->date().toString("yyyy-MM-dd");
                    NhanVien updated(employeeId.toStdString(), newName.toStdString(), newGender.toStdString(), newBirth.toStdString(),
                        newPhone.toStdString(), newEmail.toStdString(), editPosition->currentText().trimmed().toStdString(),
                        editSalary->value(), editStatus->currentText().toStdString());
                    NhanVienService service;
                    if (!service.suaNhanVien(employeeId.toStdString(), updated)) {
                        QMessageBox::critical(&editDialog, "Không lưu được", "Không thể cập nhật hồ sơ. Có thể số điện thoại đã được sử dụng hoặc dữ liệu không hợp lệ.");
                        return;
                    }
                    editDialog.accept();
                    dialog.accept();
                    loadEmployees();
                    QMessageBox::information(this, "Đã cập nhật", "Thông tin nhân viên đã được lưu vào NhanVien.txt.");
                });
                editDialog.exec();
            });
            dialog.exec();
        });
        connect(refresh,&QPushButton::clicked,this,loadEmployees);
        connect(resetPassword,&QPushButton::clicked,this,[this,selectedAccountId=std::function<QString()>([table](){int r=table->currentRow(); if(r<0||!table->item(r,0)) return QString(); return table->item(r,0)->data(Qt::UserRole).toString();}),loadEmployees](){
            if(userRole!="Admin"){QMessageBox::warning(this,"Không đủ quyền","Chỉ Admin được đặt lại mật khẩu nhân viên.");return;}
            const QString id=selectedAccountId();
            if(id.isEmpty()){QMessageBox::information(this,"Chọn nhân viên","Hãy chọn một dòng nhân viên trước.");return;}
            bool ok=false; const QString pw=QInputDialog::getText(this,"Đặt lại mật khẩu","Nhập mật khẩu mới (ít nhất 10 ký tự):",QLineEdit::Password,QString(),&ok);
            if(!ok)return;
            if(pw.size()<10){QMessageBox::warning(this,"Mật khẩu chưa hợp lệ","Mật khẩu phải có ít nhất 10 ký tự.");return;}
            TaiKhoanService accountService;
            if(!accountService.capLaiMatKhau(id.toStdString(),pw.toStdString())){QMessageBox::critical(this,"Không đặt lại được mật khẩu","Tài khoản không tồn tại, không hoạt động hoặc không thể cập nhật mật khẩu.");return;}
            loadEmployees(); QMessageBox::information(this,"Thành công","Đã đặt lại mật khẩu trong TaiKhoan.txt. Mật khẩu mới không được hiển thị trong danh sách.");
        });
        connect(filter,&QLineEdit::textChanged,this,[table](const QString &text){for(int r=0;r<table->rowCount();++r){bool match=false;for(int c=0;c<table->columnCount();++c) if(table->item(r,c)&&table->item(r,c)->text().contains(text,Qt::CaseInsensitive)) match=true; table->setRowHidden(r,!match);}});
        connect(createButton,&QPushButton::clicked,this,[=]() {
            const QString name=fullName->text().trimmed(), login=username->text().trimmed(), pw=password->text();
            if(name.isEmpty()||login.isEmpty()||pw.size()<10){QMessageBox::warning(this,"Thiếu thông tin","Nhập họ tên, tên đăng nhập và mật khẩu từ 10 ký tự trở lên.");return;}
            if(login.contains(QRegularExpression("\\s"))){QMessageBox::warning(this,"Tên đăng nhập không hợp lệ","Tên đăng nhập không được chứa khoảng trắng.");return;}
            NhanVienService employeeService;
            const TaoNhanVienTaiKhoanRequest request{
                name.toStdString(), login.toStdString(), pw.toStdString(),
                gender->currentText()=="Chưa cập nhật" ? "" : gender->currentText().toStdString(),
                birthDate->date()==QDate(2000,1,1) ? "" : birthDate->date().toString("yyyy-MM-dd").toStdString(),
                phone->text().trimmed().toStdString(), email->text().trimmed().toStdString(),
                position->currentText().toStdString(), salary->value()
            };
            const auto result = employeeService.taoNhanVienVaTaiKhoan(request);
            if (result.status == TaoNhanVienTaiKhoanStatus::TenDangNhapDaTonTai) { QMessageBox::warning(this,"Tên đăng nhập đã tồn tại","Hãy chọn tên đăng nhập khác."); return; }
            if (result.status == TaoNhanVienTaiKhoanStatus::KhongTaoDuocMa) { QMessageBox::critical(this,"Không tạo được mã","Không thể cấp mã nhân viên hoặc tài khoản."); return; }
            if (result.status == TaoNhanVienTaiKhoanStatus::LoiNhanVien) { QMessageBox::critical(this,"Không lưu được nhân viên","Thông tin nhân viên không hợp lệ hoặc mã/số điện thoại đã tồn tại."); return; }
            if (result.status == TaoNhanVienTaiKhoanStatus::LoiTaiKhoan) { QMessageBox::critical(this,"Không lưu được tài khoản","Không thể tạo tài khoản. Hồ sơ nhân viên vừa tạo đã được hoàn tác."); return; }
            const QString maNV = QString::fromStdString(result.maNhanVien);
            fullName->clear();username->clear();password->clear();phone->clear();email->clear();salary->setValue(0);
            loadEmployees(); QMessageBox::information(this,"Đã tạo tài khoản",QString("Đã lưu nhân viên và tài khoản vào file TXT.\nMã nhân viên: %1\nTên đăng nhập: %2\nVai trò: Nhân viên").arg(maNV,login));
        });
        auto selectedAccountId=[table]()->QString {int r=table->currentRow();if(r<0||!table->item(r,0))return QString();return table->item(r,0)->data(Qt::UserRole).toString();};
        connect(toggle,&QPushButton::clicked,this,[this,selectedAccountId,loadEmployees](){
            const QString id=selectedAccountId();if(id.isEmpty()){QMessageBox::information(this,"Chọn nhân viên","Hãy chọn một dòng nhân viên trước.");return;}
            TaiKhoanService accountService;const TaiKhoan* account=accountService.timTheoMa(id.toStdString());
            if(!account){QMessageBox::critical(this,"Không cập nhật được","Không tìm thấy tài khoản.");return;}
            const QString nextStatus=(account->getTrangThai()=="Hoạt động"||account->getTrangThai()=="HoatDong")?QStringLiteral("Bị khóa"):QStringLiteral("Hoạt động");
            if(!accountService.capNhatTrangThai(id.toStdString(),nextStatus.toStdString())){QMessageBox::critical(this,"Không cập nhật được","Không thể thay đổi trạng thái tài khoản.");return;}
            loadEmployees();
        });
        connect(remove,&QPushButton::clicked,this,[this,selectedAccountId,loadEmployees](){
            const QString id=selectedAccountId();if(id.isEmpty()){QMessageBox::information(this,"Chọn nhân viên","Hãy chọn tài khoản cần xóa.");return;}
            if(QMessageBox::question(this,"Xóa tài khoản","Xóa tài khoản đăng nhập này? Thông tin nhân viên được giữ lại để bảo toàn lịch sử hóa đơn/đặt bàn.",QMessageBox::Yes|QMessageBox::No,QMessageBox::No)!=QMessageBox::Yes)return;
            TaiKhoanService accountService;
            if(!accountService.xoaTaiKhoan(id.toStdString())){QMessageBox::critical(this,"Không xóa được tài khoản","Tài khoản không tồn tại hoặc không thể xóa (ví dụ tài khoản Admin cuối cùng).");return;}
            loadEmployees();QMessageBox::information(this,"Đã xóa","Đã xóa tài khoản đăng nhập. Hồ sơ nhân viên được giữ lại cho dữ liệu lịch sử.");
        });
        if(userRole=="Admin") loadEmployees();
        return w;
    }

QMainWindow *createAdminWidget(const QString &username, std::function<void()> logoutCallback) {
    return createRestaurantWindowForRole(username, QStringLiteral("Admin"), std::move(logoutCallback));
}
