#pragma once
#include <QMainWindow>
#include <QString>
#include <functional>

QMainWindow *createAdminWidget(const QString &username, std::function<void()> logoutCallback);
