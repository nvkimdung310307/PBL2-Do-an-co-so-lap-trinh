#ifndef GIAO_DIEN_DATA_SERVICE_H
#define GIAO_DIEN_DATA_SERVICE_H

#include <QString>
#include <string>
#include <vector>
#include <cstddef>

// Service trung gian cho Presentation: cung cap du lieu phuc vu hien thi
// va la dau moi duy nhat de giao dien doc/ghi cac bang TXT phu chua co Service
// nghiep vu rieng. Khong de Widgets truy cap TextFileManager truc tiep.
// Cac nghiep vu CRUD chinh van phai nam trong BanService, DatBanService, ...
class GiaoDienDataService {
public:
    using Row = std::vector<std::string>;
    using Rows = std::vector<Row>;
    // Cac API du lieu theo nghiep vu; Presentation khong can biet ten file luu tru.
    static bool layQuyenChuyenBan();
    static bool capNhatQuyenChuyenBan(bool enabled);
    static bool layMucCocDatBan(Rows& rows);
    static bool luuMucCocDatBan(const Rows& rows);
    static bool layLichSuQuyetToan(Rows& rows);
    static bool luuLichSuQuyetToan(const Rows& rows);
    static bool layCauHinhDatCoc(Rows& rows);
    static bool luuCauHinhDatCoc(const Rows& rows);
    static bool capNhatMucCocTheoKhuVuc(const std::string& maKhuVuc, long long soTien);
    static bool chotMucCocChoDatBan(const std::string& maDatBan, const std::string& maBan);
    static QString lastDataError();
    static std::string utf8(const QString &value);
    static QString value(const Row &row, size_t index);
    static bool activeBooking(const QString &status);
    static QString employeeId(const QString &username);
    static QString customerName(const QString &id);
    static QString tableName(const QString &id);
    static QString areaName(const QString &id);
    static QString dateToday();
};

#endif
