#include "BoTriBanService.h"
#include "data/TextFileManager.h"
#include "BanService.h"
#include <algorithm>
#include <set>
#include <utility>
#include <iterator>
#include <tuple>
using namespace std;

bool layKhuVucBan(const string& maBan, string& maKhuVuc) {
    BanService banService;
    const Ban* ban = banService.timBan(maBan);
    if (!ban) return false;
    maKhuVuc = ban->getMaKhuVuc();
    return true;
}
bool tonTaiBan(const string& maBan) {
    string maKhuVuc;
    return !maBan.empty() && layKhuVucBan(maBan, maKhuVuc);
}
bool cungKhuVuc(const string& maBanA, const string& maBanB) {
    string khuVucA, khuVucB;
    return layKhuVucBan(maBanA, khuVucA) &&
           layKhuVucBan(maBanB, khuVucB) && khuVucA == khuVucB;
}
bool trungViTri(const vector<BoTriBan>& ds,
                const string& boQuaId,
                int cot, int hang) {
    return any_of(ds.begin(), ds.end(), [&](const BoTriBan& item) {
        return item.getMaBan() != boQuaId &&
               item.getCot() == cot && item.getHang() == hang &&
               cungKhuVuc(item.getMaBan(), boQuaId);
    });
}
bool hopLeCauTruc(const vector<BoTriBan>& ds) {
    set<string> maBans;
    for (const auto& item : ds) {
        if (!item.hopLe() || !maBans.insert(item.getMaBan()).second) return false;
    }
    for (size_t i = 0; i < ds.size(); ++i) {
        string areaI;
        // Vi tri khong duoc tham chieu den ban da bi xoa/khong ton tai.
        if (!layKhuVucBan(ds[i].getMaBan(), areaI)) return false;
        for (size_t j = i + 1; j < ds.size(); ++j) {
            string areaJ;
            if (!layKhuVucBan(ds[j].getMaBan(), areaJ)) return false;
            if (areaI == areaJ &&
                ds[i].getCot() == ds[j].getCot() && ds[i].getHang() == ds[j].getHang())
                return false;
        }
    }
    return true;
}
bool napDuLieuViTriTho(vector<BoTriBan>& ds) {
    vector<TextFileManager::Row> rows;
    if (!TextFileManager::read("BoTriBan.txt", rows)) return false;
    vector<BoTriBan> fresh;
    for (const auto& row : rows) {
        if (row.size() < 3) return false;
        try {
            const int order = row.size() >= 4 ? stoi(row[3]) : 0;
            fresh.emplace_back(row[0], stoi(row[1]), stoi(row[2]), order);
        } catch (...) { return false; }
    }
    if (!hopLeCauTruc(fresh)) return false;
    ds.swap(fresh);
    return true;
}
bool hopLeToanBo(const vector<BoTriBan>& ds) {
    set<string> maBans;
    set<tuple<string, int, int>> viTris;
    for (const auto& item : ds) {
        string maKhuVuc;
        if (!item.hopLe() || !layKhuVucBan(item.getMaBan(), maKhuVuc)) return false;
        if (!maBans.insert(item.getMaBan()).second) return false;
        if (!viTris.insert({maKhuVuc, item.getCot(), item.getHang()}).second) return false;
    }
    return true;
}
bool BoTriBanService::napDanhSach() const {
    vector<TextFileManager::Row> rows;
    if (!TextFileManager::read("BoTriBan.txt", rows)) return false;
    vector<BoTriBan> fresh;
    for (const auto& row : rows) {
        if (row.size() < 3) return false;
        try {
            const int order = row.size() >= 4 ? stoi(row[3]) : 0;
            BoTriBan item(row[0], stoi(row[1]), stoi(row[2]), order);
            if (!item.hopLe()) return false;
            fresh.push_back(item);
        } catch (...) {
            return false;
        }
    }
    if (!hopLeToanBo(fresh)) return false;
    danhSach.swap(fresh);
    return true;
}
bool BoTriBanService::ghiDanhSach() const {
    if (!hopLeToanBo(danhSach)) return false;
    vector<TextFileManager::Row> rows;
    rows.reserve(danhSach.size());
    for (const auto& item : danhSach) {
        rows.push_back({item.getMaBan(), to_string(item.getCot()),
                        to_string(item.getHang()), to_string(item.getThuTu())});
    }
    return TextFileManager::write("BoTriBan.txt", rows);
}
const vector<BoTriBan>& BoTriBanService::getDanhSach() const {
    if (!napDanhSach()) danhSach.clear();
    return danhSach;
}
bool BoTriBanService::datViTri(const string& id, int cot, int hang, int thuTu) {
    BoTriBan item(id, cot, hang, thuTu);
    if (!item.hopLe() || !tonTaiBan(id) || !napDanhSach()) return false;
    if (trungViTri(danhSach, id, cot, hang)) return false;
    auto it = find_if(danhSach.begin(), danhSach.end(),
        [&](const BoTriBan& x) { return x.getMaBan() == id; });
    if (it == danhSach.end()) danhSach.push_back(item);
    else {
        it->setCot(cot);
        it->setHang(hang);
        it->setThuTu(thuTu);
    }
    return ghiDanhSach();
}
bool BoTriBanService::doiViTri(const string& id, int cotMoi, int hangMoi,
                               const string& otherId, int cotCu, int hangCu) {
    if (id.empty() || cotMoi < 0 || hangMoi < 0 || !tonTaiBan(id) || !napDanhSach())
        return false;
    if (!otherId.empty() && (otherId == id || !tonTaiBan(otherId) || !cungKhuVuc(id, otherId))) return false;
    auto current = find_if(danhSach.begin(), danhSach.end(),
        [&](const BoTriBan& x) { return x.getMaBan() == id; });
    auto other = danhSach.end();
    if (!otherId.empty()) {
        other = find_if(danhSach.begin(), danhSach.end(),
            [&](const BoTriBan& x) { return x.getMaBan() == otherId; });
        if (other == danhSach.end()) return false;
    }
    if (trungViTri(danhSach, id, cotMoi, hangMoi) && otherId.empty()) return false;
    if (!otherId.empty() && (other->getCot() != cotMoi || other->getHang() != hangMoi))
        return false;
    const vector<BoTriBan> old = danhSach;
    if (current == danhSach.end()) {
        danhSach.emplace_back(id, cotMoi, hangMoi, 0);
        current = prev(danhSach.end());
    } else {
        current->setCot(cotMoi);
        current->setHang(hangMoi);
    }
    if (!otherId.empty()) {
        other = find_if(danhSach.begin(), danhSach.end(),
            [&](const BoTriBan& x) { return x.getMaBan() == otherId; });
        other->setCot(cotCu);
        other->setHang(hangCu);
    }
    if (!hopLeToanBo(danhSach) || !ghiDanhSach()) {
        danhSach = old;
        return false;
    }
    return true;
}
bool BoTriBanService::xoaViTri(const string& id) {
    return xoaNhieuViTri({id});
}
bool BoTriBanService::xoaNhieuViTri(const vector<string>& ids) {
    if (ids.empty()) return true;
    if (!napDuLieuViTriTho(danhSach)) return false;
    const set<string> removing(ids.begin(), ids.end());
    const auto old = danhSach;
    danhSach.erase(remove_if(danhSach.begin(), danhSach.end(),
        [&](const BoTriBan& x) { return removing.count(x.getMaBan()) != 0; }), danhSach.end());
    if (old.size() == danhSach.size()) return true;
    if (!ghiDanhSach()) {
        danhSach = old;
        return false;
    }
    return true;
}
