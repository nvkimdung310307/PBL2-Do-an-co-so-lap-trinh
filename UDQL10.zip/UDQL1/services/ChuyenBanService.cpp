#include "ChuyenBanService.h"
#include "data/TextFileManager.h"
#include <iostream>

using namespace std;

ChuyenBanService::ChuyenBanService(BanService& bs, DatBanService& dbs)
    : banService(bs), datBanService(dbs) {}

bool ChuyenBanService::chuyenBan(const string& maDatBan, const string& maBanMoi) {
    if (maDatBan.empty() || maBanMoi.empty()) return false;

    // Quyền chuyển bàn phải được Admin bật cho toàn bộ nhân viên order.
    vector<TextFileManager::Row> permissionRows;
    if (!TextFileManager::read("QuyenChuyenBan.txt", permissionRows) ||
        permissionRows.empty() || permissionRows[0].empty() || permissionRows[0][0] != "1")
        return false;

    // DatBanService da kiem tra trang thai luot dat, ban dich va dong bo Ban.txt.
    // Tranh tu ghi DatBan.txt va cap nhat Ban.txt hai lan tai day.
    const bool ok = datBanService.chuyenBanText(maDatBan, maBanMoi);
    if (ok) cout << "Chuyen ban thanh cong: " << maDatBan << " -> " << maBanMoi << '\n';
    return ok;
}
