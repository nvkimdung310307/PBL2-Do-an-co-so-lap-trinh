#ifndef KHACH_HANG_SERVICE_H
#define KHACH_HANG_SERVICE_H

#include <QString>
#include <string>
#include <vector>
#include "../oop/KhachHang.h"

// Quan ly thong tin khach hang phuc vu nghiep vu dat ban.
class KhachHangService
{
private:
    mutable std::vector<KhachHang> danhSachKhachHang;
    QString loiCuoiCung;

    bool napDanhSachText() const;
    bool ghiDanhSachText() const;

public:
    bool themKhachHang(const KhachHang& khachHang);
    bool suaKhachHang(const std::string& maKH,
                      const KhachHang& khachHangMoi);

    const KhachHang* timKhachHang(const std::string& maKH) const;
    const KhachHang* timTheoSoDienThoai(
        const std::string& soDienThoai) const;

    const std::vector<KhachHang>& getDanhSachKhachHang() const;
    std::string taoMaKhachHang(int doDai = 6) const;

    QString getLoiCuoiCung() const { return loiCuoiCung; }
};

#endif
