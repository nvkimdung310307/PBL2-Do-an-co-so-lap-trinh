#include "BanService.h"

#include "data/TextFileManager.h"
#include "KhuVucService.h"
#include "../taikhoan/PhanQuyen.h"

#include <algorithm>
#include <iomanip>
#include <iostream>
#include <sstream>

namespace
{
const char* FILE_BAN = "Ban.txt";

std::string chuanHoaTrangThai(const std::string& trangThai)
{
    if (trangThai == "Trong") return "Trống";
    if (trangThai == "Da dat") return "Đã đặt";
    if (trangThai == "Dang su dung") return "Đang sử dụng";
    if (trangThai == "Bao tri") return "Bảo trì";
    return trangThai;
}

bool trangThaiHopLe(const std::string& trangThai)
{
    const std::string s = chuanHoaTrangThai(trangThai);
    return s == "Trống" || s == "Đã đặt" ||
           s == "Đang sử dụng" || s == "Bảo trì";
}

bool docDanhSachBan(std::vector<Ban>& danhSach)
{
    std::vector<TextFileManager::Row> rows;
    if (!TextFileManager::read(FILE_BAN, rows)) return false;

    danhSach.clear();
    for (const auto& row : rows)
    {
        if (row.size() < 5) return false;

        try
        {
            const int soCho = std::stoi(row[2]);
            danhSach.emplace_back(row[0], row[1], soCho,
                                  chuanHoaTrangThai(row[3]), row[4]);
        }
        catch (...)
        {
            return false;
        }
    }
    return true;
}

bool ghiDanhSachBan(const std::vector<Ban>& danhSach)
{
    std::vector<TextFileManager::Row> rows;
    for (const Ban& ban : danhSach)
    {
        rows.push_back({
            ban.getMaBan(),
            ban.getTenBan(),
            std::to_string(ban.getSoCho()),
            chuanHoaTrangThai(ban.getTrangThai()),
            ban.getMaKhuVuc()
        });
    }
    return TextFileManager::write(FILE_BAN, rows);
}

bool coDatBanDangHoatDong(const std::string& maBan,
                           bool chiTrongHomNay = false)
{
    std::vector<TextFileManager::Row> rows;
    if (!TextFileManager::read("DatBan.txt", rows)) return true;

    const std::time_t now = std::time(nullptr);
    const std::tm* local = std::localtime(&now);
    std::ostringstream today;
    if (local) today << std::put_time(local, "%Y-%m-%d");

    for (const auto& row : rows)
    {
        if (row.size() < 8 || row[2] != maBan) continue;
        if (chiTrongHomNay && (row.size() < 5 || row[4] != today.str()))
            continue;

        const std::string& status = row[7];
        if (status == "Đã nhận bàn" || status == "Da nhan ban")
            return true;

        if (status == "Chờ đến" || status == "Cho den" ||
            status == "Đã đặt" || status == "Da dat")
        {
            if (!chiTrongHomNay) return true;

            if (row.size() < 6) return true;
            try
            {
                const size_t colon = row[5].find(':');
                if (colon == std::string::npos) return true;
                const int hour = std::stoi(row[5].substr(0, colon));
                const size_t secondColon = row[5].find(':', colon + 1);
                const int minute = std::stoi(row[5].substr(
                    colon + 1,
                    secondColon == std::string::npos
                        ? std::string::npos : secondColon - colon - 1));
                if (hour < 0 || hour > 23 || minute < 0 || minute > 59)
                    return true;

                const int arrival = hour * 60 + minute;
                const int current = local ? local->tm_hour * 60 + local->tm_min : -1;
                if (current < 0) return true;
                if (current >= arrival - 60 && current <= arrival + 10)
                    return true;
            }
            catch (...) { return true; }
        }
    }
    return false;
}

bool coLichDatGanBan(const std::string& maBan)
{
    std::vector<TextFileManager::Row> rows;
    if (!TextFileManager::read("DatBan.txt", rows)) return true;

    for (const auto& row : rows)
        if (row.size() >= 3 && row[2] == maBan)
            return true;

    return false;
}
}

bool BanService::napDanhSachText() const
{
    return docDanhSachBan(danhSachBan);
}

bool BanService::ghiDanhSachText() const
{
    return ghiDanhSachBan(danhSachBan);
}

std::string BanService::taoMaBan(const std::string& maKhuVuc) const
{
    if (maKhuVuc.empty() || !napDanhSachText()) return "";

    std::string prefix = maKhuVuc;
    if (prefix.size() < 2) prefix.insert(0, 2 - prefix.size(), '0');
    prefix = "B" + prefix;

    int soLonNhat = 0;
    for (const Ban& ban : danhSachBan)
    {
        const std::string& id = ban.getMaBan();
        if (id.rfind(prefix, 0) != 0) continue;

        try
        {
            soLonNhat = std::max(soLonNhat,
                                 std::stoi(id.substr(prefix.size())));
        }
        catch (...) {}
    }

    std::ostringstream out;
    out << prefix << std::setw(2) << std::setfill('0') << soLonNhat + 1;
    return out.str();
}

bool BanService::themBan(const Ban& ban)
{
    if (!PhanQuyen::coQuyenNghiepVu(QStringLiteral("QUAN_LY_DANH_MUC")))
        return false;

    if (ban.getTenBan().empty() || ban.getSoCho() <= 0 ||
        ban.getMaKhuVuc().empty())
        return false;

    std::string trangThai = chuanHoaTrangThai(ban.getTrangThai());
    if (trangThai != "Trống" && trangThai != "Bảo trì") return false;

    KhuVucService khuVucService;
    if (!khuVucService.timTheoMa(ban.getMaKhuVuc())) return false;

    if (!napDanhSachText()) return false;

    const std::string maBan = ban.getMaBan().empty()
        ? taoMaBan(ban.getMaKhuVuc()) : ban.getMaBan();

    if (maBan.empty()) return false;

    const bool daTonTai = std::any_of(
        danhSachBan.begin(), danhSachBan.end(),
        [&](const Ban& item) { return item.getMaBan() == maBan; });

    if (daTonTai) return false;

    danhSachBan.emplace_back(maBan, ban.getTenBan(), ban.getSoCho(),
                             trangThai, ban.getMaKhuVuc());
    return ghiDanhSachText();
}

bool BanService::suaBan(const std::string& maBan, const Ban& banMoi)
{
    if (!PhanQuyen::coQuyenNghiepVu(QStringLiteral("QUAN_LY_DANH_MUC")))
        return false;

    if (maBan.empty() || banMoi.getTenBan().empty() ||
        banMoi.getSoCho() <= 0 || banMoi.getMaKhuVuc().empty())
        return false;

    const std::string trangThai = chuanHoaTrangThai(banMoi.getTrangThai());
    if (!trangThaiHopLe(trangThai)) return false;

    KhuVucService khuVucService;
    if (!khuVucService.timTheoMa(banMoi.getMaKhuVuc())) return false;

    if (!napDanhSachText()) return false;

    auto it = std::find_if(danhSachBan.begin(), danhSachBan.end(),
        [&](const Ban& item) { return item.getMaBan() == maBan; });

    if (it == danhSachBan.end()) return false;

    // Khong cho giam suc chua xuong thap hon so nguoi trong lich dat con hieu luc.
    std::vector<TextFileManager::Row> bookings;
    if (!TextFileManager::read("DatBan.txt", bookings)) return false;

    for (const auto& row : bookings)
    {
        if (row.size() < 8 || row[2] != maBan) continue;
        const std::string& status = row[7];
        if (status == "Đã hủy" || status == "Da huy" ||
            status == "Không đến" || status == "Khong den" ||
            status == "Hoàn thành" || status == "Hoan thanh")
            continue;

        try
        {
            if (row.size() > 6 && std::stoi(row[6]) > banMoi.getSoCho())
                return false;
        }
        catch (...) { return false; }
    }

    if (trangThai == "Bảo trì" && coDatBanDangHoatDong(maBan))
        return false;

    *it = Ban(maBan, banMoi.getTenBan(), banMoi.getSoCho(),
              trangThai, banMoi.getMaKhuVuc());
    return ghiDanhSachText();
}

bool BanService::xoaBan(const std::string& maBan)
{
    if (!PhanQuyen::coQuyenNghiepVu(QStringLiteral("QUAN_LY_DANH_MUC")))
        return false;

    if (!napDanhSachText()) return false;

    auto it = std::find_if(danhSachBan.begin(), danhSachBan.end(),
        [&](const Ban& item) { return item.getMaBan() == maBan; });

    if (it == danhSachBan.end() ||
        chuanHoaTrangThai(it->getTrangThai()) != "Trống")
        return false;

    // Khong xoa ban da co lich su dat de tranh mat lien ket du lieu.
    if (coLichDatGanBan(maBan)) return false;

    danhSachBan.erase(it);
    return ghiDanhSachText();
}

const Ban* BanService::timBan(const std::string& maBan) const
{
    if (!napDanhSachText()) return nullptr;

    auto it = std::find_if(danhSachBan.begin(), danhSachBan.end(),
        [&](const Ban& item) { return item.getMaBan() == maBan; });

    return it == danhSachBan.end() ? nullptr : &*it;
}

const std::vector<Ban>& BanService::getDanhSachBan() const
{
    if (!napDanhSachText()) danhSachBan.clear();
    return danhSachBan;
}

bool BanService::capNhatTrangThai(const std::string& maBan,
                                  const std::string& trangThai)
{
    const std::string status = chuanHoaTrangThai(trangThai);
    if (!trangThaiHopLe(status) || !napDanhSachText()) return false;

    auto it = std::find_if(danhSachBan.begin(), danhSachBan.end(),
        [&](const Ban& item) { return item.getMaBan() == maBan; });

    if (it == danhSachBan.end()) return false;

    if (status == "Trống" && coDatBanDangHoatDong(maBan, true))
        return false;

    if (status == "Bảo trì" && coDatBanDangHoatDong(maBan))
        return false;

    it->setTrangThai(status);
    return ghiDanhSachText();
}



