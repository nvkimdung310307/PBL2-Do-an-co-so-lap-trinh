#include "KhuVucService.h"
#include "data/TextFileManager.h"
#include <algorithm>
#include <iostream>
namespace {
bool loadKhuVuc(std::vector<KhuVuc>& ds) {
    std::vector<TextFileManager::Row> rows;
    if (!TextFileManager::read("KhuVuc.txt", rows)) return false;
    ds.clear();
    for (const auto& r : rows) { if (r.size() < 3) return false; ds.emplace_back(r[0], r[1], r[2]); }
    return true;
}
}
bool KhuVucService::napDanhSachText() const { return loadKhuVuc(danhSachKhuVuc); }
bool KhuVucService::ghiDanhSachText() const {
    std::vector<TextFileManager::Row> rows;
    for (const auto& x : danhSachKhuVuc) rows.push_back({x.getMaKhuVuc(), x.getTenKhuVuc(), x.getMoTa()});
    return TextFileManager::write("KhuVuc.txt", rows);
}
bool KhuVucService::themKhuVuc(const KhuVuc& x) {
    if (!x.hopLe() || x.getMaKhuVuc().empty() || !napDanhSachText()) return false;
    if (std::any_of(danhSachKhuVuc.begin(), danhSachKhuVuc.end(), [&](const KhuVuc& a){ return a.getMaKhuVuc()==x.getMaKhuVuc(); })) return false;
    danhSachKhuVuc.push_back(x); return ghiDanhSachText();
}
bool KhuVucService::suaKhuVuc(const std::string& id, const KhuVuc& x) {
    if (!x.hopLe() || !napDanhSachText()) return false;
    auto it=std::find_if(danhSachKhuVuc.begin(),danhSachKhuVuc.end(),[&](const KhuVuc& a){return a.getMaKhuVuc()==id;});
    if(it==danhSachKhuVuc.end()) return false;
    *it=KhuVuc(id,x.getTenKhuVuc(),x.getMoTa()); return ghiDanhSachText();
}
bool KhuVucService::xoaKhuVuc(const std::string& id) {
    if (!napDanhSachText()) return false;
    std::vector<TextFileManager::Row> tables;
    if (!TextFileManager::read("Ban.txt", tables)) return false;
    for (const auto& r : tables) if (r.size()>=5 && r[4]==id) return false;
    auto n=danhSachKhuVuc.size();
    danhSachKhuVuc.erase(std::remove_if(danhSachKhuVuc.begin(),danhSachKhuVuc.end(),[&](const KhuVuc& x){return x.getMaKhuVuc()==id;}),danhSachKhuVuc.end());
    return n!=danhSachKhuVuc.size() && ghiDanhSachText();
}
const KhuVuc* KhuVucService::timTheoMa(const std::string& id) const {
    if(!napDanhSachText()) return nullptr;
    auto it=std::find_if(danhSachKhuVuc.begin(),danhSachKhuVuc.end(),[&](const KhuVuc& x){return x.getMaKhuVuc()==id;});
    return it==danhSachKhuVuc.end()?nullptr:&*it;
}
const std::vector<KhuVuc>& KhuVucService::getDanhSachKhuVuc() const { if(!napDanhSachText()) danhSachKhuVuc.clear(); return danhSachKhuVuc; }
