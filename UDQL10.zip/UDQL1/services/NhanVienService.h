#ifndef NHAN_VIEN_SERVICE_H
#define NHAN_VIEN_SERVICE_H

#include <string>
#include <vector>
#include "../oop/NhanVien.h"
#include "../oop/TaiKhoan.h"

struct NhanVienTaiKhoanInfo {
    NhanVien nhanVien;
    TaiKhoan taiKhoan;
};

enum class TaoNhanVienTaiKhoanStatus {
    ThanhCong,
    TenDangNhapDaTonTai,
    LoiNhanVien,
    LoiTaiKhoan,
    KhongTaoDuocMa
};

struct TaoNhanVienTaiKhoanRequest {
    std::string hoTen;
    std::string tenDangNhap;
    std::string matKhau;
    std::string gioiTinh;
    std::string ngaySinh;
    std::string soDienThoai;
    std::string email;
    std::string chucVu;
    double luong = 0;
};

struct TaoNhanVienTaiKhoanResult {
    TaoNhanVienTaiKhoanStatus status = TaoNhanVienTaiKhoanStatus::LoiNhanVien;
    std::string maNhanVien;
};

class NhanVienService
{
private:
    mutable std::vector<NhanVien> danhSachNhanVien;
    bool napDanhSachText() const;
    bool ghiDanhSachText() const;
public:
    bool themNhanVien(const NhanVien& nhanVien);
    bool suaNhanVien(const std::string& maNV, const NhanVien& nhanVienMoi);
    bool xoaNhanVien(const std::string& maNV);
    bool capNhatTrangThai(const std::string& maNV, const std::string& trangThai);
    const NhanVien* timTheoMa(const std::string& maNV) const;
    const NhanVien* timTheoSoDienThoai(const std::string& soDienThoai) const;
    const std::vector<NhanVien>& getDanhSachNhanVien() const;
    std::string taoMaNhanVien(int doDai = 6) const;

    // Tong hop ho so nhan vien va tai khoan de giao dien chi can hien thi.
    std::vector<NhanVienTaiKhoanInfo> getDanhSachNhanVienCoTaiKhoan() const;

    // Tao ho so nhan vien va tai khoan theo mot quy trinh; tu dong hoan tac ho so neu tao tai khoan that bai.
    TaoNhanVienTaiKhoanResult taoNhanVienVaTaiKhoan(
        const TaoNhanVienTaiKhoanRequest& request);
};

#endif
