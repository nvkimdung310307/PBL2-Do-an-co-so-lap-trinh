#ifndef BAN_SERVICE_H
#define BAN_SERVICE_H

#include <string>
#include <vector>
#include "../oop/Ban.h"

// Quan ly danh sach ban an va cac thao tac co ban voi ban.
class BanService
{
private:
    mutable std::vector<Ban> danhSachBan;

    bool napDanhSachText() const;
    bool ghiDanhSachText() const;

public:
    std::string taoMaBan(const std::string& maKhuVuc) const;

    bool themBan(const Ban& ban);
    bool suaBan(const std::string& maBan, const Ban& banMoi);
    bool xoaBan(const std::string& maBan);

    const Ban* timBan(const std::string& maBan) const;
    const std::vector<Ban>& getDanhSachBan() const;

    bool capNhatTrangThai(const std::string& maBan,
                          const std::string& trangThai);

};

#endif
