#ifndef KHU_VUC_SERVICE_H
#define KHU_VUC_SERVICE_H
#include <string>
#include <vector>
#include "../oop/KhuVuc.h"
class KhuVucService
{
private:
    mutable std::vector<KhuVuc> danhSachKhuVuc;
    bool napDanhSachText() const;
    bool ghiDanhSachText() const;
public:
    bool themKhuVuc(const KhuVuc& khuVuc);
    bool suaKhuVuc(const std::string& maKhuVuc, const KhuVuc& khuVucMoi);
    bool xoaKhuVuc(const std::string& maKhuVuc);
    const KhuVuc* timTheoMa(const std::string& maKhuVuc) const;
    const std::vector<KhuVuc>& getDanhSachKhuVuc() const;
};
#endif
