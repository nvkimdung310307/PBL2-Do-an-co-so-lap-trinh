#ifndef BOTRIBAN_SERVICE_H
#define BOTRIBAN_SERVICE_H
#include <string>
#include <vector>
#include "../oop/BoTriBan.h"

class BoTriBanService {
private:
    mutable std::vector<BoTriBan> danhSach;
    bool napDanhSach() const;
    bool ghiDanhSach() const;
public:
    const std::vector<BoTriBan>& getDanhSach() const;
    bool datViTri(const std::string& maBan, int cot, int hang, int thuTu = 0);
    bool doiViTri(const std::string& maBan, int cotMoi, int hangMoi,
                  const std::string& maBanHoanDoi = std::string(),
                  int cotCu = 0, int hangCu = 0);
    bool xoaViTri(const std::string& maBan);
    bool xoaNhieuViTri(const std::vector<std::string>& maBans);
};
#endif
