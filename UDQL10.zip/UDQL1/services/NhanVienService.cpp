#include "NhanVienService.h"
#include "../taikhoan/TaiKhoanService.h"
#include "../taikhoan/PhanQuyen.h"
#include "data/TextFileManager.h"
#include <algorithm>
#include <cmath>
#include <iostream>

namespace {
using Rows = std::vector<TextFileManager::Row>;
bool loadNhanVien(std::vector<NhanVien>& ds)
{
    Rows rows;
    if (!TextFileManager::read("NhanVien.txt", rows)) return false;
    ds.clear();
    for (const auto& r : rows) {
        if (r.size() < 9) return false;
        try {
            ds.emplace_back(r[0], r[1], r[2], r[3], r[4], r[5], r[6], std::stod(r[7]), r[8]);
        } catch (...) { return false; }
    }
    return true;
}
}

bool NhanVienService::napDanhSachText() const { return loadNhanVien(danhSachNhanVien); }
bool NhanVienService::ghiDanhSachText() const
{
    Rows rows;
    for (const auto& nv : danhSachNhanVien)
        rows.push_back({nv.getMaNV(), nv.getHoTen(), nv.getGioiTinh(), nv.getNgaySinh(),
                        nv.getSoDienThoai(), nv.getEmail(), nv.getChucVu(),
                        std::to_string(nv.getLuong()), nv.getTrangThai()});
    return TextFileManager::write("NhanVien.txt", rows);
}

bool NhanVienService::themNhanVien(const NhanVien& nv)
{
    if (!PhanQuyen::coQuyenNghiepVu(QStringLiteral("QUAN_LY_DANH_MUC"))) return false;
    const NguoiDung& nguoiDung = nv;
    if (!nguoiDung.hopLe() || nv.getMaNV().empty() || !std::isfinite(nv.getLuong()) || nv.getLuong() < 0) return false;
    if (!napDanhSachText()) return false;
    if (std::any_of(danhSachNhanVien.begin(), danhSachNhanVien.end(), [&](const NhanVien& x) {
        return x.getMaNV() == nv.getMaNV() || (!nv.getSoDienThoai().empty() && x.getSoDienThoai() == nv.getSoDienThoai());
    })) return false;
    danhSachNhanVien.push_back(nv);
    return ghiDanhSachText();
}

bool NhanVienService::suaNhanVien(const std::string& id, const NhanVien& moi)
{
    if (!PhanQuyen::coQuyenNghiepVu(QStringLiteral("QUAN_LY_DANH_MUC"))) return false;
    if (!moi.hopLe() || !std::isfinite(moi.getLuong()) || moi.getLuong() < 0 || !napDanhSachText()) return false;
    auto it = std::find_if(danhSachNhanVien.begin(), danhSachNhanVien.end(), [&](const NhanVien& x) { return x.getMaNV() == id; });
    if (it == danhSachNhanVien.end()) return false;
    if (std::any_of(danhSachNhanVien.begin(), danhSachNhanVien.end(), [&](const NhanVien& x) {
        return &x != &*it && !moi.getSoDienThoai().empty() && x.getSoDienThoai() == moi.getSoDienThoai();
    })) return false;
    *it = NhanVien(id, moi.getHoTen(), moi.getGioiTinh(), moi.getNgaySinh(), moi.getSoDienThoai(),
                   moi.getEmail(), moi.getChucVu(), moi.getLuong(), moi.getTrangThai());
    return ghiDanhSachText();
}

bool NhanVienService::xoaNhanVien(const std::string& id)
{
    if (!PhanQuyen::coQuyenNghiepVu(QStringLiteral("QUAN_LY_DANH_MUC"))) return false;
    if (!napDanhSachText()) return false;
    // Không xóa hồ sơ còn được tài khoản tham chiếu.
    Rows accounts;
    if (!TextFileManager::read("TaiKhoan.txt", accounts)) return false;
    for (const auto& row : accounts) if (row.size() >= 5 && row[4] == id) return false;
    Rows bookings, invoices;
    if (!TextFileManager::read("DatBan.txt", bookings) || !TextFileManager::read("HoaDon.txt", invoices)) return false;
    for (const auto& row : bookings) if (row.size() >= 4 && row[3] == id) return false;
    for (const auto& row : invoices) if (row.size() >= 3 && row[2] == id) return false;
    auto oldSize = danhSachNhanVien.size();
    danhSachNhanVien.erase(std::remove_if(danhSachNhanVien.begin(), danhSachNhanVien.end(),
        [&](const NhanVien& x) { return x.getMaNV() == id; }), danhSachNhanVien.end());
    return oldSize != danhSachNhanVien.size() && ghiDanhSachText();
}

bool NhanVienService::capNhatTrangThai(const std::string& id, const std::string& status)
{
    if (!PhanQuyen::coQuyenNghiepVu(QStringLiteral("QUAN_LY_DANH_MUC"))) return false;
    if (status.empty() || !napDanhSachText()) return false;
    auto it = std::find_if(danhSachNhanVien.begin(), danhSachNhanVien.end(), [&](const NhanVien& x) { return x.getMaNV() == id; });
    if (it == danhSachNhanVien.end()) return false;
    it->setTrangThai(status);
    return ghiDanhSachText();
}

const NhanVien* NhanVienService::timTheoMa(const std::string& id) const
{
    if (!napDanhSachText()) return nullptr;
    auto it = std::find_if(danhSachNhanVien.begin(), danhSachNhanVien.end(), [&](const NhanVien& x) { return x.getMaNV() == id; });
    return it == danhSachNhanVien.end() ? nullptr : &*it;
}
const NhanVien* NhanVienService::timTheoSoDienThoai(const std::string& sdt) const
{
    if (!napDanhSachText()) return nullptr;
    auto it = std::find_if(danhSachNhanVien.begin(), danhSachNhanVien.end(), [&](const NhanVien& x) { return x.getSoDienThoai() == sdt; });
    return it == danhSachNhanVien.end() ? nullptr : &*it;
}
const std::vector<NhanVien>& NhanVienService::getDanhSachNhanVien() const
{
    if (!napDanhSachText()) danhSachNhanVien.clear();
    return danhSachNhanVien;
}

std::string NhanVienService::taoMaNhanVien(int doDai) const
{
    if (doDai < 1) doDai = 6;
    int maxId = 0;
    for (const auto& nv : getDanhSachNhanVien()) {
        const std::string& id = nv.getMaNV();
        if (id.rfind("NV", 0) != 0) continue;
        try {
            const int value = std::stoi(id.substr(2));
            if (value > maxId) maxId = value;
        } catch (...) {}
    }
    std::string number = std::to_string(maxId + 1);
    if (static_cast<int>(number.size()) < doDai) number.insert(0, doDai - number.size(), '0');
    return "NV" + number;
}



std::vector<NhanVienTaiKhoanInfo> NhanVienService::getDanhSachNhanVienCoTaiKhoan() const
{
    TaiKhoanService taiKhoanService;
    const auto& accounts = taiKhoanService.getDanhSachTaiKhoan();
    const auto& employees = getDanhSachNhanVien();

    std::vector<NhanVienTaiKhoanInfo> result;
    result.reserve(accounts.size());

    for (const auto& account : accounts) {
        const std::string role = account.getVaiTro();
        if (role != u8"Nhân viên" && role != "NhanVien") continue;

        const auto employee = std::find_if(
            employees.begin(), employees.end(),
            [&](const NhanVien& item) {
                return item.getMaNV() == account.getMaNV();
            });

        if (employee != employees.end()) {
            result.push_back({*employee, account});
        }
    }
    return result;
}

TaoNhanVienTaiKhoanResult NhanVienService::taoNhanVienVaTaiKhoan(
    const TaoNhanVienTaiKhoanRequest& request)
{
    TaiKhoanService taiKhoanService;

    if (taiKhoanService.timTheoTenDangNhap(request.tenDangNhap)) {
        return {TaoNhanVienTaiKhoanStatus::TenDangNhapDaTonTai, {}};
    }

    const std::string maNV = taoMaNhanVien();
    const std::string maTK = taiKhoanService.taoMaTaiKhoan();
    if (maNV.empty() || maTK.empty()) {
        return {TaoNhanVienTaiKhoanStatus::KhongTaoDuocMa, {}};
    }

    NhanVien nhanVien(maNV, request.hoTen, request.gioiTinh, request.ngaySinh,
                      request.soDienThoai, request.email, request.chucVu,
                      request.luong, "Đang làm");
    if (!themNhanVien(nhanVien)) {
        return {TaoNhanVienTaiKhoanStatus::LoiNhanVien, {}};
    }

    TaiKhoan taiKhoan(maTK, request.tenDangNhap, request.matKhau,
                      "NhanVien", maNV, "Hoạt động");
    if (!taiKhoanService.themTaiKhoan(taiKhoan)) {
        // Tai khoan chua duoc tao nen ho so moi van chua co tham chieu.
        xoaNhanVien(maNV);
        return {TaoNhanVienTaiKhoanStatus::LoiTaiKhoan, {}};
    }

    return {TaoNhanVienTaiKhoanStatus::ThanhCong, maNV};
}
