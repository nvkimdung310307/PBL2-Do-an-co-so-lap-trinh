#include "DatBanService.h"

#include "data/TextFileManager.h"
#include "BanService.h"
#include "KhachHangService.h"
#include "NhanVienService.h"
#include "DatCocService.h"
#include "../taikhoan/PhanQuyen.h"

#include <algorithm>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <sstream>

namespace
{
using Rows = std::vector<TextFileManager::Row>;

const int THOI_LUONG_GIU_BAN_TRUOC_GIO_DEN = 60;
const int SO_PHUT_CHO_KHACH_DEN = 10;

std::string ngayHienTai()
{
    const std::time_t now = std::time(nullptr);
    const std::tm* local = std::localtime(&now);
    if (!local) return "";

    std::ostringstream out;
    out << std::put_time(local, "%Y-%m-%d");
    return out.str();
}

int phutTrongNgay(const std::string& gio)
{
    // Chap nhan HH:mm hoac HH:mm:ss; khong chap nhan gio/phut/giay sai.
    if (gio.size() != 5 && gio.size() != 8) return -1;
    if (gio[2] != ':' || (gio.size() == 8 && gio[5] != ':')) return -1;

    auto laChuSo = [](char c) { return c >= '0' && c <= '9'; };
    if (!laChuSo(gio[0]) || !laChuSo(gio[1]) ||
        !laChuSo(gio[3]) || !laChuSo(gio[4])) return -1;
    if (gio.size() == 8 &&
        (!laChuSo(gio[6]) || !laChuSo(gio[7]))) return -1;

    const int hour = (gio[0] - '0') * 10 + (gio[1] - '0');
    const int minute = (gio[3] - '0') * 10 + (gio[4] - '0');
    if (hour > 23 || minute > 59) return -1;
    if (gio.size() == 8) {
        const int second = (gio[6] - '0') * 10 + (gio[7] - '0');
        if (second > 59) return -1;
    }
    return hour * 60 + minute;
}

bool ngayISOHopLe(const std::string& date)
{
    if (date.size() != 10 || date[4] != '-' || date[7] != '-') return false;
    for (size_t i = 0; i < date.size(); ++i) {
        if (i == 4 || i == 7) continue;
        if (date[i] < '0' || date[i] > '9') return false;
    }

    const int year = std::stoi(date.substr(0, 4));
    const int month = std::stoi(date.substr(5, 2));
    const int day = std::stoi(date.substr(8, 2));
    if (year < 1900 || month < 1 || month > 12) return false;

    static const int daysInMonth[] = {
        31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
    };
    int maxDay = daysInMonth[month - 1];
    const bool leap = (year % 400 == 0) || (year % 4 == 0 && year % 100 != 0);
    if (month == 2 && leap) maxDay = 29;
    return day >= 1 && day <= maxDay;
}

int phutHienTai()
{
    const std::time_t now = std::time(nullptr);
    const std::tm* local = std::localtime(&now);
    if (!local) return -1;
    return local->tm_hour * 60 + local->tm_min;
}

bool laTrangThaiKetThuc(const std::string& status)
{
    return status == "Đã hủy" || status == "Da huy" ||
           status == "Không đến" || status == "Khong den" ||
           status == "Hoàn thành" || status == "Hoan thanh";
}

bool laTrangThaiDangDat(const std::string& status)
{
    return status == "Chờ đến" || status == "Cho den" ||
           status == "Đã đặt" || status == "Da dat" ||
           status == "Đã nhận bàn" || status == "Da nhan ban";
}

bool laTrangThaiDaNhan(const std::string& status)
{
    return status == "Đã nhận bàn" || status == "Da nhan ban";
}

bool docDanhSachDatBan(std::vector<DatBan>& danhSach)
{
    Rows rows;
    if (!TextFileManager::read("DatBan.txt", rows)) return false;

    danhSach.clear();
    for (const auto& row : rows)
    {
        if (row.size() < 9) return false;

        try
        {
            danhSach.emplace_back(
                row[0], row[1], row[2], row[3], row[4], row[5],
                std::stoi(row[6]), row[7], row[8],
                row.size() > 9 ? row[9] : std::string(),
                row.size() > 10 ? row[10] : std::string());
        }
        catch (...) { return false; }
    }
    return true;
}

bool ghiDanhSachDatBan(const std::vector<DatBan>& danhSach)
{
    Rows rows;
    for (const DatBan& item : danhSach)
    {
        rows.push_back({
            item.getMaDatBan(), item.getMaKH(), item.getMaBan(),
            item.getMaNV(), item.getNgayDat(), item.getGioDat(),
            std::to_string(item.getSoNguoi()), item.getTrangThai(),
            item.getGhiChu(), item.getNgayTao(), item.getGioTao()
        });
    }
    return TextFileManager::write("DatBan.txt", rows);
}

bool kiemTraThamChieu(const DatBan& datBan)
{
    KhachHangService khachHangService;
    BanService banService;

    if (!khachHangService.timKhachHang(datBan.getMaKH()))
        return false;

    const Ban* ban = banService.timBan(datBan.getMaBan());
    if (!ban || datBan.getSoNguoi() > ban->getSoCho())
        return false;

    if (ban->getTrangThai() == "Bảo trì" ||
        ban->getTrangThai() == "Bao tri")
        return false;

    // Ma nhan vien co the rong neu khach tu dat truc tiep.
    if (!datBan.getMaNV().empty())
    {
        NhanVienService nhanVienService;
        if (!nhanVienService.timTheoMa(datBan.getMaNV()))
            return false;
    }

    return true;
}

bool khungGioBiTrung(int gioA, int gioB)
{
    if (gioA < 0 || gioB < 0) return true;

    // Moi luot dat chiem khoang 70 phut: tu 60 phut truoc gio den
    // den 10 phut sau gio den.
    const int batDauA = gioA - THOI_LUONG_GIU_BAN_TRUOC_GIO_DEN;
    const int ketThucA = gioA + SO_PHUT_CHO_KHACH_DEN;
    const int batDauB = gioB - THOI_LUONG_GIU_BAN_TRUOC_GIO_DEN;
    const int ketThucB = gioB + SO_PHUT_CHO_KHACH_DEN;

    return batDauA < ketThucB && batDauB < ketThucA;
}

bool kiemTraNgayGioHopLe(const DatBan& datBan)
{
    // Ngay luu theo dinh dang ISO YYYY-MM-DD de co the so sanh chuoi.
    const std::string& date = datBan.getNgayDat();
    if (!ngayISOHopLe(date)) return false;

    const int requestedMinute = phutTrongNgay(datBan.getGioDat());
    if (requestedMinute < 0) return false;

    const std::string today = ngayHienTai();
    if (today.empty() || date < today) return false;

    if (date == today && requestedMinute < phutHienTai())
        return false;

    return true;
}

bool coLichTrung(const std::vector<DatBan>& danhSach,
                 const DatBan& datBan,
                 const std::string& boQuaMa = "")
{
    const int requestedMinute = phutTrongNgay(datBan.getGioDat());

    for (const DatBan& other : danhSach)
    {
        if (other.getMaDatBan() == boQuaMa ||
            other.getMaBan() != datBan.getMaBan() ||
            other.getNgayDat() != datBan.getNgayDat() ||
            laTrangThaiKetThuc(other.getTrangThai()))
            continue;

        if (laTrangThaiDaNhan(other.getTrangThai()))
            return true;

        if (khungGioBiTrung(requestedMinute, phutTrongNgay(other.getGioDat())))
            return true;
    }
    return false;
}

bool capNhatTrangThaiBanTheoLich(const std::vector<DatBan>& danhSach)
{
    const std::string today = ngayHienTai();
    const int nowMinute = phutHienTai();
    if (today.empty() || nowMinute < 0) return false;

    BanService banService;
    const auto tables = banService.getDanhSachBan();

    for (const Ban& table : tables)
    {
        if (table.getTrangThai() == "Bảo trì" ||
            table.getTrangThai() == "Bao tri")
            continue;

        bool hasReceived = false;
        bool hasReserved = false;

        for (const DatBan& booking : danhSach)
        {
            if (booking.getMaBan() != table.getMaBan() ||
                booking.getNgayDat() != today ||
                laTrangThaiKetThuc(booking.getTrangThai()))
                continue;

            if (laTrangThaiDaNhan(booking.getTrangThai()))
            {
                hasReceived = true;
                break;
            }

            const int arrival = phutTrongNgay(booking.getGioDat());
            if (arrival >= 0 &&
                nowMinute >= arrival - THOI_LUONG_GIU_BAN_TRUOC_GIO_DEN &&
                nowMinute <= arrival + SO_PHUT_CHO_KHACH_DEN)
                hasReserved = true;
        }

        const std::string nextStatus = hasReceived
            ? "Đang sử dụng"
            : (hasReserved ? "Đã đặt" : "Trống");

        if (table.getTrangThai() != nextStatus &&
            !banService.capNhatTrangThai(table.getMaBan(), nextStatus))
            return false;
    }

    return true;
}

bool luuVaDongBo(std::vector<DatBan>& danhSach)
{
    if (!ghiDanhSachDatBan(danhSach)) return false;
    return capNhatTrangThaiBanTheoLich(danhSach);
}
}

bool DatBanService::napDanhSachText() const
{
    return docDanhSachDatBan(danhSachDatBan);
}

bool DatBanService::ghiDanhSachText() const
{
    return ghiDanhSachDatBan(danhSachDatBan);
}

bool DatBanService::themDatBan(const DatBan& datBan)
{
    if (!PhanQuyen::coQuyenNghiepVu(QStringLiteral("DAT_BAN")))
        return false;

    if (!datBan.hopLe() || !kiemTraNgayGioHopLe(datBan) ||
        !kiemTraThamChieu(datBan))
        return false;

    std::vector<DatBan> danhSach;
    if (!docDanhSachDatBan(danhSach)) return false;

    const bool daTonTai = std::any_of(
        danhSach.begin(), danhSach.end(),
        [&](const DatBan& item) {
            return item.getMaDatBan() == datBan.getMaDatBan();
        });
    if (daTonTai || coLichTrung(danhSach, datBan)) return false;

    DatBan item = datBan;
    if (item.getTrangThai().empty())
        item.setTrangThai("Chờ đến");

    const std::string& status = item.getTrangThai();
    if (status != "Chờ đến" && status != "Cho den" &&
        status != "Đã đặt" && status != "Da dat" &&
        status != "Đã nhận bàn" && status != "Da nhan ban")
        return false;

    if (item.getNgayTao().empty() || item.getGioTao().empty())
    {
        const std::time_t now = std::time(nullptr);
        const std::tm* local = std::localtime(&now);
        if (!local) return false;

        std::ostringstream date, time;
        date << std::put_time(local, "%Y-%m-%d");
        time << std::put_time(local, "%H:%M");
        item.setNgayTao(date.str());
        item.setGioTao(time.str());
    }

    danhSach.push_back(item);
    if (!luuVaDongBo(danhSach)) return false;
    return true;
}


bool DatBanService::huyDatBan(const std::string& maDatBan)
{
    if (!PhanQuyen::coQuyenNghiepVu(QStringLiteral("DAT_BAN")))
        return false;

    std::vector<DatBan> danhSach;
    if (!docDanhSachDatBan(danhSach)) return false;

    auto it = std::find_if(danhSach.begin(), danhSach.end(),
        [&](const DatBan& item) {
            return item.getMaDatBan() == maDatBan;
        });

    if (it == danhSach.end() || laTrangThaiKetThuc(it->getTrangThai()) ||
        laTrangThaiDaNhan(it->getTrangThai()))
        return false;

    it->setTrangThai("Đã hủy");
    if (!luuVaDongBo(danhSach)) return false;
    // Neu da thu coc thi mat toan bo coc; neu chua thu coc thi khong phat sinh giao dich.
    if (!DatCocService().danhDauMatCocTheoDatBan(maDatBan)) return false;
    return true;
}

bool DatBanService::xacNhanKhachDen(const std::string& maDatBan)
{
    if (!PhanQuyen::coQuyenNghiepVu(QStringLiteral("DAT_BAN")))
        return false;

    std::vector<DatBan> danhSach;
    if (!docDanhSachDatBan(danhSach)) return false;

    auto it = std::find_if(danhSach.begin(), danhSach.end(),
        [&](const DatBan& item) {
            return item.getMaDatBan() == maDatBan;
        });

    if (it == danhSach.end() || laTrangThaiKetThuc(it->getTrangThai()) ||
        it->getNgayDat() != ngayHienTai())
        return false;

    const int arrival = phutTrongNgay(it->getGioDat());
    const int now = phutHienTai();
    if (arrival < 0 || now < 0) return false;

    if (now > arrival + SO_PHUT_CHO_KHACH_DEN)
    {
        it->setTrangThai("Không đến");
        if (!luuVaDongBo(danhSach)) return false;
        DatCocService().danhDauMatCocTheoDatBan(maDatBan);
        return false;
    }

    if (now < arrival - 10) return false;

    it->setTrangThai("Đã nhận bàn");
    if (!luuVaDongBo(danhSach)) return false;
    return true;
}

bool DatBanService::hoanThanhDatBan(const std::string& maDatBan)
{
    if (!PhanQuyen::coQuyenNghiepVu(QStringLiteral("DAT_BAN")))
        return false;

    std::vector<DatBan> danhSach;
    if (!docDanhSachDatBan(danhSach)) return false;

    auto it = std::find_if(danhSach.begin(), danhSach.end(),
        [&](const DatBan& item) {
            return item.getMaDatBan() == maDatBan;
        });

    if (it == danhSach.end() || !laTrangThaiDaNhan(it->getTrangThai()))
        return false;

    it->setTrangThai("Hoàn thành");
    if (!luuVaDongBo(danhSach)) return false;
    return true;
}



bool DatBanService::capNhatTrangThaiTheoThoiGian()
{
    std::vector<DatBan> danhSach;
    if (!docDanhSachDatBan(danhSach)) return false;

    const std::string today = ngayHienTai();
    const int now = phutHienTai();
    if (today.empty() || now < 0) return false;

    bool changed = false;
    std::vector<std::string> cacPhieuKhongDen;

    for (DatBan& booking : danhSach)
    {
        if (laTrangThaiKetThuc(booking.getTrangThai()) ||
            laTrangThaiDaNhan(booking.getTrangThai()))
            continue;

        if (booking.getNgayDat() < today)
        {
            booking.setTrangThai("Không đến");
            cacPhieuKhongDen.push_back(booking.getMaDatBan());
            changed = true;
            continue;
        }

        if (booking.getNgayDat() != today) continue;

        const int arrival = phutTrongNgay(booking.getGioDat());
        if (arrival < 0) continue;

        if (now > arrival + SO_PHUT_CHO_KHACH_DEN)
        {
            booking.setTrangThai("Không đến");
            cacPhieuKhongDen.push_back(booking.getMaDatBan());
            changed = true;
        }
        else if (now >= arrival - THOI_LUONG_GIU_BAN_TRUOC_GIO_DEN &&
                 booking.getTrangThai() != "Đã đặt")
        {
            booking.setTrangThai("Đã đặt");
            changed = true;
        }
        else if (now < arrival - THOI_LUONG_GIU_BAN_TRUOC_GIO_DEN &&
                 booking.getTrangThai() != "Chờ đến")
        {
            booking.setTrangThai("Chờ đến");
            changed = true;
        }
    }

    if (changed && !ghiDanhSachDatBan(danhSach)) return false;
    DatCocService datCocService;
    for (const std::string& maDatBan : cacPhieuKhongDen)
        if (!datCocService.danhDauMatCocTheoDatBan(maDatBan)) return false;
    return capNhatTrangThaiBanTheoLich(danhSach);
}

bool DatBanService::chuyenBanText(const std::string& maDatBan,
                                  const std::string& maBanMoi)
{
    // Tam giu API cho giao dien cu. Nghiep vu chuyen ban se duoc bo
    // khi giao dien duoc rut gon o giai doan tiep theo.
    if (!PhanQuyen::coQuyenNghiepVu(QStringLiteral("DAT_BAN")))
        return false;

    std::vector<DatBan> danhSach;
    if (!docDanhSachDatBan(danhSach)) return false;

    auto it = std::find_if(danhSach.begin(), danhSach.end(),
        [&](const DatBan& item) {
            return item.getMaDatBan() == maDatBan;
        });

    if (it == danhSach.end() || laTrangThaiKetThuc(it->getTrangThai()))
        return false;

    BanService banService;
    const Ban* banMoi = banService.timBan(maBanMoi);
    if (!banMoi || banMoi->getSoCho() < it->getSoNguoi() ||
        banMoi->getTrangThai() == "Bảo trì" ||
        banMoi->getTrangThai() == "Bao tri" ||
        (maBanMoi != it->getMaBan() &&
         (banMoi->getTrangThai() == "Đang sử dụng" ||
          banMoi->getTrangThai() == "Dang su dung")))
        return false;

    DatBan changed = *it;
    changed.setMaBan(maBanMoi);
    if (coLichTrung(danhSach, changed, maDatBan)) return false;

    it->setMaBan(maBanMoi);
    return luuVaDongBo(danhSach);
}



const DatBan* DatBanService::timDatBan(const std::string& maDatBan) const
{
    if (!napDanhSachText()) return nullptr;

    auto it = std::find_if(danhSachDatBan.begin(), danhSachDatBan.end(),
        [&](const DatBan& item) {
            return item.getMaDatBan() == maDatBan;
        });

    return it == danhSachDatBan.end() ? nullptr : &*it;
}




const std::vector<DatBan>& DatBanService::getDanhSachDatBan() const
{
    if (!napDanhSachText()) danhSachDatBan.clear();
    return danhSachDatBan;
}

std::string DatBanService::taoMaDatBan(int doDai) const
{
    if (doDai < 1) doDai = 6;

    int soLonNhat = 0;
    for (const DatBan& item : getDanhSachDatBan())
    {
        const std::string& id = item.getMaDatBan();
        if (id.rfind("DB", 0) != 0) continue;

        try
        {
            soLonNhat = std::max(soLonNhat, std::stoi(id.substr(2)));
        }
        catch (...) {}
    }

    std::string number = std::to_string(soLonNhat + 1);
    if (static_cast<int>(number.size()) < doDai)
        number.insert(0, doDai - number.size(), '0');

    return "DB" + number;
}
