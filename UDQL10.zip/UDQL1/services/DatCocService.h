#ifndef DAT_COC_SERVICE_H
#define DAT_COC_SERVICE_H

#include <string>
#include <vector>
#include "../oop/DatCoc.h"

// Du lieu da loc cho man hinh thu tien coc; Widget chi dung de hien thi.
struct DatCocChoThuInfo {
    std::string maDatBan;
    std::string maKhachHang;
    std::string maBan;
    std::string maKhuVuc;
    std::string ngayDat;
    std::string gioDat;
    long long soTien = 0;
};

// Quan ly tien dat coc doc lap, lien ket voi phieu dat ban bang maDatBan.
class DatCocService
{
private:
    mutable std::vector<DatCoc> danhSachDatCoc;

    bool napDanhSachText() const;
    bool ghiDanhSachText() const;
    std::string taoMaDatCoc(int doDai = 6) const;
    bool duLieuDatCocHopLe(const DatCoc& datCoc) const;

public:
    // Moi phieu dat ban chi co toi da mot ho so dat coc hien hanh.
    bool themDatCoc(const DatCoc& datCoc);
    bool capNhatTrangThai(const std::string& maDatCoc,
                          const std::string& trangThaiMoi);
    // Ghi nhan mat coc khi phieu dat ban bi huy/khach khong den.
    bool danhDauMatCocTheoDatBan(const std::string& maDatBan);
    // Giao dich dat coc la lich su tai chinh, khong cho xoa.

    const DatCoc* timTheoDatBan(const std::string& maDatBan) const;
    const std::vector<DatCoc>& getDanhSachDatCoc() const;
    // Tra ve cac luot dat con hieu luc, co muc coc va chua thu coc.
    std::vector<DatCocChoThuInfo> getDanhSachChoThuTienCoc() const;
};

#endif
