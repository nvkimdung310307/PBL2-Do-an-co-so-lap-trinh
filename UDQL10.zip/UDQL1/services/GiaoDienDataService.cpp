#include "GiaoDienDataService.h"
#include "../data/TextFileManager.h"
#include "BanService.h"
#include "KhuVucService.h"
#include "KhachHangService.h"
#include "../taikhoan/TaiKhoanService.h"

#include <QDate>
#include <QByteArray>

namespace {
bool readStorage(const char* fileName, GiaoDienDataService::Rows& rows) {
    return TextFileManager::read(fileName, rows);
}
bool writeStorage(const char* fileName, const GiaoDienDataService::Rows& rows) {
    return TextFileManager::write(fileName, rows);
}
}

bool GiaoDienDataService::layQuyenChuyenBan() {
    Rows rows;
    return readStorage("QuyenChuyenBan.txt", rows) &&
           !rows.empty() && !rows[0].empty() && rows[0][0] == "1";
}

bool GiaoDienDataService::capNhatQuyenChuyenBan(bool enabled) {
    return writeStorage("QuyenChuyenBan.txt", {{enabled ? "1" : "0"}});
}

bool GiaoDienDataService::layMucCocDatBan(Rows& rows) {
    return readStorage("MucCocDatBan.txt", rows);
}

bool GiaoDienDataService::luuMucCocDatBan(const Rows& rows) {
    return writeStorage("MucCocDatBan.txt", rows);
}

bool GiaoDienDataService::layLichSuQuyetToan(Rows& rows) {
    return readStorage("QuyetToanDatCoc.txt", rows);
}

bool GiaoDienDataService::luuLichSuQuyetToan(const Rows& rows) {
    return writeStorage("QuyetToanDatCoc.txt", rows);
}

bool GiaoDienDataService::layCauHinhDatCoc(Rows& rows) {
    return readStorage("CauHinhDatCoc.txt", rows);
}

bool GiaoDienDataService::luuCauHinhDatCoc(const Rows& rows) {
    return writeStorage("CauHinhDatCoc.txt", rows);
}

bool GiaoDienDataService::capNhatMucCocTheoKhuVuc(
    const std::string& maKhuVuc, long long soTien) {
    if (maKhuVuc.empty() || soTien < 0) return false;

    Rows rows;
    if (!layCauHinhDatCoc(rows)) return false;

    bool found = false;
    for (auto& row : rows) {
        if (!row.empty() && row[0] == maKhuVuc) {
            if (row.size() < 2) row.resize(2);
            row[1] = std::to_string(soTien);
            found = true;
            break;
        }
    }

    if (!found) rows.push_back({maKhuVuc, std::to_string(soTien)});
    return luuCauHinhDatCoc(rows);
}

bool GiaoDienDataService::chotMucCocChoDatBan(
    const std::string& maDatBan, const std::string& maBan) {
    if (maDatBan.empty() || maBan.empty()) return false;

    BanService tableService;
    const Ban* table = tableService.timBan(maBan);
    if (!table) return true;

    Rows configRows;
    Rows snapshots;
    layCauHinhDatCoc(configRows);
    layMucCocDatBan(snapshots);

    long long depositAmount = 0;
    for (const auto& row : configRows) {
        if (row.size() < 2 || row[0] != table->getMaKhuVuc()) continue;
        try {
            depositAmount = std::stoll(row[1]);
        } catch (...) {
            depositAmount = 0;
        }
        break;
    }

    snapshots.push_back({maDatBan, table->getMaKhuVuc(),
                         std::to_string(depositAmount)});
    return luuMucCocDatBan(snapshots);
}

QString GiaoDienDataService::lastDataError() {
    return TextFileManager::lastErrorMessage();
}

std::string GiaoDienDataService::utf8(const QString &value) {
    const QByteArray bytes = value.toUtf8();
    return std::string(bytes.constData(),
                       static_cast<size_t>(bytes.size()));
}

QString GiaoDienDataService::value(const Row &row, size_t index) {
    return index < row.size()
        ? QString::fromUtf8(row[index].c_str())
        : QString();
}

bool GiaoDienDataService::activeBooking(const QString &status) {
    return status == QStringLiteral("Chờ đến") ||
           status == QStringLiteral("Cho den") ||
           status == QStringLiteral("Đã đặt") ||
           status == QStringLiteral("Đã nhận bàn") ||
           status == QStringLiteral("Da dat") ||
           status == QStringLiteral("Da nhan ban");
}


// Lấy mã nhân viên từ tài khoản đăng nhập
QString GiaoDienDataService::employeeId(const QString &username) {
    const QString normalizedUsername = username.trimmed();

    if (normalizedUsername.isEmpty()) {
        return {};
    }

    TaiKhoanService service;

    const TaiKhoan* account =
        service.timTheoTenDangNhap(utf8(normalizedUsername));

    if (!account) {
        return {};
    }

    // Kiểm tra trạng thái tài khoản
    const QString status =
        QString::fromUtf8(account->getTrangThai().c_str()).trimmed();

    const bool isActive =
        status.compare(QStringLiteral("Hoạt động"),
                       Qt::CaseInsensitive) == 0 ||
        status.compare(QStringLiteral("HoatDong"),
                       Qt::CaseInsensitive) == 0 ||
        status.compare(QStringLiteral("Đang hoạt động"),
                       Qt::CaseInsensitive) == 0 ||
        status.compare(QStringLiteral("Dang hoat dong"),
                       Qt::CaseInsensitive) == 0 ||
        status.compare(QStringLiteral("Active"),
                       Qt::CaseInsensitive) == 0;

    if (!isActive) {
        return {};
    }

    // Trả về mã nhân viên được liên kết trong TaiKhoan.txt
    return QString::fromUtf8(account->getMaNV().c_str()).trimmed();
}

QString GiaoDienDataService::customerName(const QString &id) {
    KhachHangService service;

    const KhachHang* customer =
        service.timKhachHang(id.toStdString());

    return customer
        ? QString::fromUtf8(customer->getHoTen().c_str())
        : QStringLiteral("(Khách hàng không tồn tại)");
}

QString GiaoDienDataService::tableName(const QString &id) {
    BanService service;

    const Ban* table = service.timBan(id.toStdString());

    return table
        ? QString::fromUtf8(table->getTenBan().c_str())
        : QStringLiteral("Chưa gán bàn");
}

QString GiaoDienDataService::areaName(const QString &id) {
    KhuVucService service;

    const KhuVuc* area = service.timTheoMa(id.toStdString());

    return area
        ? QString::fromUtf8(area->getTenKhuVuc().c_str())
        : QStringLiteral("Chưa phân khu");
}

QString GiaoDienDataService::dateToday() {
    return QDate::currentDate().toString("yyyy-MM-dd");
}