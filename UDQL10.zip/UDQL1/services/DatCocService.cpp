#include "DatCocService.h"

#include "data/TextFileManager.h"
#include "DatBanService.h"
#include "BanService.h"
#include "GiaoDienDataService.h"

#include <algorithm>
#include <ctime>
#include <iomanip>
#include <sstream>
#include <unordered_map>
#include <unordered_set>

namespace
{
using Rows = std::vector<TextFileManager::Row>;

bool laTrangThaiDatCocHopLe(const std::string& trangThai)
{
    return trangThai == "Da dat coc" || trangThai == "Đã đặt cọc" ||
           trangThai == "Da hoan coc" || trangThai == "Đã hoàn cọc" ||
           trangThai == "Mat coc" || trangThai == "Mất cọc";
}

bool ngayISOHopLe(const std::string& ngay)
{
    if (ngay.size() != 10 || ngay[4] != '-' || ngay[7] != '-') return false;
    for (size_t i = 0; i < ngay.size(); ++i)
    {
        if (i == 4 || i == 7) continue;
        if (ngay[i] < '0' || ngay[i] > '9') return false;
    }

    const int nam = std::stoi(ngay.substr(0, 4));
    const int thang = std::stoi(ngay.substr(5, 2));
    const int ngayTrongThang = std::stoi(ngay.substr(8, 2));
    if (nam < 1900 || thang < 1 || thang > 12) return false;

    static const int soNgay[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int toiDa = soNgay[thang - 1];
    const bool namNhuan = nam % 400 == 0 || (nam % 4 == 0 && nam % 100 != 0);
    if (thang == 2 && namNhuan) toiDa = 29;
    return ngayTrongThang >= 1 && ngayTrongThang <= toiDa;
}

bool docDanhSach(std::vector<DatCoc>& danhSach)
{
    Rows rows;
    if (!TextFileManager::read("DatCoc.txt", rows)) return false;

    danhSach.clear();
    for (const auto& row : rows)
    {
        if (row.size() < 5) return false;
        try
        {
            DatCoc item(row[0], row[1], std::stoll(row[2]), row[3], row[4]);
            if (!item.hopLe()) return false;
            danhSach.push_back(item);
        }
        catch (...) { return false; }
    }
    return true;
}
}

bool DatCocService::napDanhSachText() const
{
    return docDanhSach(danhSachDatCoc);
}

bool DatCocService::ghiDanhSachText() const
{
    Rows rows;
    for (const DatCoc& item : danhSachDatCoc)
    {
        rows.push_back({item.getMaDatCoc(), item.getMaDatBan(),
                        std::to_string(item.getSoTien()), item.getNgayDatCoc(),
                        item.getTrangThai()});
    }
    return TextFileManager::write("DatCoc.txt", rows);
}

bool DatCocService::duLieuDatCocHopLe(const DatCoc& datCoc) const
{
    if (!datCoc.hopLe() || datCoc.getSoTien() <= 0 ||
        !laTrangThaiDatCocHopLe(datCoc.getTrangThai()) ||
        !ngayISOHopLe(datCoc.getNgayDatCoc()))
        return false;

    // Khong cho tao dat coc cho ma dat ban khong ton tai.
    DatBanService datBanService;
    return datBanService.timDatBan(datCoc.getMaDatBan()) != nullptr;
}

bool DatCocService::themDatCoc(const DatCoc& datCoc)
{
    if (!napDanhSachText()) return false;

    DatCoc moi = datCoc;
    if (moi.getMaDatCoc().empty())
        moi.setMaDatCoc(taoMaDatCoc());
    if (!duLieuDatCocHopLe(moi)) return false;

    for (const DatCoc& item : danhSachDatCoc)
    {
        if (item.getMaDatCoc() == moi.getMaDatCoc() ||
            item.getMaDatBan() == moi.getMaDatBan())
            return false;
    }

    danhSachDatCoc.push_back(moi);
    if (ghiDanhSachText()) return true;
    danhSachDatCoc.pop_back();
    return false;
}


bool DatCocService::capNhatTrangThai(const std::string& maDatCoc,
                                    const std::string& trangThaiMoi)
{
    if (!napDanhSachText() || !laTrangThaiDatCocHopLe(trangThaiMoi)) return false;

    auto it = std::find_if(danhSachDatCoc.begin(), danhSachDatCoc.end(),
        [&](const DatCoc& item) { return item.getMaDatCoc() == maDatCoc; });
    if (it == danhSachDatCoc.end()) return false;

    const std::string trangThaiCu = it->getTrangThai();
    it->setTrangThai(trangThaiMoi);
    if (it->hopLe() && ghiDanhSachText()) return true;
    it->setTrangThai(trangThaiCu);
    return false;
}


bool DatCocService::danhDauMatCocTheoDatBan(const std::string& maDatBan)
{
    if (!napDanhSachText()) return false;

    auto it = std::find_if(danhSachDatCoc.begin(), danhSachDatCoc.end(),
        [&](const DatCoc& item) { return item.getMaDatBan() == maDatBan; });

    // Dat ban khong co tien coc la hop le; khong phat sinh ban ghi mat coc.
    if (it == danhSachDatCoc.end()) return true;
    if (it->getTrangThai() == DatCoc::MAT_COC) return true;
    if (it->getTrangThai() != DatCoc::DA_DAT_COC) return false;

    const std::string trangThaiCu = it->getTrangThai();
    it->setTrangThai(DatCoc::MAT_COC);
    if (ghiDanhSachText()) return true;
    it->setTrangThai(trangThaiCu);
    return false;
}



const DatCoc* DatCocService::timTheoDatBan(const std::string& maDatBan) const
{
    if (!napDanhSachText()) return nullptr;
    auto it = std::find_if(danhSachDatCoc.begin(), danhSachDatCoc.end(),
        [&](const DatCoc& item) { return item.getMaDatBan() == maDatBan; });
    return it == danhSachDatCoc.end() ? nullptr : &*it;
}

const std::vector<DatCoc>& DatCocService::getDanhSachDatCoc() const
{
    if (!napDanhSachText()) danhSachDatCoc.clear();
    return danhSachDatCoc;
}

std::string DatCocService::taoMaDatCoc(int doDai) const
{
    if (doDai < 1) doDai = 6;
    int soLonNhat = 0;
    for (const DatCoc& item : getDanhSachDatCoc())
    {
        const std::string& ma = item.getMaDatCoc();
        if (ma.rfind("DC", 0) != 0) continue;
        try { soLonNhat = std::max(soLonNhat, std::stoi(ma.substr(2))); }
        catch (...) {}
    }
    std::ostringstream out;
    out << "DC" << std::setw(doDai) << std::setfill('0') << soLonNhat + 1;
    return out.str();
}

std::vector<DatCocChoThuInfo> DatCocService::getDanhSachChoThuTienCoc() const
{
    GiaoDienDataService::Rows snapshots;
    if (!GiaoDienDataService::layMucCocDatBan(snapshots)) return {};

    std::unordered_map<std::string, long long> amountByBooking;
    for (const auto& row : snapshots) {
        if (row.size() < 3) continue;
        try {
            amountByBooking[row[0]] = std::stoll(row[2]);
        } catch (...) {
            // Bo qua cau hinh tien coc khong hop le, khong lam dung toan bo danh sach.
        }
    }

    DatBanService bookingService;
    BanService tableService;
    const auto& bookings = bookingService.getDanhSachDatBan();
    const auto& deposits = getDanhSachDatCoc();
    std::unordered_set<std::string> bookingsWithDeposit;
    bookingsWithDeposit.reserve(deposits.size());
    for (const auto& deposit : deposits) {
        bookingsWithDeposit.insert(deposit.getMaDatBan());
    }

    std::vector<DatCocChoThuInfo> result;
    result.reserve(bookings.size());

    for (const auto& booking : bookings) {
        const std::string status = booking.getTrangThai();
        if (status == "Đã hủy" || status == "Da huy" ||
            status == "Không đến" || status == "Khong den" ||
            status == "Hoàn thành") {
            continue;
        }

        if (bookingsWithDeposit.find(booking.getMaDatBan()) != bookingsWithDeposit.end()) continue;

        const Ban* table = tableService.timBan(booking.getMaBan());
        if (!table) continue;

        const auto amount = amountByBooking.find(booking.getMaDatBan());
        if (amount == amountByBooking.end() || amount->second <= 0) continue;

        result.push_back({
            booking.getMaDatBan(),
            booking.getMaKH(),
            booking.getMaBan(),
            table->getMaKhuVuc(),
            booking.getNgayDat(),
            booking.getGioDat(),
            amount->second
        });
    }

    return result;
}