#ifndef DAT_BAN_SERVICE_H
#define DAT_BAN_SERVICE_H

#include <string>
#include <vector>
#include "../oop/DatBan.h"

// Xu ly nghiep vu dat ban: CRUD, kiem tra trung lich va cap nhat trang thai.
class DatBanService
{
private:
    mutable std::vector<DatBan> danhSachDatBan;

    bool napDanhSachText() const;
    bool ghiDanhSachText() const;

public:
    bool themDatBan(const DatBan& datBan);
    bool huyDatBan(const std::string& maDatBan);

    bool xacNhanKhachDen(const std::string& maDatBan);
    bool hoanThanhDatBan(const std::string& maDatBan);

    // Cap nhat trang thai "Cho den", "Da dat", "Khong den" theo thoi gian.
    bool capNhatTrangThaiTheoThoiGian();

    // Cac ham tuong thich voi phien ban giao dien cu.
    // Se duoc loai bo khi chuyen sang sua giao dien quan ly dat ban.
    bool chuyenBanText(const std::string& maDatBan,
                       const std::string& maBanMoi);

    const DatBan* timDatBan(const std::string& maDatBan) const;

    const std::vector<DatBan>& getDanhSachDatBan() const;
    std::string taoMaDatBan(int doDai = 6) const;
};

#endif
