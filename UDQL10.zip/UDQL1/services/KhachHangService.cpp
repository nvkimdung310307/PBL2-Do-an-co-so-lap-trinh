#include "KhachHangService.h"

#include "data/TextFileManager.h"
#include "../taikhoan/PhanQuyen.h"

#include <algorithm>
#include <iostream>

namespace
{
using Rows = std::vector<TextFileManager::Row>;

bool docKhachHang(std::vector<KhachHang>& danhSach)
{
    Rows rows;
    if (!TextFileManager::read("KhachHang.txt", rows)) return false;

    danhSach.clear();
    for (const auto& row : rows)
    {
        if (row.size() < 3) return false;
        danhSach.emplace_back(row[0], row[1], row[2]);
    }
    return true;
}

bool ghiKhachHang(const std::vector<KhachHang>& danhSach)
{
    Rows rows;
    for (const KhachHang& khachHang : danhSach)
    {
        rows.push_back({
            khachHang.getMaKH(),
            khachHang.getHoTen(),
            khachHang.getSoDienThoai()
        });
    }
    return TextFileManager::write("KhachHang.txt", rows);
}

bool soDienThoaiDaTonTai(const std::vector<KhachHang>& danhSach,
                         const std::string& soDienThoai,
                         const std::string& boQuaMa = "")
{
    if (soDienThoai.empty()) return false;

    return std::any_of(danhSach.begin(), danhSach.end(),
        [&](const KhachHang& item) {
            return item.getMaKH() != boQuaMa &&
                   item.getSoDienThoai() == soDienThoai;
        });
}
}

bool KhachHangService::napDanhSachText() const
{
    return docKhachHang(danhSachKhachHang);
}

bool KhachHangService::ghiDanhSachText() const
{
    return ghiKhachHang(danhSachKhachHang);
}

bool KhachHangService::themKhachHang(const KhachHang& khachHang)
{
    loiCuoiCung.clear();

    if (!PhanQuyen::coQuyenNghiepVu(QStringLiteral("KHACH_HANG")) &&
        !PhanQuyen::coQuyenNghiepVu(QStringLiteral("DAT_BAN")))
    {
        loiCuoiCung = QStringLiteral("Bạn không có quyền thêm khách hàng.");
        return false;
    }

    if (!khachHang.hopLe())
    {
        loiCuoiCung = QStringLiteral("Vui lòng nhập đầy đủ mã, họ tên và số điện thoại.");
        return false;
    }

    if (!napDanhSachText())
    {
        loiCuoiCung = TextFileManager::lastErrorMessage();
        return false;
    }

    const bool trungMa = std::any_of(
        danhSachKhachHang.begin(), danhSachKhachHang.end(),
        [&](const KhachHang& item) {
            return item.getMaKH() == khachHang.getMaKH();
        });

    if (trungMa)
    {
        loiCuoiCung = QStringLiteral("Mã khách hàng đã tồn tại.");
        return false;
    }

    if (soDienThoaiDaTonTai(danhSachKhachHang,
                            khachHang.getSoDienThoai()))
    {
        loiCuoiCung = QStringLiteral("Số điện thoại đã được sử dụng.");
        return false;
    }

    danhSachKhachHang.push_back(khachHang);
    if (!ghiDanhSachText())
    {
        loiCuoiCung = TextFileManager::lastErrorMessage();
        return false;
    }

    return true;
}

bool KhachHangService::suaKhachHang(const std::string& maKH,
                                   const KhachHang& khachHangMoi)
{
    loiCuoiCung.clear();

    if (!PhanQuyen::coQuyenNghiepVu(QStringLiteral("KHACH_HANG")) &&
        !PhanQuyen::coQuyenNghiepVu(QStringLiteral("DAT_BAN")))
    {
        loiCuoiCung = QStringLiteral("Bạn không có quyền cập nhật khách hàng.");
        return false;
    }

    if (!khachHangMoi.hopLe())
    {
        loiCuoiCung = QStringLiteral("Thông tin khách hàng không hợp lệ.");
        return false;
    }

    if (!napDanhSachText())
    {
        loiCuoiCung = TextFileManager::lastErrorMessage();
        return false;
    }

    auto it = std::find_if(
        danhSachKhachHang.begin(), danhSachKhachHang.end(),
        [&](const KhachHang& item) { return item.getMaKH() == maKH; });

    if (it == danhSachKhachHang.end())
    {
        loiCuoiCung = QStringLiteral("Không tìm thấy khách hàng.");
        return false;
    }

    if (soDienThoaiDaTonTai(danhSachKhachHang,
                            khachHangMoi.getSoDienThoai(), maKH))
    {
        loiCuoiCung = QStringLiteral("Số điện thoại đã thuộc khách hàng khác.");
        return false;
    }

    // Ma khach hang la khoa chinh, khong thay doi khi sua thong tin.
    *it = KhachHang(maKH, khachHangMoi.getHoTen(),
                    khachHangMoi.getSoDienThoai());

    if (!ghiDanhSachText())
    {
        loiCuoiCung = TextFileManager::lastErrorMessage();
        return false;
    }

    return true;
}


const KhachHang* KhachHangService::timKhachHang(
    const std::string& maKH) const
{
    if (!napDanhSachText()) return nullptr;

    auto it = std::find_if(
        danhSachKhachHang.begin(), danhSachKhachHang.end(),
        [&](const KhachHang& item) { return item.getMaKH() == maKH; });

    return it == danhSachKhachHang.end() ? nullptr : &*it;
}

const KhachHang* KhachHangService::timTheoSoDienThoai(
    const std::string& soDienThoai) const
{
    if (!napDanhSachText()) return nullptr;

    auto it = std::find_if(
        danhSachKhachHang.begin(), danhSachKhachHang.end(),
        [&](const KhachHang& item) {
            return item.getSoDienThoai() == soDienThoai;
        });

    return it == danhSachKhachHang.end() ? nullptr : &*it;
}

const std::vector<KhachHang>&
KhachHangService::getDanhSachKhachHang() const
{
    if (!napDanhSachText()) danhSachKhachHang.clear();
    return danhSachKhachHang;
}

std::string KhachHangService::taoMaKhachHang(int doDai) const
{
    if (doDai < 1) doDai = 6;

    int soLonNhat = 0;
    for (const KhachHang& khachHang : getDanhSachKhachHang())
    {
        const std::string& id = khachHang.getMaKH();
        if (id.rfind("KH", 0) != 0) continue;

        try
        {
            soLonNhat = std::max(soLonNhat, std::stoi(id.substr(2)));
        }
        catch (...) {}
    }

    std::string number = std::to_string(soLonNhat + 1);
    if (static_cast<int>(number.size()) < doDai)
        number.insert(0, doDai - number.size(), '0');

    return "KH" + number;
}

